













import json
import os
import re
import threading


ABBREVIATIONS = {"mr", "mrs", "ms", "dr", "st", "jr", "sr", "vs", "mt", "ft", "feat", "vol", "no", "pt"}


LONGEST_RUN = 3

PAUSE = 0.4
_NAME_BEAT = "⁣"

_lock = threading.Lock()
_loaded = {}


def words(text):
    """`text` as the bank is matched by: its words in lower case, apostrophes kept, all else a space."""
    text = text.lower().replace("’", "'").replace("‘", "'")
    text = re.sub(r"[^a-z0-9']+", " ", text)
    return " ".join(part.strip("'") for part in text.split() if part.strip("'"))


def index(pack_dir):
    """The pack's clips by their words, read once for each pack.json."""
    path = os.path.join(pack_dir, "pack.json")
    stamp = os.stat(path).st_mtime_ns
    with _lock:
        kept = _loaded.get(pack_dir)
        if kept and kept[0] == stamp:
            return kept[1]
        with open(path, encoding="utf-8") as file:
            pack = json.load(file)
        clips = {}
        for clip in pack.get("clips", []):
            clips.setdefault(words(clip["text"]), dict(clip, path=os.path.join(pack_dir, clip["file"])))
        _loaded[pack_dir] = (stamp, clips)
        return clips


def sentences(text):
    """`text`'s sentences, each as written. A "..." before a name ("Here's Steely Dan... Peg.") stays
    inside its sentence, as do "St." and the like."""
    text = re.sub(r"\.\.\.|…", _NAME_BEAT, " ".join(text.split()))
    found, start = [], 0
    for match in re.finditer(r"[.!?]+(?=\s|$)", text):
        if match.group() == ".":
            word = re.search(r"([\w']+)$", text[start:match.start()])
            if word is None or (len(word.group(1)) == 1 and not word.group(1).isdigit()) or word.group(1).lower() in ABBREVIATIONS:
                continue
        found.append(text[start:match.end()].strip())
        start = match.end()
    found.append(text[start:].strip())
    return [part.replace(_NAME_BEAT, "...") for part in found if re.search(r"\w", part)]


def spoken(text):
    """A sentence as Pocket TTS is given it: the app's "..." before a name as a comma, as in the take
    of "Here's Marvin Gaye, Got to Give It Up." picked by ear. With the dots Pocket TTS held 0.78 s
    before the title, against 0.38 s with the comma."""

    text = re.sub(r"\s*(\.\.\.|…)\s*", ", ", text)
    text = re.sub(r",\s*,", ",", text)
    return re.sub(r"\s+([,.!?])", r"\1", text).strip()


def pieces(text, pack_dir):
    """The line as it's said: [{"clip": path, "text": its words} | {"say": text}], in order. Each run
    of sentences the bank has is a clip; what's between is one piece for Pocket TTS."""
    clips = index(pack_dir)
    parts = sentences(text)
    out, at = [], 0
    while at < len(parts):
        for run in range(min(LONGEST_RUN, len(parts) - at), 0, -1):
            clip = clips.get(words(" ".join(parts[at:at + run])))
            if clip is not None:
                out.append({"clip": clip["path"], "text": clip["text"], "id": clip["id"]})
                at += run
                break
        else:
            said = spoken(parts[at])
            if out and "say" in out[-1]:
                out[-1]["say"] += " " + said
            else:
                out.append({"say": said})
            at += 1
    return out
