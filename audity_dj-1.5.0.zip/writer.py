
































import datetime
import hashlib
import json
import os
import random
import re
import threading

HERE = os.path.dirname(os.path.abspath(__file__))




SONG_PLAYED = 10
ARTIST_PLAYED = 50
ARTIST_LOVED = 100
KIND_PLAYED = 100
KIND_RANK = 3


NOT_LATELY_DAYS = 90

REMEMBERED = 400

GENRE_SAID = {"r&b": "R and B", "rnb": "R and B", "r and b": "R and B", "hip hop": "hip-hop", "hip-hop/rap": "hip-hop",
              "rap/hip-hop": "hip-hop", "electronic": "electronic music", "electronica": "electronic music",
              "dance": "dance music", "classical": "classical music", "latin": "Latin music", "ambient": "ambient music",
              "singer-songwriter": "singer-songwriter music", "synthpop": "synth-pop", "synth pop": "synth-pop",
              "neo soul": "neo-soul", "alternative": "alternative rock", "alt-rock": "alternative rock",
              "indie": "indie rock", "rock & roll": "rock", "rock and roll": "rock", "soundtrack": "soundtrack music",
              "world": "world music", "easy listening": "easy listening music", "new age": "new age music"}
GENRE_WORD = {"electronic music": "electronic", "dance music": "dance", "classical music": "classical",
              "Latin music": "Latin", "ambient music": "ambient", "singer-songwriter music": "singer-songwriter",
              "soundtrack music": "soundtrack", "world music": "world", "easy listening music": "easy listening",
              "new age music": "new age"}

SET_OF = {"onRepeat": "repeat", "throwback": "throwback", "fresh": "new", "deepCuts": "deepcut", "favorites": "favorites",
          "djPick": "djpick", "similar": "similar", "mix": "mix"}

SAYINGS = {"Aja": "Asia", "Sade": "Shah-day", "Björk": "Byerk", "Bon Iver": "Bon Ee-vair", "Sigur Rós": "Sigur Rose",
           "Siouxsie": "Soo-zee", "Chopin": "Show-pan", "Dvořák": "Dvor-zhak", "AC/DC": "A C D C", "MGMT": "M G M T",
           "Mötley Crüe": "Motley Crue", "Motörhead": "Motorhead", "Kygo": "Kee-go", "Hozier": "Hoe-zee-er",
           "Cyndi": "Cindy"}
MONTHS = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October",
          "November", "December"]
DAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]




SONG = ["Here's {artist}, {title}.", "Here's {title}, by {artist}.", "This is {artist}, with {title}.",
        "Here's {artist} with {title}.", "Up next, {artist}, {title}.", "Let's hear {artist}, {title}.",
        "This one's {title}, by {artist}.", "Here's {title}, from {artist}.", "Next up, {title}, by {artist}.",
        "This is {title}, by {artist}.", "Here's one from {artist}, {title}.", "Coming up, {artist}, {title}."]
SONG_ALBUM = ["From the album {album}, here's {artist}, {title}.", "Here's {title}, from {artist}'s album {album}.",
              "This is {artist}, with {title}, from {album}."]
SONG_YEAR = ["Here's {artist}, {title}, from {year}.", "From {year}, here's {artist}, {title}.",
             "This is {title}, by {artist}, from {year}."]
SONG_TITLE_TRACK = ["Here's the title track from {artist}'s {album}.", "Here's {artist}, with the title track, {title}."]
SONG_OPENER = ["Here's the song that opens {album}, {title}, by {artist}.", "This is the first song on {album}, {title}, by {artist}."]
SONG_ARTIST_SAID = ["Here's {title}.", "This one's {title}.", "Here's {title}, from them."]

BACK = ["That was {artist}, {title}.", "That was {title}, by {artist}.", "That was {artist}, with {title}.",
        "You just heard {artist}, {title}.", "That was {title}, from {artist}."]

OWN = {
    "mostPlayed": ["This is your most played song by {artist}.", "Of all the {artist} songs, this is the one you play most."],
    "favorite": ["Here's one of your favorites.", "This one's a favorite of yours."],
    "span": ["Here's some music from {span}.", "Let's hear a few from {span}.", "Coming up, some music from {span}."],
    "asked": ["Here's {asked}.", "Coming up, {asked}.", "Okay, {asked}, coming up."],
    "artistSet": ["Here's a little run of {artist}.", "Let's stay with {artist} for a few.", "A few in a row from {artist}, coming up."],
    "leaving": ["Moving on from {leaving}.", "Okay, leaving {leaving} behind.", "Let's move on from {leaving}."],
    "bridge": ["From {from} to {to}.", "From {from}, over to {to}.", "Let's go from {from} to {to}."],
    "albumWeek": ["{album} came out this week in {year}.", "This album came out this week, back in {year}."],

    "sameAlbum": ["Here's another one from {album}.", "Staying with {album} for this next one.", "One more from {album}.",
                  "Another song from {album}, coming up."],
    "sameArtist": ["Staying with {artist} for one more.", "Another one from {artist}.", "More from {artist}, coming up.",
                   "Let's stay with {artist}."],
    "sameYear": ["That one's from {year}, and so is this next one.", "Another one from {year}.", "Staying in {year} for this next one."],
    "sameGenre": ["More {genre}, coming up.", "Keeping it {genre}.", "Staying with some {genre}.", "A little more {genre}."],
    "genreMove": ["From {from} to some {to}.", "From {from}, over to some {to}.", "Let's go from {from} to a little {to}.",
                  "Switching from {from} to some {to}."],
    "yearsBack": ["Going back {years} years for this next one, to {year}.", "Let's go back {years} years, to {year}.",
                  "Back to {year} for this one."],
    "yearsOn": ["Jumping ahead {years} years, to {year}.", "Forward {years} years for this one, to {year}.",
                "Ahead to {year} for this next one."],
}

TEMPO_CHANGE = 20

YEARS_APART = 15


STRIKING = re.compile(r"\b(favorites?|vibes?|gems?|classics?|all-time|nonstop|can't stop|heavy rotation|hidden|"
                      r"go-tos?|surprises?|hunch|deep cuts?|throwback)\b", re.I)
STRIKING_LINES = 20


WORDS_A_SECOND = 3.0

_frames = None
_frames_lock = threading.Lock()


def frames():
    """frames.json, read once."""
    global _frames
    with _frames_lock:
        if _frames is None:
            with open(os.path.join(HERE, "frames.json"), encoding="utf-8") as file:
                data = json.load(file)
            for frame in data["frames"]:
                frame["id"] = hashlib.sha1((frame["kind"] + "|" + frame["text"] + "|" + json.dumps(frame["when"], sort_keys=True)).encode()).hexdigest()[:10]
            _frames = data
        return _frames




ONES = ["zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten", "eleven", "twelve",
        "thirteen", "fourteen", "fifteen", "sixteen", "seventeen", "eighteen", "nineteen"]
TENS = ["", "", "twenty", "thirty", "forty", "fifty", "sixty", "seventy", "eighty", "ninety"]


def number(value):
    """As Apple's spell-out in en_US says it (HostSpeech.number): 23 "twenty-three", 105 "one hundred five"."""
    value = int(value)
    if value < 0:
        return "minus " + number(-value)
    if value < 20:
        return ONES[value]
    if value < 100:
        return TENS[value // 10] + ("" if value % 10 == 0 else "-" + ONES[value % 10])
    if value < 1000:
        rest = value % 100
        return ONES[value // 100] + " hundred" + ("" if rest == 0 else " " + number(rest))
    if value < 1_000_000:
        rest = value % 1000
        return number(value // 1000) + " thousand" + ("" if rest == 0 else " " + number(rest))
    return str(value)


def year(value):
    """HostSpeech.year: 1977 "nineteen seventy-seven", 1905 "nineteen oh five", 2007 "two thousand seven"."""
    value = int(value)
    high, low = divmod(value, 100)
    if 2000 <= value <= 2009:
        return "two thousand" if low == 0 else "two thousand " + number(low)
    if low == 0:
        return number(high) + " hundred"
    if low < 10:
        return number(high) + " oh " + number(low)
    return number(high) + " " + number(low)


def decade(value):
    names = ["", "tens", "twenties", "thirties", "forties", "fifties", "sixties", "seventies", "eighties", "nineties"]
    tens = value % 100 // 10
    if value // 100 == 20:
        return "two thousands" if tens == 0 else "twenty " + names[tens]
    if tens == 0:
        return number(value // 100) + " hundreds"
    return names[tens]


def era(first, last):
    """HostSpeech.era: 1977-1979 "the late seventies", a whole decade "the eighties", else "nineteen
    seventy-five to nineteen eighty-three" (said, not shown: `era_shown`)."""
    start = first // 10 * 10
    if last // 10 * 10 != start:
        return None
    name = decade(start)
    low, high = first % 10, last % 10
    if (low, high) == (0, 9):
        return "the " + name
    if low <= 1 and 2 <= high <= 4:
        return "the early " + name
    if 3 <= low <= 5 and 4 <= high <= 6:
        return "the mid " + name
    if 6 <= low <= 8 and high >= 8:
        return "the late " + name
    return None


def span_around(value):
    """HostPlanner.span(around:): the part of its decade a year is in."""
    start = value // 10 * 10
    part = value % 10
    if part <= 3:
        return start, start + 3
    if part <= 6:
        return start + 4, start + 6
    return start + 7, start + 9


def genre_said(raw):
    """A genre tag as said mid-sentence, the bank's way where it has one: "soul", "R and B", "electronic
    music"; a word with capitals past its first letter stays as it is (HostSpeech.genre)."""
    text = " ".join(str(raw or "").split())
    if not text:
        return None
    lower = text.lower()
    if lower in GENRE_SAID:
        return GENRE_SAID[lower]
    if lower in {genre.lower() for genre in frames()["genres"]}:
        return next(genre for genre in frames()["genres"] if genre.lower() == lower)
    words = []
    for word in text.split(" "):
        parts = []
        for part in word.split("-"):
            parts.append(part.lower() if part[1:] == part[1:].lower() else part)
        words.append("-".join(parts))
    return " ".join(words)


def spoken(text):
    """A whole line as Pocket TTS is given it: years and other numbers as words, symbols as words, the
    names in SAYINGS as they're said (HostSpeech.spoken)."""
    for written, said in sorted(SAYINGS.items(), key=lambda item: -len(item[0])):
        text = re.sub(rf"(?<![\w]){re.escape(written)}(?![\w])", said, text)
    text = re.sub(r"\b(1[89]|20)(\d)0s\b", lambda m: decade(int(m.group(1)) * 100 + int(m.group(2)) * 10), text)
    text = re.sub(r"(?:'|\b)(\d)0s\b", lambda m: decade((1900 if int(m.group(1)) >= 3 else 2000) + int(m.group(1)) * 10), text)
    text = re.sub(r"\b(19|20)\d\d\b", lambda m: year(int(m.group(0))), text)
    text = re.sub(r"\b\d+\b", lambda m: number(int(m.group(0))) if len(m.group(0)) < 7 else m.group(0), text)
    text = text.replace(" & ", " and ").replace("&", " and ")
    text = re.sub(r"[\"“”*_#~()\[\]]", "", text)


    text = re.sub(r"[!?](?=,)", "", text)
    text = re.sub(r"\s*/\s*", ", ", text)
    text = re.sub(r"\s*[—–]\s*", ", ", text).replace("’", "'")
    text = re.sub(r"\s*(\.\.\.|…)\s*", ", ", text)
    text = re.sub(r",\s*,", ",", text)
    return re.sub(r"\s+([,.!?])", r"\1", " ".join(text.split())).strip()





def _date(value):
    if not value:
        return None
    try:
        text = str(value).strip().replace("Z", "+00:00")
        if len(text) == 10:
            return datetime.datetime.fromisoformat(text + "T12:00:00")
        return datetime.datetime.fromisoformat(text)
    except ValueError:
        return None


def _int(value, default=0):
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


class Truth:
    """What may be claimed of the song coming (or the one just played), of the set and of its artist,
    genre or era, from what the app sent alone. Nothing sent, nothing claimed."""

    def __init__(self, moment, now):
        self.now = now
        self.next = moment.get("next") or {}
        self.last = moment.get("last") or moment.get("playing") or {}
        self.set = moment.get("set") or {}
        self.kind = self.set.get("kind")

    def days_since(self, song):
        played = _date(song.get("lastPlayed"))
        if played is None:
            return None
        if played.tzinfo is not None and self.now.tzinfo is None:
            played = played.replace(tzinfo=None)
        elif played.tzinfo is None and self.now.tzinfo is not None:
            played = played.replace(tzinfo=self.now.tzinfo)
        return (self.now - played).days

    def song(self, claim, song):
        plays = _int(song.get("plays"))
        if claim == "favorite":
            return bool(song.get("favorite"))
        if claim == "played":
            return plays >= SONG_PLAYED
        if claim == "unplayed":
            days = self.days_since(song)
            return plays == 0 or (days is not None and days >= NOT_LATELY_DAYS)
        return False

    def set_claim(self, claim, which):
        """A claim of the set's songs ("Here's a few you can't stop playing.") by the kind of set the app
        made, checked against the song coming, which is one of them."""
        song, plays = self.next, _int(self.next.get("plays"))
        artist_plays = _int(song.get("artistPlays"), -1)
        days = self.days_since(song)
        if which == "repeat":
            return claim == "played" and plays >= 3
        if which == "throwback":
            if claim == "played":
                return plays >= 5
            if claim == "unplayed":
                return days is not None and days >= 60
            if claim == "favorite":
                return bool(song.get("favorite")) or plays >= SONG_PLAYED
        if which == "new":
            return claim == "unplayed" and plays == 0
        if which == "favorites":
            return claim == "favorite" and bool(song.get("favorite"))
        if which == "deepcut":
            if claim == "unplayed":
                return plays <= 3
            if claim == "played":
                return artist_plays >= ARTIST_PLAYED
            if claim == "favorite":
                return artist_plays >= ARTIST_LOVED
        if which == "djpick":
            return claim == "unplayed" and plays == 0
        return False

    def artist_claim(self, claim, which):
        """A claim of the artist of the song coming ("Up next, one of your most played artists.")."""
        plays = _int(self.next.get("artistPlays"), -1)
        if claim == "played":
            return which in ("top", "recent", "throwback") and plays >= ARTIST_PLAYED
        if claim == "favorite":
            return plays >= ARTIST_LOVED
        if claim == "unplayed":
            return (which in ("new", "rare") and 0 <= plays <= 3) or (which == "djpick" and plays == 0)
        return False

    def kind_claim(self, claim):
        """A claim of the set's genre or era ("always a favorite around here"): only from the listener's
        own plays of it, should the app have sent them."""
        listening = self.set.get("listening") or {}
        plays, rank = _int(listening.get("plays"), -1), _int(listening.get("rank"), 999)
        if claim in ("favorite", "played"):
            return plays >= KIND_PLAYED and rank <= KIND_RANK
        return False


def _true(frame, check):
    return all(check(claim) for claim in frame["claim"].split())





class Memory:
    """What a listener heard lately: each sentence's id and the lines, newest last, kept in a file of its
    own on this server, so every device the listener uses hears something new."""

    def __init__(self, folder):
        self.folder = folder
        self._lock = threading.Lock()
        self._kept = {}

    def _path(self, listener):
        return os.path.join(self.folder, hashlib.sha256((listener or "").strip().lower().encode()).hexdigest()[:24] + ".json")

    def of(self, listener):
        with self._lock:
            if listener not in self._kept:
                try:
                    with open(self._path(listener), encoding="utf-8") as file:
                        kept = json.load(file)
                except (OSError, ValueError):
                    kept = {}
                self._kept[listener] = {"used": list(kept.get("used", []))[-REMEMBERED * 4:],
                                        "lines": list(kept.get("lines", []))[-REMEMBERED:]}
            return self._kept[listener]

    def add(self, listener, used, line):
        memory = self.of(listener)
        with self._lock:
            memory["used"] = (memory["used"] + list(used))[-REMEMBERED * 4:]
            memory["lines"] = (memory["lines"] + [line])[-REMEMBERED:]
            try:
                os.makedirs(self.folder, exist_ok=True)
                path = self._path(listener)
                with open(path + ".new", "w", encoding="utf-8") as file:
                    json.dump(memory, file, ensure_ascii=False)
                os.replace(path + ".new", path)
            except OSError:
                pass

    def forget(self, listener):
        with self._lock:
            self._kept.pop(listener, None)
            try:
                os.remove(self._path(listener))
            except OSError:
                pass





class _Pen:
    """One line being written: its sentences, which of them were drawn, and what's been said."""

    def __init__(self, moment, memory, rng):
        self.moment = moment
        self.rng = rng
        self.used = memory.get("used", []) if memory else []
        self.heard = set(memory.get("lines", []) if memory else [])

        self.struck = {word.lower() for line in (memory.get("lines", []) if memory else [])[-STRIKING_LINES:]
                       for word in STRIKING.findall(line)}
        self.recent = {}
        for at, key in enumerate(self.used):
            self.recent[key] = at
        self.sentences = []
        self.drawn = []
        now = _date(moment.get("now")) or datetime.datetime.now()
        self.now = now
        self.truth = Truth(moment, now)
        self.next = moment.get("next") or {}
        self.last = moment.get("last") or {}
        self.set = moment.get("set") or {}

        self.album_please = False

        self.linked = False

        if not self.last and isinstance(moment.get("playing"), dict):
            self.last = moment["playing"]



    def draw(self, choices):
        """One of `choices` [(key, shown, said)], from those said least lately: never one of the last few
        a listener heard while another is left, and of the rest the older half, at random."""
        choices = [choice for choice in choices if choice and choice[1]]
        if not choices:
            return None

        if self.sentences:

            before = re.split(r"(?<=[.!?])\s+", self.sentences[-1][0])[-1].split()[:1]
            unlike = [choice for choice in choices if choice[1].split()[:1] != before]
            choices = unlike or choices

        struck = self.struck | {word.lower() for shown, _ in self.sentences for word in STRIKING.findall(shown)}
        if struck:
            fresh = [choice for choice in choices if not {w.lower() for w in STRIKING.findall(choice[1])} & struck]

            choices = fresh if len(fresh) >= 4 else choices
        never = [choice for choice in choices if choice[0] not in self.recent]
        if never:
            pick = self.rng.choice(never)
        else:
            ordered = sorted(choices, key=lambda choice: self.recent[choice[0]])
            pick = self.rng.choice(ordered[:max(1, len(ordered) // 2)])
        return pick

    def say(self, choices):
        pick = self.draw(choices)
        if pick is None:
            return False
        self.sentences.append((pick[1], pick[2]))
        self.drawn.append(pick[0])
        return True



    def fill(self, text, values):
        """`text` with its blanks filled: (shown, said), or None when one can't be."""
        shown, said = text, text
        for name in re.findall(r"\{(\w+)\}", text):
            key = name[0].lower() + name[1:]
            if key not in values or values[key] is None:
                return None
            value = values[key]
            shown_value, said_value = value if isinstance(value, tuple) else (value, value)
            if name[0].isupper():
                shown_value, said_value = shown_value[:1].upper() + shown_value[1:], said_value[:1].upper() + said_value[1:]
            shown = shown.replace("{" + name + "}", str(shown_value), 1)
            said = said.replace("{" + name + "}", str(said_value), 1)
        return shown, said

    def bank(self, kind, values=None, check=None, when=None, written=None, of="this", needs=()):
        """The bank's sentences of `kind` that fit: their conditions met, their blanks filled, their
        claims true, written for this era or genre."""
        values = values or {}
        out = []
        for frame in frames()["frames"]:
            if frame["kind"] != kind:
                continue
            if frame["of"] != of and kind in ("plays", "year", "since", "turns", "first"):
                continue
            if any(when is None or when.get(slot) != value for slot, value in frame["when"].items()):
                continue
            if any(slot not in frame["when"] for slot in needs):
                continue
            if frame["claim"] and (check is None or not _true(frame, check)):
                continue
            if not self._written_for(frame, written or {}):
                continue
            if "and so did" in frame["text"]:
                continue
            filled = self.fill(frame["text"], values)
            if filled:
                out.append((frame["id"], *filled))
        return out

    @staticmethod
    def _written_for(frame, written):
        for slot, value in written.items():
            allowed = frame["for"].get(slot)
            if allowed is None or value is None:
                continue
            if isinstance(allowed[0], int):

                if value < allowed[0] and slot != "year":
                    return False
            elif value not in allowed and value in frames()["genres"] + _ERAS:
                return False
            elif value not in allowed and slot == "genre" and len(allowed) < 25:
                return False
            elif value not in allowed and slot in ("part", "day", "vibe"):
                return False
        return True

    def own(self, kind, values, prefix="own"):
        out = []
        for text in OWN[kind]:
            filled = self.fill(text, values)
            if filled:
                out.append((f"{prefix}-{kind}-{hashlib.sha1(text.encode()).hexdigest()[:6]}", *filled))
        return out



    def part_of_day(self):
        hour = self.now.hour
        if 5 <= hour < 12:
            return "morning"
        if 12 <= hour < 17:
            return "afternoon"
        if 17 <= hour < 22:
            return "evening"
        return "night"

    def day(self):
        """Today, or before 5 in the morning the day before: it's still Friday night."""
        return DAYS[(self.now - datetime.timedelta(hours=5)).weekday()]

    def hello(self):
        """The first words of a session: a hello, for the time of day or the day, drawn from all of them."""
        when = {"part": self.part_of_day(), "day": self.day()}
        values = {"part": when["part"], "day": when["day"]}
        choices = (self.bank("opening", values, when=when, written=when)
                   + self.bank("hello", values, when=when, written=when))
        if when["part"] == "night":

            choices = [choice for choice in choices if "good night" not in choice[1].lower()]
        return self.say(choices)

    def time_of_day(self):
        when = {"part": self.part_of_day(), "day": self.day()}
        values = dict(when)
        return self.say(self.bank("timeOfDay", values, when=when, written=when)
                        + self.bank("hello", values, when=when, written=when))

    def era_values(self, first, last):
        name = era(first, last)
        if name is None:
            return None
        return {"era": name, "era_bare": name.removeprefix("the "), "Era": name, "Era_bare": name.removeprefix("the ")}

    def about(self):
        """What the set coming is, as the bank says it, true of every song in it."""
        kind = self.set.get("kind")
        if self.set.get("new") is False:
            return False
        sound = self.moment.get("sound") or {}
        picked = self.moment.get("era") or None
        if picked and picked.get("isNew") and picked.get("from"):
            values = self.era_values(_int(picked["from"]), _int(picked.get("to", picked["from"])))
            if values and self.say(self.bank("era", values, when={}, written={"era": values["era"]})):
                return True
        if kind == "era" and not (picked and not picked.get("isNew")):
            first, last = _int(self.set.get("from")), _int(self.set.get("to", self.set.get("from")))
            values = self.era_values(first, last) if first else None
            if values:
                return self.say(self.bank("era", values, when={}, written={"era": values["era"]},
                                          check=lambda claim: self.truth.kind_claim(claim)))
            if first:
                span = f"{first} to {last}" if first != last else str(first)
                return self.say(self.own("span", {"span": (span, spoken(span))}))
        if kind == "genre" and self.set.get("genre"):
            genre = genre_said(self.set["genre"])
            values = {"genre": (genre_shown(self.set["genre"]), genre), "genre_word": GENRE_WORD.get(genre, genre),
                      "Genre": (genre_shown(self.set["genre"]), genre)}
            choices = self.bank("genre", values, when={}, written={"genre": genre},
                                check=lambda claim: self.truth.kind_claim(claim))
            if sound.get("from") and not picked:
                values.update(self.era_values(_int(sound["from"]), _int(sound.get("to", sound["from"]))) or {})
                choices += self.bank("sound", values, when={}) if "era" in values else []
            return self.say(choices)
        if kind == "artist" and self.set.get("artist"):
            artist = self.set["artist"]
            plays = _int(self.next.get("artistPlays"), -1)
            which = "top" if plays >= ARTIST_PLAYED else "rare" if 0 <= plays <= 3 else None
            choices = self.own("artistSet", {"artist": (artist, spoken(artist))})
            if which:

                choices += [choice for choice in self.bank("artist", {}, when={"set": which}, needs=("set",),
                                                           check=lambda claim: self.truth.artist_claim(claim, which))
                            if not re.search(r"this month|lately", choice[1])]
            if (_name(self.last.get("artist")) or "").lower() == artist.lower():

                choices += self.bank("artist", {}, when={})
            return self.say(choices)
        if kind == "asked" and self.set.get("asked"):
            asked = " ".join(str(self.set["asked"]).split())
            return self.say(self.own("asked", {"asked": (asked, spoken(asked))}))
        which = SET_OF.get(kind)
        if which:
            choices = self.bank("about", {}, when={"set": which}, check=lambda claim: self.truth.set_claim(claim, which))
            if which == "new" and _int(self.next.get("plays")) > 0:
                choices = []
            return self.say(choices)

        if sound.get("genre") or sound.get("from"):
            values = {}
            if sound.get("genre"):
                genre = genre_said(sound["genre"])
                values.update(genre=(genre_shown(sound["genre"]), genre))
            if sound.get("from"):
                values.update(self.era_values(_int(sound["from"]), _int(sound.get("to", sound["from"]))) or {})
            return self.say(self.bank("sound", values, when={}))
        return False

    def song(self, extra=True):
        """The song coming, by name: "Here's Bill Withers, Lovely Day." Now and then its album, its year
        (when nothing before it in the line said it), or what it is on its album."""
        title, artist = _name(self.next.get("title")), _name(self.next.get("artist"))
        if not title:
            return False
        if not artist:
            return self.say([("song-title", f"Here's {title}.", f"Here's {spoken(title)}.")])
        values = {"title": (title, spoken(title)), "artist": (artist, spoken(artist))}
        album = _name(self.next.get("album"))
        album_said = bool(album) and any(album.lower() in shown.lower() for shown, _ in self.sentences)
        if album and album.lower() != title.lower() and len(album) <= 40 and not _plain_album(album) and not album_said:
            values["album"] = (album, spoken(album))
        said_year = any(re.search(r"\b(19|20)\d\d\b", shown) for shown, _ in self.sentences)
        if _int(self.next.get("year")) and not said_year:
            values["year"] = (str(_int(self.next["year"])), year(_int(self.next["year"])))
        choices = [self._own_song(text, values) for text in SONG]
        artist_said = any(artist.lower() in shown.lower() for shown, _ in self.sentences)
        if artist_said:
            choices = [self._own_song(text, values) for text in SONG_ARTIST_SAID]
        elif self.album_please and "album" in values and not any(values["album"][0] in shown for shown, _ in self.sentences):
            choices = [self._own_song(text, values) for text in SONG_ALBUM]
        elif extra:
            roll = self.rng.random()
            if self.next.get("titleTrack") and album and not album_said and roll < 0.5:
                values["album"] = (album, spoken(album))
                choices = [self._own_song(text, values) for text in SONG_TITLE_TRACK]
            elif self.next.get("opener") and "album" in values and roll < 0.4:
                choices = [self._own_song(text, values) for text in SONG_OPENER]
            elif "year" in values and roll < 0.25:
                choices = [self._own_song(text, values) for text in SONG_YEAR]
            elif "album" in values and roll < 0.4:
                choices = [self._own_song(text, values) for text in SONG_ALBUM]
        return self.say(choices)

    def _own_song(self, text, values):
        filled = self.fill(text, values)
        return (f"song-{hashlib.sha1(text.encode()).hexdigest()[:6]}", *filled) if filled else None

    def back(self):
        """The song just played, by name, and now and then what's true of it."""
        title, artist = _name(self.last.get("title")), _name(self.last.get("artist"))
        if not (title and artist):
            return False
        values = {"title": (title, spoken(title)), "artist": (artist, spoken(artist))}
        self.say([(f"back-{hashlib.sha1(text.encode()).hexdigest()[:6]}", *self.fill(text, values)) for text in BACK])
        return True

    def fact(self, song, of="this", personal=False):
        """One thing that's true of the song: its plays, when it came out, when it was last played, that
        it's a favorite or new. False when there's nothing to say."""
        choices = []
        plays = _int(song.get("plays"))
        if plays >= SONG_PLAYED:
            choices += self.bank("plays", {"count": (str(plays), number(plays))}, written={"count": plays}, of=of, when={})
        song_year = _int(song.get("year"))
        years = []
        if song_year:
            years = self.bank("year", {"year": (str(song_year), year(song_year))}, written={"year": song_year}, of=of, when={})
        if not personal:
            choices += years
        days = self.truth.days_since(song)
        if plays > 0 and days is not None and days >= NOT_LATELY_DAYS:
            played = _date(song.get("lastPlayed"))
            choices += self.bank("since", {"month": MONTHS[played.month - 1], "year": (str(played.year), year(played.year))},
                                 written={"year": played.year}, of=of, when={},
                                 check=lambda claim: self.truth.song(claim, song))
        if of == "this":
            if plays == 0:
                choices += self.bank("first", {}, when={}, check=lambda claim: self.truth.song(claim, song))
            if song.get("favorite"):
                choices += self.bank("favorite", {}, when={}, check=lambda claim: True) + self.own("favorite", {})
            if song.get("artistsMostPlayed") and plays >= SONG_PLAYED and _name(song.get("artist")):
                choices += self.own("mostPlayed", {"artist": (_name(song["artist"]), spoken(_name(song["artist"])))})
        else:
            if song.get("artistsMostPlayed") and plays >= SONG_PLAYED:
                choices += self.bank("artistMost", {}, when={}, of="that", check=lambda claim: True)
            if song.get("titleTrack"):
                choices += self.bank("titleTrack", {}, when={}, of="that")
        return self.say(choices or (years if personal else []))

    def when_fact(self):
        """When the song came out: its album's birthday this week, a round number of years this year, or
        its year."""
        released = _date(self.next.get("released"))
        try:
            this_year = released.replace(year=self.now.year, tzinfo=None) if released is not None else None
        except ValueError:
            this_year = None
        if this_year is not None and released.year < self.now.year:
            if abs((this_year - self.now.replace(tzinfo=None)).days) <= 3:
                years = self.now.year - released.year
                choices = self.bank("turns", {"years": (str(years), number(years))}, written={"years": years}, when={})
                choices = [choice for choice in choices if "album" in choice[1]]
                album = _name(self.next.get("album"))
                if album:
                    choices += self.own("albumWeek", {"album": (album, spoken(album)),
                                                      "year": (str(released.year), year(released.year))})
                if self.say(choices):
                    self.album_please = True
                    return True
        song_year = _int(self.next.get("year"))
        if song_year:
            years = self.now.year - song_year
            if years >= 10 and years % 5 == 0 and self.rng.random() < 0.6:
                choices = [choice for choice in self.bank("turns", {"years": (str(years), number(years))},
                                                          written={"years": years}, when={})
                           if "album" not in choice[1]]
                if self.say(choices):
                    return True
            return self.say(self.bank("year", {"year": (str(song_year), year(song_year))}, written={"year": song_year}, when={}))
        return False

    def bridge(self):
        """From the years of the song just played to the next's: "From the late seventies to the early
        eighties." """
        first, then = _int(self.last.get("year")), _int(self.next.get("year"))
        if not (first and then):
            return False
        before, after = era(*span_around(first)), era(*span_around(then))
        if not before or not after or before == after:
            return False
        choices = self.bank("switch", {"from": before, "to": after}, when={}) + self.own("bridge", {"from": before, "to": after})
        return self.say(choices)

    def leaving(self):
        leaving = self.moment.get("leaving") or {}
        artist = _name(leaving.get("artist"))
        genre = genre_said(leaving.get("genre")) if leaving.get("genre") else None
        when = era(_int(leaving["from"]), _int(leaving.get("to", leaving["from"]))) if leaving.get("from") else None
        if artist:
            theirs = artist + ("'" if artist.endswith("s") else "'s")
            said = (f"{theirs} {genre} from {when}" if genre and when else f"{theirs} {genre}" if genre
                    else f"{artist} and {when}" if when else artist)
        else:
            said = f"{genre} from {when}" if genre and when else genre or when
        if not said:
            return False
        choices = self.own("leaving", {"leaving": (said, spoken(said))})
        if genre and not artist:

            choices += self.bank("enough", {"genre": (genre_shown(leaving["genre"]), genre)}, when={}, written={"genre": genre})
        if when and not artist and not genre:
            choices += self.bank("enough", {"era": when}, when={}, written={"era": when})
        return self.say(choices)

    def mood(self, mood):
        return self.say(self.bank("moodShift", {}, when={"mood": mood}))

    def tempo(self):
        """"up" or "down" when the songs' BPM tags differ by TEMPO_CHANGE or more, else None."""
        before, after = _int(self.last.get("bpm")), _int(self.next.get("bpm"))
        if not (before and after):
            return None
        if after - before >= TEMPO_CHANGE:
            return "up"
        if before - after >= TEMPO_CHANGE:
            return "down"
        return None

    def links(self):
        """What connects the song playing (`last`) to the next, the closest first: [(strength, kind,
        choices)]. Only what their own tags say."""
        if not self.last:
            return []
        found = []
        before_album, after_album = _name(self.last.get("album")), _name(self.next.get("album"))
        before_artist, after_artist = _name(self.last.get("artist")), _name(self.next.get("artist"))
        same_artist = bool(before_artist and after_artist and before_artist.lower() == after_artist.lower())
        if same_artist and (_name(self.last.get("title")) or "").lower() == (_name(self.next.get("title")) or "").lower():
            return []
        if (same_artist and before_album and after_album and before_album.lower() == after_album.lower()
                and not _plain_album(after_album)):
            found.append((3, "sameAlbum", self.own("sameAlbum", {"album": (after_album, spoken(after_album))})))
        if same_artist:
            found.append((3, "sameArtist", self.own("sameArtist", {"artist": (after_artist, spoken(after_artist))})))
        before_year, after_year = _int(self.last.get("year")), _int(self.next.get("year"))
        if before_year and before_year == after_year:
            values = {"year": (str(after_year), year(after_year))}
            found.append((2, "sameYear", self.own("sameYear", values)))
        elif before_year and after_year and abs(after_year - before_year) >= YEARS_APART:
            years = abs(after_year - before_year)
            kind = "yearsBack" if after_year < before_year else "yearsOn"
            choices = self.own(kind, {"years": (str(years), number(years)), "year": (str(after_year), year(after_year))})
            if years > 60:
                choices = [choice for choice in choices if str(years) not in choice[1]]
            found.append((2, kind, choices))
        before_genre, after_genre = genre_said(self.last.get("genre")), genre_said(self.next.get("genre"))
        if before_genre and after_genre:
            if before_genre.lower() == after_genre.lower():
                found.append((1, "sameGenre", self.own("sameGenre", {"genre": (genre_shown(self.next["genre"]), after_genre)})))
            else:
                values = {"from": (genre_shown(self.last["genre"]), before_genre), "to": (genre_shown(self.next["genre"]), after_genre)}
                found.append((2, "genreMove", self.own("genreMove", values)))
        if before_year and after_year:
            before_era, after_era = era(*span_around(before_year)), era(*span_around(after_year))
            if before_era and after_era and before_era != after_era and abs(after_year - before_year) < YEARS_APART:
                found.append((1, "eraMove", self.bank("switch", {"from": before_era, "to": after_era}, when={})
                              + self.own("bridge", {"from": before_era, "to": after_era})))
        mood = self.tempo()
        if mood:
            found.append((1, "tempo", self.bank("moodShift", {}, when={"mood": mood})))
        return [each for each in found if each[2]]

    def link(self, strongest=1):
        """A sentence connecting the song playing to the next, of at least `strongest`: drawn among the
        closest connections they have (the same album or artist before the same year, before a move of
        genre or era). False with none."""
        found = [each for each in self.links() if each[0] >= strongest]
        if not found:
            return False
        best = max(each[0] for each in found)
        choices = [choice for strength, _, each in found if strength == best for choice in each]


        if self.say(choices):
            self.linked = True
            return True
        return False



    def write(self):
        angle = self.moment.get("angle") or "intro"
        if angle == "goodbye":
            self.say(self.bank("goodbye", {}, when={}))
            return
        if angle == "opening" or self.moment.get("first"):
            self.hello()
            self.about()
        elif angle == "backAnnounce":



            self.back()
            if not (self.set.get("new") is not False and self.about()):
                if not self.link() and self.rng.random() < 0.6:
                    self.fact(self.last, of="that")
        elif angle == "eraBridge":
            if not self.bridge() and not self.link():
                self.about()
            elif self.set.get("kind") not in ("era",) and self.rng.random() < 0.5:
                self.about()
        elif angle == "personalStat":
            if not self.fact(self.next, personal=True):
                self.about()
            elif self.rng.random() < 0.5:
                self.about()
        elif angle == "timeOfDay":
            self.time_of_day()
            self.about()
        elif angle == "moodShift":
            mood = self.moment.get("mood") or self.tempo()
            if mood not in ("up", "down", "different", "same") or not self.mood(mood):
                self.about()
            elif self.rng.random() < 0.5:
                self.about()
        elif angle == "anniversary":
            if not self.when_fact():
                self.about()
        elif angle == "switchUp":


            if not (self.moment.get("leaving") and self.rng.random() < 0.6 and self.leaving()):
                self.say(self.bank("switchUp", {}, when={}) + self.bank("moodShift", {}, when={"mood": "different"}))
            self.about()
        elif angle == "answer":
            self.say(self.bank("answer", {}, when={}))
            self.about()
        elif angle == "next":

            if not (self.rng.random() < 0.8 and self.link()) and self.rng.random() < 0.5:
                self.say(self.bank("next", {}, when={}))
        else:

            if not self.about():
                self.link()
        self.song(extra=len(self.sentences) < 2)
        self.fit()

    def fit(self):
        """The line cut to the time the app says it has ("room", in seconds: until the next song's singing),
        at WORDS_A_SECOND: the sentences before the name go first, the earliest first, but an opening's
        hello; the name always stays."""
        room = self.moment.get("room")
        try:
            room = float(room) if room is not None else None
        except (TypeError, ValueError):
            room = None
        if not room or room <= 0:
            return
        budget = max(room * WORDS_A_SECOND, 6)
        keep_first = (self.moment.get("angle") == "opening" or self.moment.get("first")) and len(self.sentences) > 2
        while len(self.sentences) > 1 and sum(len(shown.split()) for shown, _ in self.sentences) > budget:
            at = 1 if keep_first and len(self.sentences) > 2 else 0
            self.sentences.pop(at)
            self.drawn.pop(at)


_ERAS = []


def genre_shown(raw):
    """A genre tag as the line shows it: as the app says it, R&B as written."""
    text = " ".join(str(raw or "").split())
    said = genre_said(text) or ""
    return "R&B" if said == "R and B" else said


def _name(value):
    return " ".join(str(value or "").split()) or None


def _plain_album(album):
    """An album name no host would say: a best-of, a self-titled one, "Unknown"."""
    lower = album.lower()
    return lower in ("unknown album", "unknown", "[unknown album]") or bool(re.search(r"\b(greatest hits|best of|the very best|collection|anthology|essential)\b", lower))


def write(moment, memory=None, seed=None, tries=8):
    """The line for `moment`: {"text": as shown, "spoken": as Pocket TTS is given it, "used": the
    sentences drawn}. Written again, up to `tries` times, should the whole line be one said before."""
    rng = random.Random(seed)
    heard = set((memory or {}).get("lines", []))
    best = None
    for _ in range(tries):
        pen = _Pen(moment, memory, rng)
        pen.write()
        if not pen.sentences:
            return None

        text = re.sub(r"([!?])\.", lambda m: m.group(1), " ".join(shown for shown, _ in pen.sentences))
        said = re.sub(r"([!?])\.", lambda m: m.group(1), " ".join(said for _, said in pen.sentences))
        said = re.sub(r"[!?](?=,)", "", said)
        line = {"text": text, "spoken": said, "used": pen.drawn,
                "angle": moment.get("angle") or "intro"}
        if text not in heard:
            return line
        best = best or line
    return best


def _eras():
    for start in range(1940, 2030, 10):
        for part in ("the early ", "the mid ", "the late ", "the "):
            yield part + decade(start)


_ERAS.extend(_eras())
