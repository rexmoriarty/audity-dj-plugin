




























import argparse
import collections
import copy
import hashlib
import json
import os
import re
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

parser = argparse.ArgumentParser()
parser.add_argument("--port", type=int, required=True)
parser.add_argument("--model", required=True, help="Pocket TTS's English weights (safetensors)")
parser.add_argument("--tokenizer", required=True, help="its tokenizer.json")
parser.add_argument("--decoder", required=True, help="the codec's decoder retrained on the bank (safetensors)")
parser.add_argument("--prompt", required=True, help="the bank's takes Pocket TTS copies Theo from")
parser.add_argument("--cache", required=True, help="a folder for the voice's state, worked out once")
parser.add_argument("--steps", type=int, default=4)
parser.add_argument("--temperature", type=float, default=0.3)
parser.add_argument("--threads", type=int, default=0, help="torch's threads; 0 keeps Pocket TTS's own, 1")
parser.add_argument("--idle", type=float, default=90, help="seconds without a word from the plugin before it stops")
parser.add_argument("--whole-prompt", default="", help="the voice whole lines are said in (writer.py), or none")
parser.add_argument("--whole-steps", type=int, default=1)
parser.add_argument("--whole-temperature", type=float, default=0.3)
parser.add_argument("--whole-threads", type=int, default=0, help="torch's threads for a whole line; 0 keeps --threads'")
args = parser.parse_args()

import numpy as np
import soundfile
from scipy.signal import butter, lfilter, resample_poly, sosfilt

RATE = 48_000
POCKET_RATE = 24_000



PAUSE = 0.34
EDGE = 0.05
LOUDNESS = 10 ** (-20 / 20)

state = {"loaded": False, "error": None, "heard_from": time.monotonic(), "threads": None}
loaded = threading.Event()
speaking = threading.Lock()
model = {"tts": None, "voice": None, "init_states": None, "torch": None, "stock_mimi": None, "whole_voice": None}


SHORTEST_FOR_LETTERS, LONGEST_FOR_LETTERS = 0.03, 0.12



LONGEST_PAUSE = 0.6
_said = collections.OrderedDict()
_said_lock = threading.Lock()





def _config():
    """Pocket TTS's own English config, its weights and tokenizer read from this server's disk instead
    of Hugging Face (where the weights that copy a voice are gated)."""
    import pocket_tts

    with open(os.path.join(os.path.dirname(pocket_tts.__file__), "config", "english.yaml"), encoding="utf-8") as file:
        text = file.read()
    text = re.sub(r"(?m)^weights_path:.*$", "weights_path: " + json.dumps(args.model), text)
    text = re.sub(r"(?m)^weights_path_without_voice_cloning:.*$", "", text)
    text = re.sub(r"(?m)^(\s*)tokenizer_path:.*$", lambda m: m.group(1) + "tokenizer_path: " + json.dumps(args.tokenizer), text)
    path = os.path.join(args.cache, "english.yaml")
    with open(path + ".new", "w", encoding="utf-8") as file:
        file.write(text)
    os.replace(path + ".new", path)
    return path


def load():
    try:
        began = time.monotonic()
        os.makedirs(args.cache, exist_ok=True)
        import torch
        from safetensors.torch import load_file

        from pocket_tts import TTSModel
        from pocket_tts.models.model_state import export_model_state
        from pocket_tts.modules.stateful_module import init_states




        if args.threads > 0:
            torch.set_num_threads(args.threads)
        state["threads"] = torch.get_num_threads()
        tts = TTSModel.load_model(config=_config(), temp=args.temperature, sampler_decode_steps=args.steps)

        stock = copy.deepcopy(tts.mimi).eval() if args.whole_prompt else None
        decoder = load_file(args.decoder)
        unknown = set(decoder) - set(tts.mimi.state_dict())
        if unknown:
            raise RuntimeError(f"the retrained decoder doesn't fit Pocket TTS's codec ({sorted(unknown)[:2]})")
        tts.mimi.load_state_dict(decoder, strict=False)
        tts.mimi.eval()


        with open(args.prompt, "rb") as file:
            key = hashlib.sha256(file.read()).hexdigest()[:16]
        key += f"-{os.path.getsize(args.model)}"
        kept = os.path.join(args.cache, f"voice-{key}.safetensors")
        if os.path.isfile(kept):
            voice = tts.get_state_for_audio_prompt(kept)
        else:
            voice = tts.get_state_for_audio_prompt(args.prompt)
            try:
                export_model_state(voice, kept + ".new.safetensors")
                os.replace(kept + ".new.safetensors", kept)
            except OSError:
                pass
        whole = None
        if stock is not None:

            try:
                whole = _voice_state(tts, args.whole_prompt, "whole", stock, export_model_state)
            except Exception as error:
                state["wholeError"] = f"{type(error).__name__}: {error}"
                print(f"Whole lines' voice failed to load: {state['wholeError']}", flush=True)
        model.update(tts=tts, voice=voice, init_states=init_states, torch=torch, stock_mimi=stock, whole_voice=whole)
        if whole is not None:


            try:
                say_whole("Hello.", 1)
            except Exception as error:
                print(f"Whole lines' warm-up failed: {type(error).__name__}: {error}", flush=True)
        state["whole"] = whole is not None
        state["loaded"] = True
        loaded.set()
        print(f"Pocket TTS loaded in {time.monotonic() - began:.1f} s ({torch.get_num_threads()} threads)", flush=True)
    except Exception as error:
        state["error"] = f"{type(error).__name__}: {error}"
        loaded.set()
        print(f"Pocket TTS failed to load: {state['error']}", flush=True)


def _voice_state(tts, prompt, name, mimi, export_model_state):
    """A voice's state from its prompt, read with `mimi`, worked out once and kept (it depends on the
    prompt and the weights that read it)."""
    with open(prompt, "rb") as file:
        key = hashlib.sha256(file.read()).hexdigest()[:16]
    kept = os.path.join(args.cache, f"voice-{name}-{key}-{os.path.getsize(args.model)}.safetensors")
    if os.path.isfile(kept):
        return tts.get_state_for_audio_prompt(kept)
    before = tts.mimi
    tts.mimi = mimi
    try:
        voice = tts.get_state_for_audio_prompt(prompt)
    finally:
        tts.mimi = before
    try:
        export_model_state(voice, kept + ".new.safetensors")
        os.replace(kept + ".new.safetensors", kept)
    except OSError:
        pass
    return voice


def say_whole(text, seed):
    """`text`, a whole line, said in one go in the whole lines' voice with the codec as it comes, at
    24 kHz."""
    torch = model["torch"]
    tts = model["tts"]
    with speaking, torch.no_grad():
        kept = (tts.mimi, tts.temp, tts.sampler_decode_steps, torch.get_num_threads())
        tts.mimi, tts.temp, tts.sampler_decode_steps = model["stock_mimi"], args.whole_temperature, args.whole_steps
        if args.whole_threads > 0:
            torch.set_num_threads(args.whole_threads)
        try:
            torch.manual_seed(int(seed))



            return tts.generate_audio(model["whole_voice"], text, max_tokens=80).numpy().astype(np.float32).reshape(-1)
        finally:
            tts.mimi, tts.temp, tts.sampler_decode_steps = kept[:3]
            torch.set_num_threads(kept[3])


def cap_pauses(audio, rate, longest=LONGEST_PAUSE, under=40.0, blend=0.01):
    """`audio` with every quiet inside it (10 ms steps more than `under` dB below its loudest) longer than
    `longest` shortened to it, the middle taken out and the two sides blended."""
    step = max(1, int(0.01 * rate))
    frames = len(audio) // step
    if frames < 3:
        return audio
    level = np.sqrt(np.mean(audio[:frames * step].astype(np.float64).reshape(frames, step) ** 2, axis=1))
    quiet = level < level.max() * 10 ** (-under / 20)
    keep, cuts, at = int(longest / 0.01), [], 0
    voiced = np.flatnonzero(~quiet)
    if not voiced.size:
        return audio
    at = int(voiced[0])
    while at <= voiced[-1]:
        if not quiet[at]:
            at += 1
            continue
        end = at
        while end < frames and quiet[end]:
            end += 1
        if end - at > keep:
            cuts.append(((at + keep // 2) * step, (end - (keep - keep // 2)) * step))
        at = end
    if not cuts:
        return audio
    ramp = int(blend * rate)
    curve = np.sin(np.linspace(0, np.pi / 2, ramp, dtype=np.float32)) ** 2
    out, start = [], 0
    for begin, finish in cuts:
        before, after = audio[start:begin].copy(), audio[finish:finish + ramp]
        if before.size >= ramp and after.size == ramp:
            before[-ramp:] = before[-ramp:] * (1 - curve) + after * curve
            out.append(before)
            start = finish + ramp
        else:
            out.append(before)
            start = finish
    out.append(audio[start:])
    return np.concatenate(out)


_HIGH_PASS = butter(2, 80, btype="highpass", fs=POCKET_RATE, output="sos")


def broken(audio, rate):
    """Why a take is broken, by its sound alone, or None (the take-picking research's free checks,
    research_notes/Whole line DJ voice quality/take_selection.md): clipped, cut off while still talking,
    or a silence inside it long enough that it stopped and started again."""
    if not audio.size:
        return "silent"
    if np.mean(np.abs(audio) >= 0.999) > 0.001:
        return "clipped"
    step = max(1, int(0.01 * rate))
    frames = len(audio) // step
    if frames < 20:
        return None
    level = np.sqrt(np.mean(audio[:frames * step].astype(np.float64).reshape(frames, step) ** 2, axis=1))
    loud = level > level.max() * 10 ** (-20 / 20)
    if loud[-15:].all():
        return "cut off"
    voiced = np.flatnonzero(level > level.max() * 10 ** (-40 / 20))
    quiet = np.diff(voiced) - 1
    if quiet.size and quiet.max() * 0.01 > 1.5:
        return "a gap"
    return None


def median_pitch(audio, rate, low=70.0, high=300.0):
    """The voice's median pitch in Hz, by autocorrelation in 40 ms steps of its voiced parts, or 0 (0.94
    alike the voice chat's pitch on its 24 takes, in 12 ms a take)."""
    frame, hop = int(0.04 * rate), int(0.01 * rate)
    count = (len(audio) - frame) // hop
    if count < 5:
        return 0.0
    frames = np.lib.stride_tricks.sliding_window_view(audio, frame)[::hop][:count].astype(np.float64)
    level = np.sqrt(np.mean(frames ** 2, axis=1))
    frames = frames[level > level.max() * 10 ** (-25 / 20)]
    frames = frames - frames.mean(axis=1, keepdims=True)
    spectrum = np.fft.rfft(frames * np.hanning(frame), n=2 * frame, axis=1)
    corr = np.fft.irfft(np.abs(spectrum) ** 2, axis=1)[:, :frame]
    corr /= np.maximum(corr[:, :1], 1e-12)
    shortest, longest = int(rate / high), int(rate / low)
    lags = shortest + np.argmax(corr[:, shortest:longest], axis=1)
    voiced = lags[corr[np.arange(len(lags)), lags] > 0.45]
    return float(np.median(rate / voiced)) if voiced.size else 0.0


def make_whole(text, takes, seed, spent):
    """A whole line at 48 kHz: `takes` takes, and of those that fit (their length for their letters,
    within a fifth of their middle length, nothing broken), the lowest-pitched. Made again, up to twice
    more, while none fits.

    ~~The middle one by length~~ (the voice chat's names_test.py way): Theo's calm lines come out higher
    from Pocket TTS than from Qwen (147 Hz against 120 to 138, the voice chat, 2026-11-17), and of its 54
    lines of 3 takes the lowest-pitched within a fifth of the middle length scored 3.80 on UTMOS against
    3.72 and sat at 141 Hz against 148, its words right in 46 against 48 (the check by ear catches those,
    voicebox.WHOLE_HEAR)."""
    letters = max(1, len(re.findall(r"\w", text)))
    made, tried = [], 0
    while tried < takes + 2:
        began = time.monotonic()
        audio = say_whole(text, seed + tried * 7)
        spent["pocket"] = spent.get("pocket", 0.0) + time.monotonic() - began
        tried += 1
        seconds = trim(audio, POCKET_RATE).size / POCKET_RATE
        why = broken(audio, POCKET_RATE)
        fits = why is None and SHORTEST_FOR_LETTERS * letters <= seconds <= LONGEST_FOR_LETTERS * letters + 1.0
        if why:
            spent.setdefault("broken", []).append(why)
        made.append((fits, seconds, audio))
        spent.setdefault("takes", []).append(round(seconds, 2))
        if len(made) >= takes and any(take[0] for take in made):
            break

    lengths = sorted(take[1] for take in made if take[0])
    middle = lengths[(len(lengths) - 1) // 2] if lengths else 0
    if len(lengths) >= 3:
        made = [take if not take[0] or abs(take[1] - middle) <= 0.2 * middle else (False, *take[1:]) for take in made]
    fitting = [take for take in made if take[0]] or made[:1]
    pitches = [median_pitch(take[2], POCKET_RATE) for take in fitting]
    spent["pitches"] = [round(pitch) for pitch in pitches]
    picked = fitting[min(range(len(fitting)), key=lambda at: pitches[at] or 999)][2]


    picked = sosfilt(_HIGH_PASS, picked).astype(np.float32)
    line = cap_pauses(trim(even(picked), POCKET_RATE), POCKET_RATE)
    spent["picked"] = round(line.size / POCKET_RATE, 2)
    if not line.size:
        return np.zeros(0, dtype=np.float32)
    quiet = np.zeros(int(EDGE * POCKET_RATE), dtype=np.float32)
    line = resample_poly(np.concatenate([quiet, line, quiet]), RATE, POCKET_RATE).astype(np.float32)
    peak = float(np.max(np.abs(line))) or 1.0
    return (line * min(1.0, 0.97 / peak)).astype(np.float32)


def say(text, seed):
    """`text` in Theo's voice, at 24 kHz, kept for the next ask of the same words."""
    key = (text, seed)
    with _said_lock:
        if key in _said:
            _said.move_to_end(key)
            return _said[key]
    torch = model["torch"]
    with speaking, torch.no_grad():
        torch.manual_seed(int(seed))
        audio = model["tts"].generate_audio(model["voice"], text).numpy().astype(np.float32)
    with _said_lock:
        _said[key] = audio
        while len(_said) > 64:
            _said.popitem(last=False)
    return audio


def through_codec(audio):
    """A clip (24 kHz) through Pocket TTS's codec and the retrained decoder, as a name is."""
    torch = model["torch"]
    with speaking, torch.no_grad():
        mimi = model["tts"].mimi
        latent = mimi.encode_to_latent(torch.from_numpy(np.ascontiguousarray(audio))[None, None])
        back = mimi.decode_from_latent(latent, model["init_states"](mimi, batch_size=1,
                                                                     sequence_length=latent.shape[1] * 16 + 64))
    return back[0, 0].numpy().astype(np.float32)





def read_clip(path):
    audio, rate = soundfile.read(path, dtype="float32", always_2d=False)
    if audio.ndim > 1:
        audio = audio.mean(axis=1)
    if rate != RATE:
        audio = resample_poly(audio, RATE, rate).astype(np.float32)
    return audio


def even(audio):
    """The voiced parts at the bank's level (make_pack.py), peaks under 0.97."""
    voiced = audio[np.abs(audio) > 0.01]
    rms = float(np.sqrt(np.mean(voiced ** 2))) if voiced.size else 0.0
    gain = LOUDNESS / rms if rms > 0 else 1.0
    return audio * min(gain, 0.97 / max(1e-9, float(np.abs(audio).max())))


def trim(audio, rate, start_under=40.0, end_under=50.0, keep=0.06, fade=0.03, rises_to=20.0, rises_within=0.06):
    """Quiet off both ends, keeping each word's own fade (Tools/DJBank/models/pocket-tts/join.py's rule,
    9b00ba1). In 10 ms steps against the loudest: from where the voice first comes within `start_under` dB
    and goes on to come within `rises_to` dB inside `rises_within` s, to where it last falls `end_under` dB
    below (a word's fade is slow, its start sharp), `keep` more each side, faded in and out over `fade` so
    no piece starts or stops mid-wave. A piece with nothing above 0.01 is none."""







    if not audio.size or float(np.abs(audio).max()) <= 0.01:
        return audio[:0]
    step = max(1, int(0.01 * rate))
    frames = max(1, len(audio) // step)
    padded = np.zeros(frames * step, dtype=np.float64)
    padded[:min(len(audio), padded.size)] = audio[:padded.size]
    level = np.sqrt(np.mean(padded.reshape(frames, step) ** 2, axis=1))
    near = np.flatnonzero(level > level.max() * 10 ** (-start_under / 20))
    voiced = level > level.max() * 10 ** (-rises_to / 20)
    ahead = int(round(rises_within / 0.01)) + 1
    first = next((frame for frame in near if voiced[frame:frame + ahead].any()), near[0])
    last = np.flatnonzero(level > level.max() * 10 ** (-end_under / 20))[-1]
    out = audio[max(0, first * step - int(keep * rate)):min(len(audio), (last + 1) * step + int(keep * rate))].copy()
    ramp = min(int(fade * rate), out.size // 2)
    if ramp:
        curve = (np.sin(np.linspace(0, np.pi / 2, ramp)) ** 2).astype(out.dtype)
        out[:ramp] *= curve
        out[-ramp:] *= curve[::-1]
    return out


def _biquad(kind, rate, frequency, q, gain_db=0.0):
    """RBJ's cookbook filters, as BS.1770's K-weighting is made at any rate (pyloudnorm's way)."""
    a_gain = 10 ** (gain_db / 40)
    w0 = 2 * np.pi * frequency / rate
    alpha = np.sin(w0) / (2 * q)
    cos = np.cos(w0)
    if kind == "high_shelf":
        root = 2 * np.sqrt(a_gain) * alpha
        b = [a_gain * ((a_gain + 1) + (a_gain - 1) * cos + root), -2 * a_gain * ((a_gain - 1) + (a_gain + 1) * cos),
             a_gain * ((a_gain + 1) + (a_gain - 1) * cos - root)]
        a = [(a_gain + 1) - (a_gain - 1) * cos + root, 2 * ((a_gain - 1) - (a_gain + 1) * cos),
             (a_gain + 1) - (a_gain - 1) * cos - root]
    else:
        b = [(1 + cos) / 2, -(1 + cos), (1 + cos) / 2]
        a = [1 + alpha, -2 * cos, 1 - alpha]
    return np.array(b) / a[0], np.array(a) / a[0]


def lufs(audio, rate):
    """How loud it sounds (ITU-R BS.1770-4: K-weighted, 400 ms blocks, gated at -70 LUFS and 10 LU under)."""
    weighted = audio.astype(np.float64)
    for kind, frequency, q, gain in (("high_shelf", 1681.974450955533, 0.7071752369554193, 3.99984385397),
                                     ("high_pass", 38.13547087613982, 0.5003270373253953, 0.0)):
        b, a = _biquad(kind, rate, frequency, q, gain)
        weighted = lfilter(b, a, weighted)
    block, step = int(0.4 * rate), int(0.1 * rate)
    if weighted.size < block:
        weighted = np.concatenate([weighted, np.zeros(block - weighted.size)])
    powers = np.array([np.mean(weighted[at:at + block] ** 2) for at in range(0, weighted.size - block + 1, step)])
    loudness = -0.691 + 10 * np.log10(powers + 1e-12)
    kept = powers[loudness > -70]
    if not kept.size:
        return -70.0
    relative = -0.691 + 10 * np.log10(np.mean(kept)) - 10
    kept = powers[(loudness > -70) & (loudness > relative)]
    return float(-0.691 + 10 * np.log10(np.mean(kept if kept.size else powers) + 1e-12))


def make_line(pieces, codec, seed, spent):
    """The line's samples at 48 kHz from its pieces (see the top)."""
    made = []
    for index, piece in enumerate(pieces):
        if "clip" in piece:
            began = time.monotonic()
            audio = read_clip(piece["clip"])
            spent["reading"] = spent.get("reading", 0.0) + time.monotonic() - began
            if codec:
                began = time.monotonic()
                audio = through_codec(resample_poly(audio, POCKET_RATE, RATE).astype(np.float32))
                spent["codec"] = spent.get("codec", 0.0) + time.monotonic() - began
                made.append(("clip", trim(even(audio), POCKET_RATE)))
            else:
                made.append(("clip", trim(audio, RATE)))
        else:
            began = time.monotonic()
            audio = say(piece["say"], seed + index * 7)
            spent["pocket"] = spent.get("pocket", 0.0) + time.monotonic() - began
            spent["newWords"] = spent.get("newWords", 0) + len(piece["say"].split())
            made.append(("say", trim(even(audio), POCKET_RATE)))
    rate = POCKET_RATE if codec else RATE
    made = [(kind, audio) for kind, audio in made if audio.size]
    if not made:
        return np.zeros(0, dtype=np.float32)
    clips = [audio for kind, audio in made if kind == "clip"]
    if clips and any(kind == "say" for kind, _ in made):

        target = float(np.mean([lufs(audio, rate) for audio in clips]))
        for at, (kind, audio) in enumerate(made):
            if kind == "say":
                gain = 10 ** ((target - lufs(audio, rate)) / 20)
                made[at] = (kind, audio * min(gain, 0.97 / max(1e-9, float(np.abs(audio).max()))))
    quiet = lambda seconds: np.zeros(int(seconds * rate), dtype=np.float32)
    joined = [quiet(EDGE)]
    for at, (_, audio) in enumerate(made):
        joined += [audio, quiet(PAUSE if at < len(made) - 1 else EDGE)]
    line = np.concatenate(joined)
    if rate != RATE:
        line = resample_poly(line, RATE, rate).astype(np.float32)
    peak = float(np.max(np.abs(line))) or 1.0
    return (line * min(1.0, 0.97 / peak)).astype(np.float32)





class Handler(BaseHTTPRequestHandler):
    def log_message(self, *_):
        pass

    def _send(self, status, body, kind="application/json", headers=None):
        self.send_response(status)
        self.send_header("Content-Type", kind)
        for name, value in (headers or {}).items():
            self.send_header(name, value)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        state["heard_from"] = time.monotonic()
        if self.path == "/ready":
            self._send(200, json.dumps({"bank": True, "loaded": state["loaded"], "error": state["error"],
                                        "whole": bool(state.get("whole"))}).encode())
        else:
            self._send(404, b"{}")

    def do_POST(self):
        state["heard_from"] = time.monotonic()
        length = int(self.headers.get("Content-Length") or 0)
        asked = json.loads(self.rfile.read(length) or b"{}")
        if self.path == "/beat":
            self._send(200, b"{}")
            return
        if self.path == "/whole":
            self._whole(asked)
            return
        if self.path != "/line":
            self._send(404, b"{}")
            return
        pieces = asked.get("pieces") or []
        new_words = any("say" in piece for piece in pieces)
        began = time.monotonic()
        if new_words:
            loaded.wait(max(0.0, float(asked.get("wait", 0))))
            if not state["loaded"]:
                self._send(503, json.dumps({"error": state["error"] or "Pocket TTS is still loading",
                                            "loading": state["error"] is None}).encode())
                return
        spent = {"loading": time.monotonic() - began, "threads": state["threads"]}
        try:
            samples = make_line(pieces, bool(asked.get("codec")) and new_words, int(asked.get("seed", 1)), spent)
        except Exception as error:
            self._send(500, json.dumps({"error": f"{type(error).__name__}: {error}"}).encode())
            return
        finally:
            state["heard_from"] = time.monotonic()
        spent["total"] = time.monotonic() - began
        self._send(200, samples.tobytes(), "application/octet-stream", {"X-Spent": json.dumps(spent)})


    def _whole(self, asked):
        text = " ".join(str(asked.get("text", "")).split())
        if not text:
            self._send(400, json.dumps({"error": "A line with no words."}).encode())
            return
        began = time.monotonic()
        loaded.wait(max(0.0, float(asked.get("wait", 0))))
        if not state["loaded"]:
            self._send(503, json.dumps({"error": state["error"] or "Pocket TTS is still loading",
                                        "loading": state["error"] is None}).encode())
            return
        if model["whole_voice"] is None:
            self._send(404, json.dumps({"error": "No voice for whole lines."}).encode())
            return
        spent = {"loading": time.monotonic() - began, "threads": args.whole_threads or state["threads"]}
        try:
            samples = make_whole(text, max(1, min(int(asked.get("takes", 1)), 5)), int(asked.get("seed", 1)), spent)
        except Exception as error:
            self._send(500, json.dumps({"error": f"{type(error).__name__}: {error}"}).encode())
            return
        finally:
            state["heard_from"] = time.monotonic()
        spent["total"] = time.monotonic() - began
        self._send(200, samples.tobytes(), "application/octet-stream", {"X-Spent": json.dumps(spent)})


def watch():


    while True:
        time.sleep(5)
        if not speaking.locked() and time.monotonic() - state["heard_from"] > args.idle:
            print("No word from the plugin; stopping", flush=True)
            os._exit(0)


threading.Thread(target=load, daemon=True).start()
threading.Thread(target=watch, daemon=True).start()
ThreadingHTTPServer(("127.0.0.1", args.port), Handler).serve_forever()
