













import gzip
import json
import os
import shutil
import threading
import time

from flask import Blueprint, Response, current_app, g, jsonify, make_response, redirect, request, url_for
from werkzeug.datastructures import ImmutableMultiDict

from plugin.api import config, get_db, logger, render_page

from . import analysis, bank_setup, engine, feel, files, gate, page, store

VERSION = "1.9.0"
bp = Blueprint("audity_dj", __name__)
DEFAULT_VOICE = "male"

THEO = {"id": DEFAULT_VOICE, "name": "Theo", "detail": "Deep and warm", "isDefault": True}
WAIT_LONGEST = 8.0


@bp.before_request
def _admins_only():
    """Everything here but the app's own routes (gate.py answers those, signed in with the music
    server) is the server owner's: the voice's download, the voices, who uses the DJ. AudioMuse-AI
    keeps only a plugin's settings page to its admins and opens the rest of a plugin's pages to anyone
    signed in to it, so the rest is kept to its admins here."""
    if request.path.startswith(gate.PREFIX):
        return None
    if not getattr(config, "AUTH_ENABLED", True) or g.get("auth_role") == "admin":
        return None
    return jsonify(error="Only an AudioMuse-AI admin can do this."), 403


def _listener():
    return gate.listener()


def _account():
    return {"server": gate.server_id() or "", "listener": _listener()}





_KEPT_HEADERS = ("Content-Type", "Content-Encoding", "ETag", "Vary", "X-Audity-Line")


def _starting(down):
    return jsonify(error=str(down) or "The DJ is starting. Try again in a moment.", starting=True,
                   reason="dj-starting"), 503


def _passed(answer):
    """The engine's answer, as it sent it, to the app."""
    body = answer.raw.read(decode_content=False)
    response = Response(body, status=answer.status_code)
    for name in _KEPT_HEADERS:
        if name in answer.headers:
            response.headers[name] = answer.headers[name]
    return response


def _pass(method, path, timeout=30, **sent):
    try:
        return _passed(engine.ask(method, path, timeout=timeout, **sent))
    except engine.EngineDown as down:
        return _starting(down)


def _engine_status(listener=None):
    """The engine's {"voice", "bank", "voices", "recent", "library", ...}, or None while it starts."""
    try:
        answer = engine.ask("GET", "/status", params={"server": gate.server_id() or "", "listener": listener}
                            if listener is not None else None, timeout=10)
        return answer.json() if answer.status_code == 200 else None
    except (engine.EngineDown, ValueError):
        return None


def _session_while_starting():
    """A DJ session's state as box.status gave it, while the engine starts: not running."""
    return {"running": False, "loaded": False, "warming": False, "since": None, "listeners": [], "waiting": 0,
            "engine": "bank" if bank_setup.is_ready() else None, "names": None, "namesError": None,
            "error": engine.status()["error"], "alwaysOn": bank_setup.is_ready()}




@bp.route("/app/hello")
def app_hello():
    listener = _listener()
    status = _engine_status(listener)
    return jsonify({
        "plugin": "audity_dj",
        "version": VERSION,
        "voice": _voice_status(),
        "voices": (status or {}).get("voices") or [THEO],
        "picked": DEFAULT_VOICE,
        "session": status["voice"] if status else _session_while_starting(),

        "canDownload": gate.is_admin(),
        "diskGB": bank_setup.DISK_GB,



        "bank": (status or {}).get("bank"),

        "memory": {"version": 2},


        "asks": {"version": 1, "library": (status or {}).get("library"), "feel": _feel_status()},

        "said": {"version": 1},


        "facts": {"version": 1, "artists": bank_setup.FACTS["id"] if bank_setup.facts_ready() else None},

        "engine": engine.status(),
    })


_feel = {"at": 0.0, "status": None}


def _feel_status():
    if time.monotonic() - _feel["at"] > 60 or _feel["status"] is None:
        try:
            _feel["status"] = feel.feel_status()
        except Exception as error:
            _feel["status"] = {"ready": False, "why": f"{type(error).__name__}: {error}"}
        _feel["at"] = time.monotonic()
    return _feel["status"]


def _voice_status():
    """The DJ's voice as the app sees it: Theo's bank, ready once it's downloaded, else its download's state.
    "newer" when an update can be downloaded, the bank or the artists' facts or both, as one of "updateBytes";
    "updating" while it comes down, the bank talking meanwhile (POST /app/voice/download starts it)."""


    raw = bank_setup.status()
    ready = bank_setup.is_ready()
    state = dict(raw, state="ready") if ready else raw
    return {"state": state.get("state"), "step": state.get("step"),
            "fraction": state.get("fraction", 0.0), "error": state.get("error"),
            "newer": bool(raw.get("newer")), "updateBytes": raw.get("updateBytes", 0),
            "updating": ready and raw.get("state") == "downloading"}


@bp.route("/app/voice", methods=["POST"])
def app_voice():
    listener = _listener()
    voice_id = (request.get_json(silent=True) or {}).get("id", "")
    if voice_id != DEFAULT_VOICE:
        return jsonify(error="No such voice."), 404

    store.set_voice(listener, voice_id)
    return jsonify(picked=DEFAULT_VOICE)


@bp.route("/app/voice/download", methods=["POST"])
def app_download():
    """The voice's download started (or stopped) from the app's DJ page, by an admin of the server, so
    there's nothing to do on this page at all once the plugin's installed."""
    if not gate.is_admin():
        return jsonify(error="Only an admin of your music server can download the DJ's voice."), 403
    if (request.get_json(silent=True) or {}).get("action") == "stop":
        bank_setup.stop()
    elif not bank_setup.is_ready() or bank_setup.status().get("newer"):

        bank_setup.start()
    return jsonify(voice=_voice_status())


@bp.route("/app/session/hold", methods=["POST"])
def app_hold():
    try:
        answer = engine.ask("POST", "/hold", json={"listener": _listener()})
    except engine.EngineDown as down:
        return _starting(down)
    if answer.status_code == 409:
        return jsonify(error="The DJ's voice isn't downloaded on the server yet.", voice=_voice_status()), 409
    _warm_feel()
    return _passed(answer)


def _warm_feel():
    """AudioMuse-AI's text search kept loaded while a DJ session is on (`feel.warm`), off this request."""
    app = current_app._get_current_object()

    def warm():
        with app.app_context():
            feel.warm()
    threading.Thread(target=warm, name="audity-dj-warm-feel", daemon=True).start()


@bp.route("/app/session/release", methods=["POST"])
def app_release():
    return _pass("POST", "/release", json={"listener": _listener()})




@bp.route("/app/library", methods=["POST"])
def app_library():
    """The account's song list, as the app's reader read it: {"version", "songs": [{"id", "title", "artist",
    "artistId", "album", "albumId", "genre", "genres", "moods", "year", "albumYear"}]}, gzip'd or not, in the app's
    order. Kept on the disk by the engine until the next."""
    headers = {"Content-Encoding": request.headers["Content-Encoding"]} if "Content-Encoding" in request.headers else {}
    return _pass("POST", "/library", params=_account(), data=request.get_data(cache=False), headers=headers, timeout=120)


@bp.route("/app/ask", methods=["POST"])
def app_request():
    """A request, read: {"text", "alternatives", "playing" (the song's id), "now" (the phone's time with its offset)}
    answered {"request" (HostRequest's fields, or null), "heard", "feelSongs", "feelWhy", "took", "library"}. 409
    when the account's library hasn't been sent."""
    began = time.monotonic()
    asked = dict(request.get_json(silent=True) or {}, **_account())
    try:
        answer = engine.ask("POST", "/ask", json=asked)
        if answer.status_code != 200:
            return _passed(answer)
        read = answer.json()
        words = read.pop("feel", None)
        feel_songs, why = [], read.pop("why", None)
        if words:


            try:
                results, why = feel.search(words)
            except Exception as error:
                results, why = [], f"AudioMuse-AI's text search failed: {type(error).__name__}: {error}"
            if results:
                kept = engine.ask("POST", "/ask/feel", json=dict(_account(), results=results, leaveOut=asked.get("playing")))
                feel_songs = kept.json().get("feelSongs", []) if kept.status_code == 200 else []
    except engine.EngineDown as down:
        return _starting(down)
    read.update(feelSongs=feel_songs, feelWhy=why, took=round(time.monotonic() - began, 3))
    logger.info("Audity DJ: a request read in %.2f s: %r as %s%s", read["took"], read["heard"],
                "nothing" if read["request"] is None else ", ".join(key for key, value in read["request"].items()
                                                                     if value and key not in ("without", "reply")) or "a feel",
                f", {len(feel_songs)} songs by feel" if feel_songs else "")
    return jsonify(read)




@bp.route("/app/names", methods=["POST"])
def app_names():
    """The next songs' name sentences, as the app will ask for them in its lines ({"say": [sentence]}): what of each
    the bank hasn't is said by Pocket TTS while no line waits, and kept, so their lines are made at once. Answered
    {"queued": n, "seconds": {sentence: s}}, each sentence made already with how long it lasts in a line (hello's
    bank "edge" and "pause" aside), so the app can pick a line that ends before the singing; asked again, the rest."""
    return _pass("POST", "/names", json={"say": (request.get_json(silent=True) or {}).get("say")})


@bp.route("/app/lines", methods=["POST"])
def app_ask():
    asked = dict(request.get_json(silent=True) or {}, listener=_listener())
    return _pass("POST", "/lines", json=asked)


@bp.route("/app/lines/<job_id>", methods=["GET", "DELETE"])
def app_line(job_id):


    wait = request.args.get("wait", type=float)
    params = {"listener": _listener(), **({"wait": min(max(wait, 0), WAIT_LONGEST)} if wait else {})}
    return _pass(request.method, f"/lines/{job_id}", params=params, timeout=WAIT_LONGEST + 20)


@bp.route("/app/bank")
def app_bank():
    """The bank in use, sentence by sentence, for an app that writes its lines with them: sent back with its exact
    words, each is its clip at once, and only the name sentence beside it is said by Pocket TTS. A new bank comes with
    no change to the app. Its ETag is the bank's, so an app that has it gets a 304; gzip'd for an app that takes it."""
    headers = {name: request.headers[name] for name in ("If-None-Match", "Accept-Encoding") if name in request.headers}
    return _pass("GET", "/bank", headers=headers, timeout=120)


@bp.route("/app/voices/<voice_id>/clip")
def app_clip(voice_id):
    return _pass("GET", f"/voices/{voice_id}/clip")




def _json(answer):
    """`answer` as JSON, gzip'd for an app that takes it (URLSession does): release 2's sentences heard run to
    megabytes."""
    body = json.dumps(answer, ensure_ascii=False, separators=(",", ":")).encode()
    zipped = "gzip" in request.headers.get("Accept-Encoding", "").lower() and len(body) > 1024
    response = make_response(gzip.compress(body, 6) if zipped else body)
    response.mimetype = "application/json"
    response.headers["Vary"] = "Accept-Encoding"
    if zipped:
        response.headers["Content-Encoding"] = "gzip"
    return response


@bp.route("/app/said", methods=["GET", "POST"])
def app_said():
    """Every sentence this account heard (store.remember_said): POST {"said": [{"key", "at"}]} adds them (2,000 a call
    at most), GET ?since=<unix seconds> gives {"said": {key: at}, "count", "now"} heard after `since`, all of them
    without it."""
    listener = _listener()
    if request.method == "POST":
        said = (request.get_json(silent=True) or {}).get("said")
        if not isinstance(said, list) or len(said) > 2000 or not all(isinstance(item, dict) for item in said):
            return jsonify(error="said is a list of up to 2,000 {key, at}."), 400
        count = store.remember_said(listener, [(item.get("key"), item.get("at")) for item in said])
        return jsonify(kept=len(said), count=count)
    since = request.args.get("since")
    try:
        since = float(since) if since not in (None, "") else None
    except ValueError:
        return jsonify(error="since is unix seconds."), 400
    now = time.time()
    said = store.said_since(listener, since)
    return _json({"said": said, "count": len(said) if since is None else None, "now": now})


@bp.route("/app/memory", methods=["GET", "POST"])
def app_memory():
    """What the DJ remembers of this account (store.py). The last lines and the last 3 days' songs, as before:
    {"voice", "lines", "songs"}. And the DJ's history, kept for good (hello's "memory" version 2): POST adds
    "heard": [{"recording", "at", "device", "skipped"}], each song the DJ played, and "ideas": [{"idea", "at", "by",
    "device"}], each set's, 2,000 of each a call at most (sent again, nothing's kept twice; a song's "skipped" and
    "device" may come later); GET ?since=<unix seconds> gives those after `since` too, oldest first, with "now", and
    "next" where there's more: the `since` to read on from."""
    listener = _listener()
    if request.method == "GET":
        answer = store.memory(listener)
        since = request.args.get("since")
        if since not in (None, ""):
            try:
                since = float(since)
            except ValueError:
                return jsonify(error="since is unix seconds."), 400
            now = time.time()
            answer.update(store.history_since(listener, since), now=now)
        return _json(answer)
    asked = request.get_json(silent=True) or {}
    lines = asked.get("lines") or []
    songs = asked.get("songs") or {}
    heard = asked.get("heard") or []
    ideas = asked.get("ideas") or []
    if not isinstance(lines, list) or not isinstance(songs, dict):
        return jsonify(error="lines is a list, songs a dictionary."), 400
    for name, items in (("heard", heard), ("ideas", ideas)):
        if not isinstance(items, list) or len(items) > 2000 or not all(isinstance(item, dict) for item in items):
            return jsonify(error=f"{name} is a list of up to 2,000 dictionaries."), 400
    answer = store.remember(listener, lines[-60:], dict(list(songs.items())[-3000:]))
    if heard or ideas:
        answer["kept"] = store.remember_history(listener, heard, ideas)
    return jsonify(answer)


@bp.route("/app/artists", methods=["POST"])
def app_artists():
    """What the facts file has on each artist (the engine's artists.py, FACTS.md): POST {"artists": [{"mbid", "name",
    "albums"}]}, up to 500, answered {"artists": {"<name asked>": facts or null}, "file"}; 404 with needsDownload while
    the file isn't downloaded."""
    asked = dict(_account(), artists=(request.get_json(silent=True) or {}).get("artists"))
    headers = {"Accept-Encoding": request.headers["Accept-Encoding"]} if "Accept-Encoding" in request.headers else {}
    return _pass("POST", "/artists", json=asked, headers=headers, timeout=60)


@bp.route("/app/facts", methods=["POST"])
def app_facts():
    """AudioMuse-AI's analysis of each song, as the lines say it (analysis.songs, FACTS.md): POST {"songs": ["<id>"]}, up
    to 2,000, answered {"songs": {"<id>": {"bpm", "pace", "paceSure", "key", "scale", "energy", "moods"}}}, a song
    not analyzed left out."""
    ids = (request.get_json(silent=True) or {}).get("songs")
    if not isinstance(ids, list) or len(ids) > analysis.SONGS_MOST or not all(isinstance(each, str) for each in ids):
        return jsonify(error="songs is a list of up to 2,000 song ids."), 400
    try:
        answer = analysis.songs(ids, get_db)
    except Exception as error:
        logger.exception("Audity DJ: a song's facts")
        return jsonify(error=f"AudioMuse-AI's analysis couldn't be read: {type(error).__name__}"), 503
    return _json({"songs": answer})






def _audiomuse_view(name):
    for view in current_app.view_functions.values():
        if getattr(view, "__name__", "") == name:
            return view
    return None


@bp.route("/app/similar")
def app_similar():
    view = _audiomuse_view("get_similar_tracks_endpoint")
    if view is None:
        return jsonify(error="This AudioMuse-AI can't find songs by sound."), 501
    _for_this_server(("item_id", "n", "eliminate_duplicates"), most=SIMILAR_MOST)
    return current_app.ensure_sync(view)()





SIMILAR_MOST = 100


def _for_this_server(allowed, most=None):
    """AudioMuse-AI's own answer asked of the server the app signed in to, by its IDs, rather than
    its default one, where it's connected to more than one, and never of another: `server` is always
    the sign-in's. Only the arguments the app sends (`allowed`) go through, with `n` at most `most`."""
    args = {key: request.args.getlist(key)[:1] for key in allowed if request.args.get(key) is not None}
    if most is not None and "n" in args:
        try:
            args["n"] = [str(max(1, min(int(args["n"][0]), most)))]
        except ValueError:
            args.pop("n")
    server = gate.server_id()
    if server:
        args["server"] = [server]
    request.args = ImmutableMultiDict(args)


@bp.route("/app/path")
def app_path():
    view = _audiomuse_view("find_path_endpoint")
    if view is None:
        return jsonify(error="This AudioMuse-AI can't find paths between songs."), 501
    _for_this_server(("start_song_id", "end_song_id", "max_steps"))
    return current_app.ensure_sync(view)()




@bp.route("/")
def home():
    return render_page(page.html(VERSION), title="Audity DJ")


def _log_tail(name, lines=20):
    try:
        with open(files.folder(name), errors="replace") as file:
            return file.read()[-6000:].splitlines()[-lines:]
    except OSError:
        return []


@bp.route("/status.json")
def status_json():
    fast = bank_setup.status()
    status = _engine_status()
    pack = bank_setup.pack()
    return jsonify({
        "voice": {"state": fast.get("state"), "step": fast.get("step"), "fraction": fast.get("fraction", 0.0),
                  "error": fast.get("error"), "needsToken": bool(fast.get("needsToken")),
                  "ready": bank_setup.is_ready(), "newer": bool(fast.get("newer")),
                  "factsNew": bool(fast.get("factsNew")), "updateBytes": fast.get("updateBytes", 0),
                  "factsError": fast.get("factsError"),
                  "bankNew": bool(fast.get("newer")) and fast.get("pack") != bank_setup.PACK["id"],
                  "pack": pack.get("id"), "clips": len(pack.get("clips", [])),
                  "diskBytes": bank_setup.disk_bytes() if bank_setup.is_ready() else 0,
                  "diskGB": bank_setup.DISK_GB, "engine": "bank" if bank_setup.is_ready() else None},
        "session": status["voice"] if status else _session_while_starting(),
        "engine": engine.status(),

        "recent": (status or {}).get("recent") or [],
        "voiceLog": _log_tail("voice.log"),
        "voiceLogBefore": _log_tail("voice.log.1", 8),
        "listeners": _listeners(),
    })


def _listeners():
    """Each account that's used the DJ, with how many songs it's played them (the DJ's history, store.py)."""
    played = store.history_counts()
    return [dict(row, updated=row["updated"].isoformat() if row["updated"] else None, played=played.get(row["username"], 0))
            for row in store.listeners()]


@bp.route("/download", methods=["POST"])
def download():
    action = request.form.get("action", "start")
    if action == "start":

        bank_setup.start(request.form.get("token"))
    elif action == "stop":
        bank_setup.stop()
    elif action == "remove":
        try:
            engine.ask("POST", "/release-all", json={}).close()
        except engine.EngineDown:
            pass
        bank_setup.remove()
    return redirect(url_for("audity_dj.home"))




@bp.route("/try", methods=["POST"])
def try_line():
    text = " ".join(str((request.get_json(silent=True) or {}).get("text", "")).split())[:600]
    if not text:
        return jsonify(error="Type a line."), 400
    try:
        answer = engine.ask("POST", "/try", json={"text": text})
    except engine.EngineDown as down:
        return _starting(down)
    if answer.status_code == 409:
        return jsonify(error="Download the voice first."), 409
    return _passed(answer)


@bp.route("/try/<job_id>")
def try_result(job_id):
    return _pass("GET", f"/try/{job_id}", params={"done": request.args.get("done")} if request.args.get("done") else None)






_EARLIER = ("neutts", "neutts.json", "ming", "ming.new", "env", "voice.json")


def _clear_earlier():
    for name in _EARLIER:
        path = files.folder(name)
        try:
            if os.path.isdir(path):
                shutil.rmtree(path)
                logger.info("Audity DJ: %s, from a voice before the bank, removed", name)
            elif os.path.isfile(path):
                os.remove(path)
        except OSError:
            logger.exception("Audity DJ: %s couldn't be removed", name)


def _on_start():
    store.migrate()
    gate.install(current_app._get_current_object())


    engine.start()
    threading.Thread(target=_clear_earlier, name="audity-dj-clear-earlier", daemon=True).start()
    logger.info("Audity DJ %s is ready for the app at /plugins/audity_dj/app/", VERSION)


def register(ctx):
    ctx.add_blueprint(bp)
    ctx.add_menu_item("Audity DJ", "audity_dj.home", admin_only=True)
    ctx.set_settings_page("audity_dj.home")
    ctx.on_install(store.migrate)
    ctx.on_flask_start(_on_start)
