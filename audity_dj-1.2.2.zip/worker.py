














import argparse
import json
import os
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

parser = argparse.ArgumentParser()
parser.add_argument("--port", type=int, required=True)
parser.add_argument("--ming", required=True, help="Ming-3.0-tts's code")
parser.add_argument("--model", required=True, help="Ming's weights, a folder")
parser.add_argument("--threads", type=int, default=0)
parser.add_argument("--idle", type=float, default=90, help="seconds without a word from the plugin before it stops")


parser.add_argument("--precision", choices=("float32", "bfloat16"), default="float32")
args = parser.parse_args()

sys.path.insert(0, args.ming)

import contextlib
import gc

import numpy as np
import torch
import torchaudio

if args.threads > 0:
    torch.set_num_threads(args.threads)




SAMPLE_RATE = 44_100
state = {"loaded": False, "error": None, "heard_from": time.monotonic()}
speaking = threading.Lock()
tts = None


def load():
    global tts
    try:
        from ming_tts import MingTTS

        began = time.monotonic()
        made = MingTTS(args.model, device="cpu", text_normalization=False)
        if args.precision == "float32":


            made.model.float()

            @torch.inference_mode()
            def encode_in_full_precision(waveform):


                waveform = waveform.to(device=made.model.device, dtype=torch.float32)
                length = torch.tensor([waveform.size(1)], dtype=torch.long, device=made.model.device)
                return made.model.audio.encode_latent(waveform, length)[0]

            made.model.encode_prompt_latent = encode_in_full_precision
        gc.collect()
        _time_parts(made)
        tts = made
        state["loaded"] = True
        print(f"Voice loaded in {time.monotonic() - began:.0f} s", flush=True)
    except Exception as error:
        state["error"] = f"{type(error).__name__}: {error}"
        print(f"Voice failed to load: {state['error']}", flush=True)





spent = {}


def _time_parts(made):
    def add(part, seconds):
        spent[part] = spent.get(part, 0.0) + seconds

    began = {}
    language_model = made.model.model
    language_model.register_forward_pre_hook(lambda *_: began.__setitem__("step", time.monotonic()))

    def stepped(*_):
        add("languageModel", time.monotonic() - began["step"])
        spent["steps"] = spent.get("steps", 0) + 1

    language_model.register_forward_hook(stepped)
    for owner, name, part in ((made.model.flowloss, "sample", "flowHead"), (made.model.audio, "decode", "decoder")):
        def timed(*arguments, _call=getattr(owner, name), _part=part, **named):
            start = time.monotonic()
            try:
                return _call(*arguments, **named)
            finally:
                add(_part, time.monotonic() - start)
        setattr(owner, name, timed)


def say(text, clips, seed):
    paths = [clip["path"] for clip in clips]
    words = " ".join(clip["words"].strip() for clip in clips)
    prompt = paths if len(paths) > 1 else paths[0]
    with speaking:
        spent.clear()
        spent["threads"] = torch.get_num_threads()
        if args.precision == "bfloat16":



            tts.prepare_prompt(prompt, True)
            mixing = torch.autocast("cpu", dtype=torch.bfloat16)
        else:
            mixing = contextlib.nullcontext()
        torch.manual_seed(int(seed))
        with mixing:
            wave = tts.synthesize(task="TTS", text=text, language_id="English", prompt_wav_path=prompt,
                                  prompt_text=words, use_spk_emb=True)
    wave = wave.float().cpu()
    if wave.dim() > 1:
        wave = wave.mean(dim=0)






    held = int(0.1 * tts.sample_rate)
    wave = torch.cat([wave[:1].repeat(held), wave, wave[-1:].repeat(held)])
    wave = torchaudio.functional.highpass_biquad(wave, tts.sample_rate, 50.0)[held:-held]
    wave = torchaudio.functional.resample(wave, tts.sample_rate, SAMPLE_RATE)
    return wave.numpy().astype(np.float32)


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *_):
        pass

    def _send(self, status, body, kind="application/json", headers=None):
        self.send_response(status)
        self.send_header("Content-Type", kind)
        for name, value in (headers or {}).items():
            self.send_header(name, value)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        state["heard_from"] = time.monotonic()
        if self.path == "/ready":
            self._send(200, json.dumps({"loaded": state["loaded"], "error": state["error"]}).encode())
        else:
            self._send(404, b"{}")

    def do_POST(self):
        state["heard_from"] = time.monotonic()
        length = int(self.headers.get("Content-Length") or 0)
        asked = json.loads(self.rfile.read(length) or b"{}")
        if self.path == "/beat":
            self._send(200, b"{}")
        elif self.path == "/say":
            if not state["loaded"]:
                self._send(503, json.dumps({"error": state["error"] or "loading"}).encode())
                return
            try:
                began = time.monotonic()
                samples = say(asked["text"], asked["clips"], asked.get("seed", 1))
                parts = dict(spent, total=time.monotonic() - began)
            except Exception as error:
                self._send(500, json.dumps({"error": f"{type(error).__name__}: {error}"}).encode())
                return
            finally:
                state["heard_from"] = time.monotonic()
            self._send(200, samples.tobytes(), "application/octet-stream", {"X-Spent": json.dumps(parts)})
        else:
            self._send(404, b"{}")


def watch():


    while True:
        time.sleep(5)
        if not speaking.locked() and time.monotonic() - state["heard_from"] > args.idle:
            print("No word from the plugin; stopping", flush=True)
            os._exit(0)


threading.Thread(target=load, daemon=True).start()
threading.Thread(target=watch, daemon=True).start()
ThreadingHTTPServer(("127.0.0.1", args.port), Handler).serve_forever()
