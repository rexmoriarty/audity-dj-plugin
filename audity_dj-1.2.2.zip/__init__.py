













import json

from flask import Blueprint, Response, current_app, g, jsonify, redirect, request, url_for
from werkzeug.datastructures import ImmutableMultiDict

from plugin.api import config, logger, render_page

from . import gate, install, page, store, voicebox, voices

VERSION = "1.2.2"
bp = Blueprint("audity_dj", __name__)


@bp.before_request
def _admins_only():
    """Everything here but the app's own routes (gate.py answers those, signed in with the music
    server) is the server owner's: the voice's download, the voices, who uses the DJ. AudioMuse-AI
    keeps only a plugin's settings page to its admins and opens the rest of a plugin's pages to anyone
    signed in to it, so the rest is kept to its admins here."""
    if request.path.startswith(gate.PREFIX):
        return None
    if not getattr(config, "AUTH_ENABLED", True) or g.get("auth_role") == "admin":
        return None
    return jsonify(error="Only an AudioMuse-AI admin can do this."), 403
box = voicebox.box


def _listener():
    return gate.listener()


def _picked(listener):
    picked = store.memory(listener).get("voice")
    if picked and voices.find(picked, listener):
        return picked
    return voices.DEFAULT




@bp.route("/app/hello")
def app_hello():
    listener = _listener()
    return jsonify({
        "plugin": "audity_dj",
        "version": VERSION,
        "voice": _voice_status(),
        "voices": [voices.public(voice) for voice in voices.for_listener(listener)],
        "picked": _picked(listener),
        "session": box.status(),

        "canDownload": gate.is_admin(),
        "diskGB": install.DISK_GB,
    })


def _voice_status():
    state = install.status()
    return {"state": state.get("state"), "step": state.get("step"),
            "fraction": state.get("fraction", 0.0), "error": state.get("error")}


@bp.route("/app/voice", methods=["POST"])
def app_voice():
    listener = _listener()
    voice_id = (request.get_json(silent=True) or {}).get("id", "")
    if voices.find(voice_id, listener) is None:
        return jsonify(error="No such voice."), 404
    store.set_voice(listener, voice_id)
    return jsonify(picked=voice_id)


@bp.route("/app/voice/download", methods=["POST"])
def app_download():
    """The voice's download started (or stopped) from the app's DJ page, by an admin of the server, so
    there's nothing to do on this page at all once the plugin's installed."""
    if not gate.is_admin():
        return jsonify(error="Only an admin of your music server can download the DJ's voice."), 403
    if (request.get_json(silent=True) or {}).get("action") == "stop":
        install.stop()
    elif not install.is_ready():
        install.start()
    return jsonify(voice=_voice_status())


@bp.route("/app/session/hold", methods=["POST"])
def app_hold():
    try:
        box.hold(_listener())
    except voicebox.VoiceNotReady:
        return jsonify(error="The DJ's voice isn't downloaded on the server yet.", voice=_voice_status()), 409
    return jsonify(box.status())


@bp.route("/app/session/release", methods=["POST"])
def app_release():
    box.release(_listener())
    return jsonify(ok=True)


@bp.route("/app/lines", methods=["POST"])
def app_ask():
    listener = _listener()
    asked = request.get_json(silent=True) or {}
    text = " ".join(str(asked.get("text", "")).split())
    if not text or len(text) > 600:
        return jsonify(error="A line of 1 to 600 characters."), 400
    voice_id = asked.get("voice") or _picked(listener)
    try:


        job_id = box.ask(listener, text, voice_id, asked.get("takes", 1), later=bool(asked.get("later")),
                         full_band=bool(asked.get("fullBand")))
    except voicebox.VoiceNotReady:
        return jsonify(error="The DJ's voice isn't downloaded on the server yet."), 409
    job = box.line(job_id)
    if asked.get("atOnce") and job is not None and job.state == "done":



        return _line_answer(job)
    return jsonify(id=job_id), 202


@bp.route("/app/lines/<job_id>", methods=["GET", "DELETE"])
def app_line(job_id):
    job = box.line(job_id)
    if job is None or job.listener != _listener():
        return jsonify(error="No such line."), 404
    if request.method == "DELETE":
        box.cancel(job_id)
        return jsonify(ok=True)
    if job.state in ("waiting", "making"):

        try:
            box.hold(job.listener)
        except voicebox.VoiceNotReady:
            pass


        wait = request.args.get("wait", type=float)
        if wait:
            job.finished.wait(min(max(wait, 0), WAIT_LONGEST))
    return _line_answer(job)


WAIT_LONGEST = 8.0


def _line_answer(job):
    if job.state == "done":
        answer = Response(job.wav_for_app(), mimetype="audio/wav")
        answer.headers["X-Audity-Line"] = json.dumps(job.info)
        return answer
    if job.state in ("failed", "cancelled"):
        return jsonify(state=job.state, error=job.error), 500 if job.state == "failed" else 410
    return jsonify(state=job.state, ahead=box.ahead_of(job), session=box.status()), 202


@bp.route("/app/memory", methods=["GET", "POST"])
def app_memory():
    listener = _listener()
    if request.method == "GET":
        return jsonify(store.memory(listener))
    asked = request.get_json(silent=True) or {}
    lines = asked.get("lines") or []
    songs = asked.get("songs") or {}
    if not isinstance(lines, list) or not isinstance(songs, dict):
        return jsonify(error="lines is a list, songs a dictionary."), 400
    return jsonify(store.remember(listener, lines[-60:], dict(list(songs.items())[-3000:])))






def _audiomuse_view(name):
    for view in current_app.view_functions.values():
        if getattr(view, "__name__", "") == name:
            return view
    return None


@bp.route("/app/similar")
def app_similar():
    view = _audiomuse_view("get_similar_tracks_endpoint")
    if view is None:
        return jsonify(error="This AudioMuse-AI can't find songs by sound."), 501
    _for_this_server(("item_id", "n", "eliminate_duplicates"), most=SIMILAR_MOST)
    return current_app.ensure_sync(view)()





SIMILAR_MOST = 100


def _for_this_server(allowed, most=None):
    """AudioMuse-AI's own answer asked of the server the app signed in to, by its IDs, rather than
    its default one, where it's connected to more than one, and never of another: `server` is always
    the sign-in's. Only the arguments the app sends (`allowed`) go through, with `n` at most `most`."""
    args = {key: request.args.getlist(key)[:1] for key in allowed if request.args.get(key) is not None}
    if most is not None and "n" in args:
        try:
            args["n"] = [str(max(1, min(int(args["n"][0]), most)))]
        except ValueError:
            args.pop("n")
    server = gate.server_id()
    if server:
        args["server"] = [server]
    request.args = ImmutableMultiDict(args)


@bp.route("/app/path")
def app_path():
    view = _audiomuse_view("find_path_endpoint")
    if view is None:
        return jsonify(error="This AudioMuse-AI can't find paths between songs."), 501
    _for_this_server(("start_song_id", "end_song_id", "max_steps"))
    return current_app.ensure_sync(view)()


@bp.route("/app/voices/<voice_id>/clip")
def app_clip(voice_id):
    return _clip(voices.find(voice_id, _listener()))


def _clip(voice):
    if voice is None:
        return jsonify(error="No such voice."), 404
    path = voices.clip_path(voice, voice["clips"][0])
    with open(path, "rb") as file:
        data = file.read()
    return Response(data, mimetype="audio/flac" if path.endswith(".flac") else "audio/wav")




@bp.route("/")
def home():
    return render_page(page.html(VERSION), title="Audity DJ")


@bp.route("/status.json")
def status_json():
    return jsonify({
        "voice": dict(_voice_status(), diskBytes=install.disk_bytes() if install.is_ready() else 0,
                      diskGB=install.DISK_GB),
        "session": box.status(),
        "voices": [dict(voices.public(voice), onlyFor=voice.get("onlyFor"), added=voice.get("added", False))
                   for voice in voices.all_voices()],
        "listeners": [dict(row, updated=row["updated"].isoformat() if row["updated"] else None)
                      for row in store.listeners()],
    })


@bp.route("/download", methods=["POST"])
def download():
    action = request.form.get("action", "start")
    if action == "start":
        install.start()
    elif action == "stop":
        install.stop()
    elif action == "remove":
        for listener in box.status()["listeners"]:
            box.release(listener)
        install.remove()
    return redirect(url_for("audity_dj.home"))


@bp.route("/voices/add", methods=["POST"])
def add_voice():
    try:
        package = request.files.get("package")
        if package and package.filename:

            voices.add_package(package.read(), request.form.get("onlyFor"))
        else:

            clips = []
            upload = request.files.get("clip1")
            if upload and upload.filename:
                clips.append((upload.filename, upload.read(), request.form.get("words1", "")))
            voices.add(request.form.get("name", ""), clips, request.form.get("onlyFor"), request.form.get("detail", ""))
    except (ValueError, OSError) as error:
        return render_page(page.problem(str(error), url_for("audity_dj.home")), title="Audity DJ")
    return redirect(url_for("audity_dj.home"))


@bp.route("/voices/<voice_id>/edit", methods=["POST"])
def edit_voice(voice_id):
    try:
        voices.edit(voice_id, request.form.get("name", ""), request.form.get("detail", ""), request.form.get("onlyFor"))
    except (ValueError, OSError) as error:
        return render_page(page.problem(str(error), url_for("audity_dj.home")), title="Audity DJ")
    return redirect(url_for("audity_dj.home"))


@bp.route("/voices/<voice_id>/remove", methods=["POST"])
def remove_voice(voice_id):
    voices.remove(voice_id)
    return redirect(url_for("audity_dj.home"))


@bp.route("/voices/<voice_id>/clip")
def page_clip(voice_id):
    return _clip(voices.find(voice_id))




@bp.route("/try", methods=["POST"])
def try_line():
    asked = request.get_json(silent=True) or {}
    text = " ".join(str(asked.get("text", "")).split())[:600]
    if not text:
        return jsonify(error="Type a line."), 400
    voice_id = asked.get("voice") or voices.DEFAULT



    if voices.find(voice_id) is None:
        return jsonify(error="That voice isn't on the server any more."), 404
    try:

        job_id = box.ask("this page", text, voice_id, 1, full_band=True, any_voice=True)
    except voicebox.VoiceNotReady:
        return jsonify(error="Download the voice first."), 409
    return jsonify(id=job_id), 202


@bp.route("/try/<job_id>")
def try_result(job_id):
    job = box.line(job_id)
    if job is None or job.listener != "this page":
        return jsonify(error="No such line."), 404
    if job.state in ("waiting", "making"):
        box.hold("this page")
    elif job.state == "done" and request.args.get("done") == "1":
        box.release("this page")
    return _line_answer(job)


def _on_start():
    store.migrate()
    gate.install(current_app._get_current_object())
    logger.info("Audity DJ %s is ready for the app at /plugins/audity_dj/app/", VERSION)


def register(ctx):
    ctx.add_blueprint(bp)
    ctx.add_menu_item("Audity DJ", "audity_dj.home", admin_only=True)
    ctx.set_settings_page("audity_dj.home")
    ctx.on_install(store.migrate)
    ctx.on_flask_start(_on_start)
