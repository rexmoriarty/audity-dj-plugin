














import hashlib
import re
import threading
import time

import requests
from flask import current_app, g, jsonify, request

from plugin.api import logger

PREFIX = "/plugins/audity_dj/app/"


_SHAPE = re.compile(r"^[A-Za-z0-9._~+/=-]{1,512}$")

TRUSTED_FOR = 600
KINDS = ("navidrome", "jellyfin", "plex")
_trusted = {}
_lock = threading.Lock()


def install(app):
    """Puts `answer_app` ahead of AudioMuse-AI's sign-in check."""
    waiting = app.before_request_funcs.setdefault(None, [])
    if answer_app not in waiting:
        waiting.insert(0, answer_app)


def answer_app():
    if not request.path.startswith(PREFIX):
        return None
    signed = signed_in()
    if signed is None:
        return jsonify(error="Sign in with your music server's account."), 401
    if request.routing_exception is not None:
        code = getattr(request.routing_exception, "code", 404)
        return jsonify(error="Not here."), code
    view = current_app.view_functions.get(request.endpoint)
    if view is None:
        return jsonify(error="Not here."), 404
    g.audity_listener, g.audity_admin, g.audity_server = signed

    return current_app.ensure_sync(view)(**(request.view_args or {}))


def listener():
    return g.get("audity_listener")


def server_id():
    """The AudioMuse-AI server the sign-in was checked with: songs are found by sound in its own
    library, by its own IDs, where AudioMuse-AI is connected to more than one."""
    return g.get("audity_server")


def is_admin():
    """Whether the account signed in is an admin of its server: only an admin's phone may start the
    voice's download on the server (4.5 GB of its disk)."""
    return bool(g.get("audity_admin"))


def signed_in():
    """(username, is admin, AudioMuse-AI's id for the server) for the request's sign-in, or None."""
    kind = request.headers.get("X-Audity-Server", "navidrome").strip().lower()
    username = request.headers.get("X-Audity-User", "").strip()
    token = request.headers.get("X-Audity-Token", "").strip()
    salt = request.headers.get("X-Audity-Salt", "").strip()
    if kind not in KINDS or not token or (kind == "navidrome" and not (username and salt)):
        return None
    if not (_SHAPE.match(token) and (not salt or _SHAPE.match(salt)) and len(username) <= 200
            and username.isprintable()):
        return None
    key = hashlib.sha256(f"{kind}\0{username}\0{token}\0{salt}".encode()).hexdigest()
    now = time.monotonic()
    with _lock:
        kept = _trusted.get(key)
        if kept is not None:
            if kept[0] > now:
                return kept[1]
            _trusted.pop(key, None)
    checked = {"navidrome": _navidrome, "jellyfin": _jellyfin, "plex": _plex}[kind](username, token, salt)
    if checked is None:
        return None
    with _lock:
        if len(_trusted) > 500:
            _trusted.clear()
        _trusted[key] = (now + TRUSTED_FOR, checked)
    return checked


def _servers(kind):
    """(AudioMuse-AI's id, address) for each server of `kind` it's connected to."""
    from tasks.mediaserver import registry

    found = []
    for server in registry.list_servers():
        url = (server.get("creds") or {}).get("url")
        if server.get("server_type") == kind and url:
            found.append((server.get("server_id"), url.rstrip("/")))
    return found


def _navidrome(username, token, salt):
    params = {"u": username, "t": token, "s": salt, "v": "1.16.1", "c": "audity-dj", "f": "json"}
    for server, url in _servers("navidrome"):
        try:

            answer = requests.get(f"{url}/rest/getUser.view", timeout=10, params=dict(params, username=username))
            body = answer.json().get("subsonic-response", {}) if answer.ok else {}
            if body.get("status") == "ok":
                return username, bool((body.get("user") or {}).get("adminRole")), server

            answer = requests.get(f"{url}/rest/ping.view", timeout=10, params=params)
            if answer.ok and answer.json().get("subsonic-response", {}).get("status") == "ok":
                return username, False, server
        except (requests.RequestException, ValueError):
            logger.warning("Audity DJ: couldn't reach Navidrome at %s to check a sign-in", url)
    return None


def _jellyfin(_username, token, _salt):
    headers = {"Authorization": f'MediaBrowser Client="Audity DJ", Device="AudioMuse-AI", DeviceId="audity-dj", '
                                f'Version="1", Token="{token}"', "Accept": "application/json"}
    for server, url in _servers("jellyfin"):
        try:
            answer = requests.get(f"{url}/Users/Me", timeout=10, headers=headers)
            if answer.ok:
                user = answer.json()
                name = str(user.get("Name") or "").strip()
                if name:
                    return name, bool((user.get("Policy") or {}).get("IsAdministrator")), server
        except (requests.RequestException, ValueError):
            logger.warning("Audity DJ: couldn't reach Jellyfin at %s to check a sign-in", url)
    return None


PLEX_TV = "https://plex.tv"
_PLEX_HEADERS = {"Accept": "application/json", "X-Plex-Product": "Audity DJ", "X-Plex-Client-Identifier": "audity-dj"}


def _plex(_username, token, _salt):
    headers = dict(_PLEX_HEADERS, **{"X-Plex-Token": token})
    for server, url in _servers("plex"):
        try:

            if not requests.get(f"{url}/library/sections", timeout=10, headers=headers).ok:
                continue

            user = requests.get(f"{PLEX_TV}/api/v2/user", timeout=10, headers=headers).json()
            name = str(user.get("username") or user.get("title") or "").strip()
            if not name:
                continue

            owner = requests.get(f"{url}/myplex/account", timeout=10, headers=headers)
            owner_name = ((owner.json() or {}).get("MyPlex") or {}).get("username") if owner.ok else None
            return name, bool(owner_name) and owner_name == user.get("username"), server
        except (requests.RequestException, ValueError):
            logger.warning("Audity DJ: couldn't reach Plex at %s to check a sign-in", url)
    return None
