





import json

from plugin.api import get_db, table


LINES_KEPT = 30
SONG_DAYS = 3
SONGS_KEPT = 3000


def migrate(db=None):
    db = db or get_db()
    cur = db.cursor()
    cur.execute(
        "CREATE TABLE IF NOT EXISTS " + table("listeners") + " ("
        " username TEXT PRIMARY KEY,"
        " voice TEXT,"
        " lines JSONB NOT NULL DEFAULT '[]'::jsonb,"
        " songs JSONB NOT NULL DEFAULT '{}'::jsonb,"
        " updated_at TIMESTAMP NOT NULL DEFAULT now())"
    )
    db.commit()
    cur.close()


def _key(username):
    return (username or "").strip().lower()


def _row(cur, username):
    cur.execute("SELECT voice, lines, songs FROM " + table("listeners") + " WHERE username = %s", (_key(username),))
    row = cur.fetchone()
    if row is None:
        return None, [], {}
    voice, lines, songs = row
    if isinstance(lines, str):
        lines = json.loads(lines)
    if isinstance(songs, str):
        songs = json.loads(songs)
    return voice, list(lines or []), dict(songs or {})


def memory(username):
    db = get_db()
    cur = db.cursor()
    try:
        voice, lines, songs = _row(cur, username)
    finally:
        cur.close()
    return {"voice": voice, "lines": lines, "songs": songs}


def remember(username, lines=(), songs=None, now=None):
    """Adds what a device said and played, and returns the whole memory. Each song's time is the
    latest any device played it; anything older than three days goes."""
    import time

    now = now or time.time()
    db = get_db()
    cur = db.cursor()
    try:

        cur.execute("INSERT INTO " + table("listeners") + " (username) VALUES (%s) ON CONFLICT DO NOTHING",
                    (_key(username),))
        cur.execute("SELECT 1 FROM " + table("listeners") + " WHERE username = %s FOR UPDATE", (_key(username),))
        voice, kept_lines, kept_songs = _row(cur, username)


        for line in lines or ():
            line = str(line).strip()[:600]
            if line and line not in kept_lines:
                kept_lines.append(line)
        kept_lines = kept_lines[-LINES_KEPT:]
        for recording, when in (songs or {}).items():
            try:
                when = float(when)
            except (TypeError, ValueError):
                continue
            recording = str(recording)[:300]
            if when > kept_songs.get(recording, 0):
                kept_songs[recording] = min(when, now + 60)
        since = now - SONG_DAYS * 86_400
        kept_songs = {key: value for key, value in kept_songs.items() if value >= since}
        if len(kept_songs) > SONGS_KEPT:
            kept_songs = dict(sorted(kept_songs.items(), key=lambda item: item[1], reverse=True)[:SONGS_KEPT])
        cur.execute("UPDATE " + table("listeners") + " SET lines = %s::jsonb, songs = %s::jsonb, updated_at = now()"
                    " WHERE username = %s", (json.dumps(kept_lines), json.dumps(kept_songs), _key(username)))
        db.commit()
    except Exception:
        db.rollback()
        raise
    finally:
        cur.close()
    return {"voice": voice, "lines": kept_lines, "songs": kept_songs}


def set_voice(username, voice_id):
    db = get_db()
    cur = db.cursor()
    try:
        cur.execute("INSERT INTO " + table("listeners") + " (username, voice) VALUES (%s, %s)"
                    " ON CONFLICT (username) DO UPDATE SET voice = EXCLUDED.voice, updated_at = now()",
                    (_key(username), voice_id))
        db.commit()
    except Exception:
        db.rollback()
        raise
    finally:
        cur.close()


def listeners():
    db = get_db()
    cur = db.cursor()
    try:
        cur.execute("SELECT username, voice, jsonb_array_length(lines), updated_at FROM " + table("listeners")
                    + " ORDER BY updated_at DESC")
        return [{"username": row[0], "voice": row[1], "lines": row[2], "updated": row[3]} for row in cur.fetchall()]
    finally:
        cur.close()
