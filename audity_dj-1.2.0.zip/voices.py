

















import json
import os
import re
import shutil
import time
import uuid

from . import install

HERE = os.path.dirname(os.path.abspath(__file__))

BUILT_IN = [
    {
        "id": "male",
        "name": "Theo",
        "detail": "Warm and upbeat",
        "use": "mood",

        "pace": 0.92,
        "clips": [
            {"file": "server-male-joyful.wav", "mood": "lively",
             "words": "Oh man, this is it. I've been waiting all week for this one, and it's finally here. "
                      "I love it. Come on, let's go."},
            {"file": "server-male-base.wav", "mood": "calm",
             "words": "Oh man, you are not going to believe this. I just got the best news of my whole year. "
                      "I'm so happy right now. I can't stop smiling. Let's go."},
        ],
    },
    {
        "id": "female",
        "name": "Juno",
        "detail": "Smooth and easy",
        "clips": [
            {"file": "female-alto.wav",
             "words": "That was Steely Dan with Deacon Blues, off Aja, back in seventy-seven. Let's hang out in "
                      "the late seventies a little longer. Here's Michael Jackson. Rock With You."},
        ],
    },
]
DEFAULT = "male"
_ID = re.compile(r"^[a-z0-9][a-z0-9-]{0,40}$")


def _added_folder(*parts):
    return install.folder("voices", *parts)


def _added():
    voices = []
    root = _added_folder()
    if not os.path.isdir(root):
        return voices
    for name in sorted(os.listdir(root)):
        try:
            with open(os.path.join(root, name, "voice.json")) as file:
                voice = json.load(file)
        except (OSError, ValueError):
            continue
        voice["id"] = name
        voice["added"] = True
        voices.append(voice)
    return voices


def all_voices():
    return [dict(voice, added=False) for voice in BUILT_IN] + _added()


def for_listener(username):
    """The voices `username` can pick: the built-in ones and those added for everyone or for them."""
    name = (username or "").lower()
    return [voice for voice in all_voices()
            if not voice.get("onlyFor") or voice["onlyFor"].lower() == name]


def find(voice_id, username=None):
    for voice in (for_listener(username) if username is not None else all_voices()):
        if voice["id"] == voice_id:
            return voice
    return None


def clip_path(voice, clip):
    if voice.get("added"):
        return _added_folder(voice["id"], clip["file"])
    return os.path.join(HERE, "voices", clip["file"])


def clips_for(voice, line):
    """The one clip a line is copied from: the one for the line's mood where a voice has them (Male),
    else its first. ~~All of them for a mix~~ (see the top)."""
    clips = voice["clips"]
    clip = clips[0]
    if voice.get("use") == "mood" and len(clips) > 1:
        mood = "lively" if "!" in line else "calm"
        clip = next((each for each in clips if each.get("mood") == mood), clips[0])
    return [{"path": clip_path(voice, clip), "words": clip["words"]}]


def pace(voice):
    """How much slower than its clip a voice talks: 1 as copied, 0.85 a little slower."""
    try:
        return min(1.0, max(0.7, float(voice.get("pace", 1.0))))
    except (TypeError, ValueError):
        return 1.0


def public(voice):
    return {"id": voice["id"], "name": voice["name"], "detail": voice.get("detail", ""),
            "isDefault": voice["id"] == DEFAULT}


def add(name, clips, only_for=None, detail="", pace=1.0):
    """A voice from `clips`: [(file name, bytes, words)], of which only the first is kept and used (see
    the top). Returns its id."""
    clips = clips[:1]
    name = name.strip()[:40] or "Voice"
    base = re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-")[:30] or "voice"
    voice_id = base
    if find(voice_id) is not None:
        voice_id = f"{base}-{uuid.uuid4().hex[:4]}"
    temporary = _added_folder(f".{voice_id}.new")
    shutil.rmtree(temporary, ignore_errors=True)
    os.makedirs(temporary)
    kept = []
    for index, (file_name, data, words) in enumerate(clips, 1):
        extension = os.path.splitext(file_name or "")[1].lower()
        if extension not in (".wav", ".flac"):
            raise ValueError("Each clip must be a WAV or FLAC file.")
        if not words.strip():
            raise ValueError("Each clip needs its exact words.")
        stored = f"clip{index}{extension}"
        with open(os.path.join(temporary, stored), "wb") as file:
            file.write(data)
        kept.append({"file": stored, "words": " ".join(words.split())})
    if not kept:
        raise ValueError("Add at least one clip.")
    voice = {"name": name, "detail": detail.strip()[:60], "clips": kept, "pace": pace,
             "onlyFor": (only_for or "").strip() or None, "addedAt": int(time.time())}
    with open(os.path.join(temporary, "voice.json"), "w") as file:
        json.dump(voice, file, indent=1)
    os.replace(temporary, _added_folder(voice_id))
    return voice_id


def add_package(data, only_for=None):
    """A voice from a .zip holding voice.json and its clips (how a voice of your own comes)."""
    import io
    import zipfile

    with zipfile.ZipFile(io.BytesIO(data)) as package:
        names = {os.path.basename(info.filename): info for info in package.infolist() if not info.is_dir()}
        if "voice.json" not in names:
            raise ValueError("The package has no voice.json.")
        voice = json.loads(package.read(names["voice.json"]))
        clips = []
        for clip in voice.get("clips", []):
            info = names.get(os.path.basename(clip.get("file", "")))
            if info is None:
                raise ValueError(f"The package is missing {clip.get('file')}.")
            clips.append((clip["file"], package.read(info), clip.get("words", "")))
    return add(voice.get("name", "Voice"), clips, (only_for or "").strip() or voice.get("onlyFor"), voice.get("detail", ""),
               pace(voice))


def remove(voice_id):
    if not _ID.match(voice_id or ""):
        return False
    path = _added_folder(voice_id)
    if not os.path.isdir(path):
        return False
    shutil.rmtree(path)
    return True
