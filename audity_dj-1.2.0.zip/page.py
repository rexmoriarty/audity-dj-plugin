

from html import escape

from . import install

_STYLE = """
<style>
.adj section { margin: 0 0 1.6rem; }
.adj h3 { margin: 0 0 .5rem; }
.adj .muted { opacity: .7; }
.adj .row { display: flex; gap: .6rem; align-items: center; flex-wrap: wrap; margin: .4rem 0; }
.adj table { border-collapse: collapse; width: 100%; max-width: 760px; }
.adj td, .adj th { text-align: left; padding: .35rem .5rem; border-bottom: 1px solid rgba(127,127,127,.25); }
.adj progress { width: 260px; }
.adj textarea, .adj input[type=text] { width: 100%; max-width: 640px; }
.adj fieldset { border: 1px solid rgba(127,127,127,.3); padding: .6rem .8rem; max-width: 680px; }
</style>
"""

_SCRIPT = """
<script>
(function () {
  const $ = (id) => document.getElementById(id);
  function gb(bytes) { return (bytes / 1e9).toFixed(1) + ' GB'; }
  async function refresh() {
    let s;
    try { s = await (await fetch('status.json', {credentials: 'same-origin'})).json(); } catch (e) { return; }
    const v = s.voice;
    $('voice-ready').hidden = v.state !== 'ready';
    $('voice-none').hidden = !(v.state === 'none' || v.state === 'failed');
    $('voice-coming').hidden = v.state !== 'downloading';
    $('voice-error').textContent = v.state === 'failed' ? (v.error || 'The download failed.') : '';
    if (v.state === 'downloading') {
      $('voice-step').textContent = v.step || 'Downloading';
      $('voice-bar').value = v.fraction || 0;
      $('voice-percent').textContent = Math.round((v.fraction || 0) * 100) + '%';
    }
    if (v.state === 'ready') { $('voice-size').textContent = gb(v.diskBytes); }
    const se = s.session;
    $('session').textContent = !se.running ? 'Off. Nothing of the voice is running.'
      : (se.warming ? 'Starting the voice (' + se.since + ' s)…' : 'On for ' + se.listeners.join(', ') + '.')
        + (se.waiting ? ' ' + se.waiting + ' line(s) being made.' : '');
    if (se.error) { $('session').textContent += ' Problem: ' + se.error; }
    const rows = s.voices.map((x) => '<tr><td>' + esc(x.name) + (x.isDefault ? ' <span class="muted">(default)</span>' : '')
      + '</td><td class="muted">' + esc(x.detail || '') + '</td><td>' + (x.onlyFor ? 'Only ' + esc(x.onlyFor) : 'Everyone')
      + '</td><td><audio controls preload="none" src="voices/' + x.id + '/clip"></audio></td><td>'
      + (x.added ? '<form method="post" action="voices/' + x.id + '/remove" onsubmit="return confirm(\\'Remove this voice?\\')"><button>Remove</button></form>' : '')
      + '</td></tr>');
    $('voices').innerHTML = rows.join('');
    const pick = $('try-voice'), was = pick.value;
    pick.innerHTML = s.voices.map((x) => '<option value="' + x.id + '">' + esc(x.name) + '</option>').join('');
    if (was) pick.value = was;
    $('listeners').innerHTML = s.listeners.length ? s.listeners.map((l) => '<tr><td>' + esc(l.username)
      + '</td><td>' + esc(l.voice || 'default') + '</td><td>' + l.lines + '</td><td class="muted">' + esc(l.updated || '') + '</td></tr>').join('')
      : '<tr><td class="muted" colspan="4">No one has used the DJ yet.</td></tr>';
  }
  function esc(t) { const d = document.createElement('div'); d.textContent = t; return d.innerHTML; }
  $('try-go').onclick = async function () {
    const text = $('try-text').value.trim();
    if (!text) return;
    $('try-go').disabled = true;
    $('try-state').textContent = 'Asked…';
    const begun = Date.now();
    const asked = await fetch('try', {method: 'POST', headers: {'Content-Type': 'application/json'},
      credentials: 'same-origin', body: JSON.stringify({text: text, voice: $('try-voice').value})});
    const got = await asked.json();
    if (!asked.ok) { $('try-state').textContent = got.error || 'Couldn\\'t ask.'; $('try-go').disabled = false; return; }
    while (true) {
      await new Promise((r) => setTimeout(r, 2000));
      const answer = await fetch('try/' + got.id, {credentials: 'same-origin'});
      if (answer.status === 200) {
        const info = JSON.parse(answer.headers.get('X-Audity-Line') || '{}');
        $('try-audio').src = URL.createObjectURL(await answer.blob());
        $('try-audio').play();
        fetch('try/' + got.id + '?done=1', {credentials: 'same-origin'});
        $('try-state').textContent = 'Made in ' + Math.round((Date.now() - begun) / 1000) + ' s ('
          + info.seconds + ' s of speech). Heard back: “' + (info.heard || '') + '”';
        break;
      }
      if (answer.status !== 202) { const e = await answer.json(); $('try-state').textContent = e.error || 'It failed.'; break; }
      const w = await answer.json();
      $('try-state').textContent = w.session && w.session.warming ? 'Starting the voice (' + w.session.since + ' s)…'
        : 'Making it (' + Math.round((Date.now() - begun) / 1000) + ' s)…';
    }
    $('try-go').disabled = false;
  };
  refresh();
  setInterval(refresh, 3000);
})();
</script>
"""


def html(version):
    return _STYLE + f"""
<div class="adj">
<p class="muted">Version {escape(version)}. Audity finds this on its own: turn on the DJ in Audity's Settings → Radio &amp; Autoplay.
The voice runs only while someone's DJ is on, and stops when the last one turns it off or closes Audity.</p>

<section>
  <h3>The voice</h3>
  <div id="voice-none" hidden>
    <p>The DJ's voice is Ming-3.0-tts (inclusionAI, MIT), made on this server's processor. It needs a one-time download of about
    {install.DISK_GB:.1f} GB (PyTorch for processors, Ming's code and its 3.0 GB voice), kept in the plugins volume.</p>
    <p id="voice-error" class="muted"></p>
    <form method="post" action="download"><input type="hidden" name="action" value="start"><button>Download the Voice</button></form>
  </div>
  <div id="voice-coming" hidden>
    <div class="row"><span id="voice-step">Downloading</span> <progress id="voice-bar" max="1" value="0"></progress> <span id="voice-percent"></span></div>
    <form method="post" action="download"><input type="hidden" name="action" value="stop"><button>Stop Downloading</button></form>
  </div>
  <div id="voice-ready" hidden>
    <p>Downloaded (<span id="voice-size"></span>).</p>
    <form method="post" action="download" onsubmit="return confirm('Remove the voice? The DJ can\\'t talk until it\\'s downloaded again. Voices you added stay.')">
      <input type="hidden" name="action" value="remove"><button>Remove the Voice</button></form>
  </div>
</section>

<section>
  <h3>Now</h3>
  <p id="session">…</p>
</section>

<section>
  <h3>Try a line</h3>
  <div class="row"><select id="try-voice"></select></div>
  <textarea id="try-text" rows="2">Good evening, let's start with the songs you can't stop playing this month. Here's Steely Dan... Peg.</textarea>
  <div class="row"><button id="try-go">Say It</button> <span id="try-state" class="muted"></span></div>
  <audio id="try-audio" controls></audio>
  <p class="muted">"..." before a name leaves a beat before it, as Audity writes its lines. The first line after the voice starts takes longer.</p>
</section>

<section>
  <h3>Voices</h3>
  <table><thead><tr><th>Name</th><th></th><th>For</th><th>Its clip</th><th></th></tr></thead><tbody id="voices"></tbody></table>
  <p class="muted">Each listener picks their voice in Audity's Settings. A voice is copied from a short clip of someone talking (5 to 15 s),
  with its exact words: a wrong word changes the voice. Only add someone's voice with their permission.</p>
  <form method="post" action="voices/add" enctype="multipart/form-data">
    <fieldset>
      <legend>Add a voice</legend>
      <div class="row">Name <input type="text" name="name" required style="max-width:240px"></div>
      <div class="row">Description <input type="text" name="detail" style="max-width:320px" placeholder="Optional"></div>
      <div class="row">Only for the account <input type="text" name="onlyFor" style="max-width:200px" placeholder="Everyone if empty"></div>
      <div class="row">Clip <input type="file" name="clip1" accept=".wav,.flac"></div><textarea name="words1" rows="2" placeholder="The clip's exact words"></textarea>
      <p class="muted">Clear and lively talk copies best: the voice keeps the clip's feeling and pace.</p>
      <div class="row">Or a voice package (.zip with voice.json and its clips) <input type="file" name="package" accept=".zip"></div>
      <button>Add Voice</button>
    </fieldset>
  </form>
</section>

<section>
  <h3>Listeners</h3>
  <p class="muted">What the DJ remembers for each account (Navidrome, Jellyfin or Plex): its last lines and the songs it played in the last three days, so a new
  session, on any device, doesn't repeat them.</p>
  <table><thead><tr><th>Account</th><th>Voice</th><th>Lines kept</th><th>Last used</th></tr></thead><tbody id="listeners"></tbody></table>
</section>
</div>
""" + _SCRIPT


def problem(text):
    return f'<p>{escape(text)}</p><p><a href="../">Back</a></p>'
