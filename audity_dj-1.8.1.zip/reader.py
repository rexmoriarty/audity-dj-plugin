









import re
import unicodedata
from datetime import datetime



_FEEL_WORDS = {

    "calm": (-1, None), "calmer": (-0.7, None), "chill": (-0.8, None), "chilled": (-0.8, None), "chillout": (-0.8, None),
    "relax": (-0.9, None), "relaxing": (-0.9, None), "relaxed": (-0.9, None), "mellow": (-0.7, None), "mellower": (-0.6, None),
    "soft": (-0.7, None), "softer": (-0.6, None), "quiet": (-0.8, None), "quieter": (-0.6, None), "gentle": (-0.8, None),
    "slow": (-0.8, None), "slower": (-0.6, None), "sleep": (-1, None), "sleepy": (-1, None), "bedtime": (-1, None),
    "study": (-0.6, None), "studying": (-0.6, None), "focus": (-0.5, None), "reading": (-0.7, None), "peaceful": (-0.9, 0.3),
    "soothing": (-0.9, None), "lazy": (-0.7, 0.2), "cozy": (-0.6, 0.3), "cosy": (-0.6, 0.3), "sunday": (-0.5, 0.3),
    "unwind": (-0.8, None), "dreamy": (-0.6, None), "acoustic": (-0.6, None), "laid": (-0.6, 0.2), "easygoing": (-0.5, 0.3),

    "sad": (-0.4, -1), "sadder": (None, -0.8), "melancholic": (-0.4, -0.9), "melancholy": (-0.4, -0.9),
    "heartbroken": (-0.3, -1), "heartbreak": (-0.3, -1), "breakup": (-0.3, -0.9), "lonely": (-0.5, -0.9),
    "cry": (-0.5, -1), "crying": (-0.5, -1), "depressing": (-0.5, -1), "depressed": (-0.5, -1), "gloomy": (-0.4, -0.8),
    "moody": (None, -0.6), "moodier": (None, -0.6), "dark": (None, -0.7), "darker": (None, -0.6), "somber": (-0.6, -0.8),
    "sombre": (-0.6, -0.8), "wistful": (-0.5, -0.5), "bittersweet": (-0.3, -0.4), "emotional": (-0.3, -0.5),
    "blue": (-0.3, -0.7), "rainy": (-0.5, -0.5), "rain": (-0.5, -0.5), "brooding": (None, -0.7), "haunting": (-0.4, -0.6),
    "nostalgic": (-0.3, -0.2), "reflective": (-0.5, -0.3), "introspective": (-0.5, -0.4), "sentimental": (-0.4, -0.3),

    "happy": (0.4, 1), "happier": (None, 0.8), "upbeat": (0.7, 0.8), "cheerful": (0.4, 0.9), "sunny": (0.4, 0.9),
    "summer": (0.4, 0.8), "summery": (0.4, 0.8), "fun": (0.6, 0.8), "joyful": (0.5, 1), "uplifting": (0.4, 0.9),
    "positive": (None, 0.8), "feelgood": (0.4, 0.9), "groovy": (0.5, 0.6), "funky": (0.6, 0.6), "bright": (None, 0.8),
    "brighter": (None, 0.6), "sunshine": (0.4, 0.9), "carefree": (0.3, 0.8), "playful": (0.4, 0.8), "beach": (0.3, 0.7),

    "energetic": (1, None), "energy": (1, None), "lively": (0.8, 0.4), "livelier": (0.7, None), "hype": (1, None),
    "hyped": (1, None), "pump": (1, None), "pumped": (1, None), "workout": (1, None), "gym": (1, None), "exercise": (1, None),
    "running": (1, None), "run": (0.9, None), "lifting": (1, None), "cardio": (1, None), "party": (0.9, 0.7),
    "dance": (0.9, 0.6), "dancing": (0.9, 0.6), "danceable": (0.9, 0.6), "loud": (0.9, None), "louder": (0.6, None),
    "fast": (0.8, None), "faster": (0.6, None), "intense": (0.9, -0.2), "aggressive": (1, -0.5), "angry": (1, -0.7),
    "rage": (1, -0.7), "heavy": (0.9, -0.4), "heavier": (0.7, -0.3), "driving": (0.6, 0.4), "drive": (0.6, 0.4),
    "banger": (0.9, None), "bangers": (0.9, None), "epic": (0.7, None), "cleaning": (0.6, 0.6), "celebrate": (0.7, 0.9),

    "romantic": (-0.4, 0.4), "romance": (-0.4, 0.4), "sexy": (-0.3, 0.3), "sensual": (-0.4, 0.3), "seductive": (-0.3, 0.2),
    "smooth": (-0.5, 0.3), "dinner": (-0.5, 0.2), "coffee": (-0.4, 0.2), "morning": (-0.3, 0.3),
}
_FEEL_PAIRS = {
    "feel good": (0.4, 0.9), "good vibes": (0.3, 0.8), "road trip": (0.6, 0.5), "wake up": (0.6, 0.5),
    "date night": (-0.3, 0.4), "love songs": (-0.3, 0.4), "wind down": (-0.8, None), "calm down": (-0.8, None),
    "slow down": (-0.7, None), "late night": (-0.5, -0.1), "slow dance": (-0.6, 0.4), "rock out": (0.9, None),
    "feeling down": (-0.4, -0.8), "it down": (-0.6, None), "it up": (0.6, None), "pick me": (0.5, 0.8),
    "laid back": (-0.6, 0.2), "easy going": (-0.5, 0.3), "get going": (0.6, 0.4),
}


def read_feel(said):
    """HostFeel.read: {"energy", "brightness"} from the words (as `plain` gives them), each word or pair for a mood,
    a moment or a pace moving one axis or both, "not" or "less" just before turning it, "a little" softening it.
    None when none is said."""
    words = said.split()
    energies, brightnesses = [], []
    index = 0
    while index < len(words):
        length = 1
        entry = _FEEL_WORDS.get(words[index])
        if index + 1 < len(words) and (words[index] + " " + words[index + 1]) in _FEEL_PAIRS:
            entry = _FEEL_PAIRS[words[index] + " " + words[index + 1]]
            length = 2
        if entry:
            before = words[max(0, index - 2):index]
            turn = -0.6 if any(w in ("not", "less", "no", "without", "nothing", "isnt", "too") for w in before)\
                else 0.6 if any(w in ("little", "bit", "slightly", "kinda", "somewhat") for w in before) else 1
            if entry[0] is not None:
                energies.append(entry[0] * turn)
            if entry[1] is not None:
                brightnesses.append(entry[1] * turn)
        index += length
    if not energies and not brightnesses:
        return None
    mean = lambda values: sum(values) / len(values) if values else None
    return {"energy": mean(energies), "brightness": mean(brightnesses)}




def genres_of(song):
    """HostPlanner.genres(of:): every genre a song is tagged with."""
    genres = song.get("genres") or [song.get("genre") or ""]
    return [genre for genre in genres if genre]


def year_of(song):
    """HostPlanner.year(of:): its original release year, else its album's."""
    year = int(song.get("year") or 0)
    return year if year > 0 else int(song.get("albumYear") or 0)


def _tidy(text):
    return " ".join(text.split())


def speech_artist(raw):
    """HostSpeech.artist: "feat." as "featuring", "&" as "and"."""
    text = re.sub(r"\b(feat\.?|ft\.?)(\s)", lambda m: "featuring" + m.group(2), raw, flags=re.IGNORECASE)
    return _tidy(text.replace(" & ", " and "))


def speech_genre(raw):
    """HostSpeech.genre: a genre tag as said mid-sentence, a word with capitals past its first letter kept."""
    def part(p):
        rest = p[1:]
        return p.lower() if rest == rest.lower() else p
    return " ".join("-".join(part(p) for p in word.split("-")) for word in raw.split(" "))




def plain(text):
    """HostRequest.plain: lower case, without accents or punctuation, with a space at each end, so a name is found
    only as whole words; a word's "'s" apart from it."""
    folded = "".join(c for c in unicodedata.normalize("NFKD", text) if not unicodedata.combining(c)).lower()
    folded = folded.replace("&", " and ").replace("’", "'").replace(".", "")
    words = "".join(c if (c.isalnum() or c == "'") else " " for c in folded).split()
    return (" " + " ".join(words) + " ").replace("'s ", " s ")


_OPENERS = ["hey dj", "dj", "can you", "could you", "would you", "please", "i want to hear", "i wanna hear", "i'd like to hear",
            "let s hear", "lets hear", "let s play", "lets play", "play me", "play", "put on", "queue up", "queue",
            "give me", "some", "a little", "the song", "the album", "something by", "anything by", "more"]


def cores(said):
    """The words without the asking, each step of it: "can you play some purple rain please" is "purple rain", and
    "play some velvet morning" "some velvet morning" as well as "velvet morning"."""
    words = said.strip()
    steps = {words}
    changed = True
    while changed:
        changed = False
        for opener in _OPENERS:
            if words == opener or words.startswith(opener + " "):
                words = words[len(opener):].strip()
                steps.add(words)
                changed = True
        for closer in ("please", "next", "now", "for me", "and similar"):
            if words.endswith(" " + closer):
                words = words[:-len(closer)].strip()
                steps.add(words)
                changed = True
    for step in list(steps):
        at = step.find(" by ")
        if at >= 0:
            steps.add(step[:at])
    steps.discard("")
    return steps


def core_of(title):
    """A title without what follows its name: "Shoot to Thrill (Live)", "Dreams - 2004 Remaster" are "Shoot to
    Thrill", "Dreams"."""
    for opening in (" (", " [", " - ", " – ", " — "):
        at = title.find(opening)
        if at > 0:
            title = title[:at]
    return title.strip()


_SAME = {"too": "to", "two": "to", "2": "to", "four": "for", "4": "for", "u": "you", "ur": "your", "n": "and", "tha": "the"}


def loose(said):
    """Plain words as they sound, for titles heard: "too" and "two" as "to", "four" as "for"."""
    return " " + " ".join(_SAME.get(word, word) for word in said.split()) + " "


START_WORDS = [" starting with ", " starting off with ", " start with ", " start off with ", " start it with ",
               " beginning with ", " begin with ", " kick off with ", " kick it off with ", " kicking off with ",
               " open with ", " opening with ", " lead with ", " lead off with ", " leading off with "]


def is_started(title, said):
    """Whether `title` is said right after words that start a set with it ("some AC/DC, starting with Shoot to
    Thrill"), as heard too."""
    titles = {t for t in (plain(title).strip(), plain(core_of(title)).strip()) if t}
    heard = loose(said)
    loose_titles = {loose(" " + t + " ").strip() for t in titles}
    return any(any(phrase + t + " " in said or phrase + "the song " + t + " " in said for t in titles)
               or any(phrase + t + " " in heard or phrase + "the song " + t + " " in heard for t in loose_titles)
               for phrase in START_WORDS)


OUT_WORDS = {"no", "no more", "not", "never", "anything but", "anything except", "anything besides", "except", "besides",
             "other than", "without", "stop playing", "stop", "enough", "enough with", "skip", "tired of", "sick of",
             "instead of", "not feeling", "done with", "over", "get rid of", "lose the", "ditch"}
LESS_WORDS = {"less", "fewer", "not so much", "not as much", "a bit less", "a little less", "too much", "cut down on"}
_TURN_FILLER = {"the", "some", "any", "of", "songs", "song", "music", "stuff", "by", "from", "all", "that", "this", "so",
                "much", "for", "now"}


def turn(name, said):
    """How the words just before `name` turn from it: "out" ("no more", "anything but") or "less"; None when they
    ask for it."""
    at = said.find(" " + name + " ")
    if at < 0:
        return None
    words = said[:at].split()
    for _ in range(2):
        for count in range(min(4, len(words)), 0, -1):
            tail = " ".join(words[-count:])
            if tail in LESS_WORDS:
                return "less"
            if tail in OUT_WORDS:
                return "out"
        while words and words[-1] in _TURN_FILLER:
            words.pop()
    return None


def joins(name, said):
    """Whether `name` follows another with "and", "or" or "nor" between ("no country or folk")."""
    at = said.find(" " + name + " ")
    if at < 0:
        return False
    before = said[:at].split()
    return bool(before) and before[-1] in ("and", "or", "nor", "also")


PLAYING_WORDS = {
    "more": [" more like this ", " more of this ", " more like that ", " more of that ", " keep this going ", " keep it going ",
             " keep going ", " keep this vibe ", " this vibe ", " same vibe ", " similar to this ", " songs like this ",
             " like this ", " love this ", " loving this ", " this is great ", " more stuff like this "],
    "different": [" something different ", " something else ", " anything else ", " switch it up ", " change it up ",
                  " mix it up ", " shake it up ", " not this ", " not feeling this ", " not feeling it ", " not this one ",
                  " surprise me ", " change the vibe ", " different vibe ", " something new for a change "],
    "older": [" something older ", " older ", " go back further ", " further back ", " back in time "],
    "newer": [" something newer ", " newer ", " more recent ", " something recent "],
}


def about(said):
    """What's playing, in the words: "more" like it, something "different", "older" or "newer"."""
    for kind in ("different", "more", "older", "newer"):
        if any(phrase in said for phrase in PLAYING_WORDS[kind]):
            return kind
    return None


def kind(said):
    """A kind of set named by what it is (HostTheme.kind): your most played lately, what you've just added, deep cuts."""
    if any(p in said for p in (" most played", " on repeat", " top songs", " my top ", " been playing", " been listening to",
                               " heavy rotation", " the usual", " go to songs", " my go to ")):
        return "onRepeat"
    if any(p in said for p in (" new releases", " new music ", " new stuff", " new albums", " new additions", " just added",
                               " recently added", " latest ", " newest ")):
        return "fresh"
    if any(p in said for p in (" deep cuts", " deep cut ", " hidden gems", " b sides")):
        return "deepCuts"
    return None


ASKING = {
    "hey", "hi", "yo", "dj", "ok", "okay", "alright", "all", "right", "so", "um", "uh", "well", "now", "then", "can", "could",
    "would", "will", "you", "we", "i", "id", "i'd", "im", "i'm", "ill", "i'll", "me", "us", "my", "let", "lets", "let's", "s",
    "want", "wanna", "like", "love", "to", "hear", "listen", "listening", "play", "playing", "put", "on", "throw", "spin",
    "queue", "add", "up", "give", "some", "a", "an", "the", "little", "bit", "of", "song", "track", "tune", "by", "from",
    "next", "after", "this", "that", "please", "for", "just", "go", "ahead", "and", "how", "about", "maybe", "again",
    "instead", "is", "it", "be", "in", "mood", "really", "need", "with", "thanks", "thank", "start", "starting", "one",
    "similar",
}
_PHRASE_LEADING = (ASKING - {"some", "a", "an", "my", "the", "little", "bit"}) | {
    "change", "switch", "turn", "make", "vibe", "into", "feel", "feeling", "feelin", "something", "music", "songs"}
_PHRASE_TRAILING = {"please", "now", "next", "thanks", "thank", "you", "for", "me", "instead", "then", "right", "up", "this",
                    "after", "on"}


def phrase(said):
    """A sound asked for, as said, to say back: "change the vibe to something more upbeat" is "something more
    upbeat", "give me some gym music" "some gym music", "melancholic" "something melancholic". None past seven
    words, or none."""
    words = said.split()
    while words and (words[0] in _PHRASE_LEADING or (words[0] in ("the", "my") and len(words) > 1 and words[1] in _PHRASE_LEADING)):
        if words[0] in ("something", "music", "songs") and len(words) > 1 and words[1] not in _PHRASE_LEADING:
            break
        words.pop(0)
    while words and words[-1] in _PHRASE_TRAILING:
        words.pop()
    if not words or len(words) > 7:
        return None
    text = " ".join(words)
    if words[0] in ("something", "some", "a", "an", "music", "songs", "anything", "my", "the", "your"):
        return text
    if read_feel(" " + words[0] + " ") is not None or words[0] in ("more", "less", "kind", "kinda", "bit", "little"):
        return "something " + text
    return "some " + text


def found(said, names):
    """The names among `names` said whole in `said`, none inside a longer one said ("Rock" in "Indie Rock")."""
    hits = []
    for name in names:
        plain_name = plain(name).strip()
        if len(plain_name) >= 3 and " " + plain_name + " " in said:
            hits.append((name, plain_name))
    once = {}
    for name, plain_name in hits:
        once.setdefault(plain_name, name)
    return sorted(name for plain_name, name in once.items()
                  if not any(other != plain_name and " " + plain_name + " " in " " + other + " " for other in once))


_DECADE_WORDS = {"fifties": 1950, "sixties": 1960, "seventies": 1970, "eighties": 1980, "nineties": 1990,
                 "two thousands": 2000, "noughties": 2000, "aughts": 2000, "twenty tens": 2010, "twenties": 2020}


def era(said, now=None):
    """An era said, as (from, to): "the eighties", "80s", "1980s", "2024", "this year", "last year"."""
    year = (now or datetime.now()).year
    if " this year " in said:
        return (year, year)
    if " last year " in said:
        return (year - 1, year - 1)
    for word, decade in _DECADE_WORDS.items():
        if " " + word + " " in said:
            return (decade, decade + 9)
    match = re.search(r" (19|20)?([0-9])0 ?'?s ", said)
    if match:
        digit = int(match.group(2))
        century = int(match.group(1)) * 100 if match.group(1) else (1900 if digit >= 5 else 2000)
        return (century + digit * 10, century + digit * 10 + 9)
    match = re.search(r" (19[5-9][0-9]|20[0-3][0-9]) ", said)
    if match:
        return (int(match.group(1)), int(match.group(1)))
    return None


def mix(said):
    """Your favorites, throwbacks, or ones you've barely played (HostMix's raw values)."""
    if any(p in said for p in (" throwback", " in a while", " in ages", " in forever", " in years", " forgotten ", " rediscover",
                               " used to ", " old favorite", " old favourite")):
        return "throwbacks"
    if any(p in said for p in (" favorite", " favourite", " loved ", " love the most ")):
        return "favorites"
    if any(p in said for p in (" haven't heard", " havent heard", " barely ", " never played", " haven't played", " havent played",
                               " discover", " new to me", " never heard", " something new ", " rarely ")):
        return "rediscover"
    return None


def artist_names(said, asked, library):
    """Every artist named, with the name as found in the words, longest first, none inside a longer one found, with
    or without a leading "the"; joined where its name has a slash or a dash ("AC/DC" heard as "ACDC"); a short name
    (under five letters) only when it's all that's asked. In the order said."""
    found_ = []
    for artist_id, name in library.artists.items():
        plain_name = plain(name).strip()
        if plain_name.startswith("the ") and len(plain_name) > 7 and " " + plain_name + " " not in said:
            plain_name = plain_name[4:]
        joined = plain_name.replace(" ", "")
        is_joined = False
        if " " + plain_name + " " not in said and any(c in "/-" for c in name) and len(joined) >= 4 and " " + joined + " " in said:
            plain_name = joined
            is_joined = True
        if len(plain_name) >= 3 and " " + plain_name + " " in said and (len(plain_name) >= 5 or is_joined or plain_name in asked):
            found_.append((artist_id, plain_name))
    kept = []
    for artist in sorted(found_, key=lambda a: -len(a[1])):
        if not any(" " + artist[1] + " " in " " + k[1] + " " for k in kept):
            kept.append(artist)
    return sorted(kept, key=lambda a: said.find(" " + a[1] + " "))


class Library:
    """The app's song list, read once for each version (`/app/library`), with what the reader looks up by."""

    def __init__(self, songs, version=""):
        self.version = version
        self.songs = songs
        self.by_id = {song["id"]: song for song in songs}
        self.artists = {}
        for song in songs:
            self.artists.setdefault(song.get("artistId") or "", song.get("artist") or "")
        self.artists.pop("", None)
        self.genres = sorted({genre for song in songs for genre in genres_of(song)})
        self.moods = sorted({mood for song in songs for mood in (song.get("moods") or [])})
        self._plain = {}

    def titles(self, title):
        """`title` plain as tagged and without what follows its name, worked out once."""
        kept = self._plain.get(title)
        if kept is None:
            kept = self._plain[title] = (plain(title).strip(), plain(core_of(title)).strip())
        return kept


def _empty():
    return {"songs": [], "albums": [], "artists": [], "genres": [], "moods": [], "era": None, "mix": None, "feel": None,
            "later": False, "wholeAlbum": False, "phrase": None, "reply": None,
            "without": {"artists": [], "genres": [], "lessArtists": [], "lessGenres": [], "said": [], "isLess": False},
            "playing": None, "kind": None, "startsWith": None}


def names_music(request):
    return bool(request["songs"] or request["albums"] or request["artists"])


def without_empty(request):
    without = request["without"]
    return not (without["artists"] or without["genres"] or without["lessArtists"] or without["lessGenres"])


def is_empty(request):
    return (not names_music(request) and not request["genres"] and not request["moods"] and request["era"] is None
            and request["mix"] is None and not request["feel"] and without_empty(request) and request["playing"] is None
            and request["kind"] is None and request["startsWith"] is None)


def is_read(request):
    """Whether the words said what to play in a way read here; the rest, a feel AudioMuse-AI's text search reads."""
    return (names_music(request) or bool(request["genres"]) or bool(request["moods"]) or bool(request["feel"])
            or request["era"] is not None or request["mix"] is not None or not without_empty(request)
            or request["playing"] is not None or request["kind"] is not None or request["startsWith"] is not None)


def read(words, library, playing=None, now=None):
    """HostRequest.read: the request as a dict (HostRequest's fields, `era` as {"from", "to"}), or None when nothing in
    the words is in the library or says a mood. `playing` is the song on (a library song), for words about it."""
    said = plain(words)
    if not said.strip():
        return None

    if playing:
        artist = plain(playing.get("artist") or "").strip()
        if artist:
            for p in (" this artist ", " this band ", " this singer ", " this group ", " these guys "):
                said = said.replace(p, " " + artist + " ")
        genres = genres_of(playing)
        genre = plain(genres[0]).strip() if genres else ""
        if genre:
            for p in (" this genre ", " this kind of music ", " this style ", " this type of music "):
                said = said.replace(p, " " + genre + " ")
    asked = cores(said)
    request = _empty()
    found_era = era(said, now)
    request["era"] = found_era
    request["mix"] = mix(said)

    named = artist_names(said, asked, library)
    loosely = loose(said)

    def is_named_plain(title, extra):
        if len(title) < 2:
            return False
        if title in asked or (len(title) >= 12 and " " + title + " " in said):
            return True
        if len(title) >= 12 and " " + loose(" " + title + " ").strip() + " " in loosely:
            return True
        if " " + title + " " not in said or not any(word not in ASKING for word in title.split())\
                or read_feel(" " + title + " ") is not None:
            return False
        rest = said.replace(" " + title + " ", " ")
        for _, name in named:
            rest = rest.replace(" " + name + " ", " ")
        return all(word in ASKING or word in extra for word in rest.split())

    def is_named(title, extra=frozenset()):
        whole, short = library.titles(title)
        return is_named_plain(whole, extra) or (short != whole and len(short) >= 4 and is_named_plain(short, extra))

    def by_named(matches):
        for song in matches:
            if any(artist_id == song.get("artistId") for artist_id, _ in named):
                return song
        return matches[0] if matches and not named else None

    says_album = any(p in said for p in (" album ", " record ", " lp "))
    album_words = frozenset({"album", "record", "lp", "whole", "entire", "full", "all"})
    songs = library.songs
    song = None if says_album else by_named([s for s in songs if is_named(s.get("title") or "")])
    if song and is_started(song.get("title") or "", said):
        request["startsWith"] = song["id"]
    elif song:
        request["songs"] = [song["id"]]
    else:
        album = by_named([s for s in songs if is_named(s.get("album") or "", album_words)])
        if album:
            request["albums"] = [album.get("albumId")]
            request["wholeAlbum"] = any(p in said for p in (" whole ", " entire ", " full ", " all of "))
        elif says_album:
            song = by_named([s for s in songs if is_named(s.get("title") or "", album_words)])
            if song:
                request["songs"] = [song["id"]]

    whose = {s.get("artistId") for s in songs if s["id"] in request["songs"] or (request["albums"] and s.get("albumId") in request["albums"])}
    request["artists"] = [artist_id for artist_id, _ in named if artist_id not in whose]


    outside = said
    titles = [s.get("title") or "" for s in songs if s["id"] in request["songs"] or s["id"] == request["startsWith"]]
    if request["albums"]:
        titles += [s.get("album") or "" for s in songs if s.get("albumId") in request["albums"]][:1]
    for title in titles:
        outside = outside.replace(" " + plain(title).strip() + " ", " ")
        outside = outside.replace(" " + plain(core_of(title)).strip() + " ", " ")
    for p in START_WORDS:
        outside = outside.replace(p, " ")
    for _, name in named:
        outside = outside.replace(" " + name + " ", " ")
    request["later"] = any(p in outside for p in (" next ", " after this ", " after that ", " afterwards ", " later ", " queue ", " add "))

    request["genres"] = found(said, library.genres)
    request["moods"] = found(said, library.moods)



    names_said = {}
    for artist_id, name in named:
        names_said.setdefault(artist_id, name)
    without = {"artists": set(), "genres": set(), "lessArtists": set(), "lessGenres": set(), "said": [], "isLess": False}
    turns = []
    for artist_id in request["artists"]:
        name = names_said.get(artist_id)
        at = said.find(" " + name + " ") if name else -1
        if at < 0:
            continue
        turns.append((at, name, turn(name, said), ("artist", artist_id, name)))
    for genre in request["genres"]:
        name = plain(genre).strip()
        at = said.find(" " + name + " ")
        if at < 0:
            continue
        turns.append((at, name, turn(name, said), ("genre", genre, name)))
    last = None
    for at, name, its_turn, (what, key, name_) in sorted(turns, key=lambda t: t[0]):
        joined = joins(name, said)
        this = its_turn if its_turn is not None else (last if joined else None)
        if this is not None:
            if what == "artist":
                (without["artists"] if this == "out" else without["lessArtists"]).add(key)
                first = next((s for s in songs if s.get("artistId") == key), None)
                without["said"].append(speech_artist(first["artist"]) if first else name_)
            else:
                (without["genres"] if this == "out" else without["lessGenres"]).add(key.lower())
                without["said"].append(speech_genre(key))
            without["isLess"] = without["isLess"] or this == "less"
        last = this
    request["artists"] = [a for a in request["artists"] if a not in without["artists"] and a not in without["lessArtists"]]
    request["genres"] = [g for g in request["genres"] if g.lower() not in without["genres"] and g.lower() not in without["lessGenres"]]
    request["without"] = {key: sorted(value) if isinstance(value, set) else value for key, value in without.items()}

    request["kind"] = kind(said)
    if not names_music(request) and not request["genres"] and not request["moods"] and request["mix"] is None\
            and request["kind"] is None and playing:
        request["playing"] = about(said)
        if request["playing"] in ("older", "newer"):
            decade = year_of(playing) // 10 * 10
            if decade > 1900:
                if request["era"] is None:
                    request["era"] = (1900, decade - 1) if request["playing"] == "older" else (decade + 10, 2100)
            else:
                request["playing"] = None

    for_feel = outside
    for name in request["genres"] + request["without"]["genres"] + request["without"]["lessGenres"] + request["moods"]:
        for_feel = for_feel.replace(" " + plain(name).strip() + " ", " ")
    for phrases in PLAYING_WORDS.values():
        for p in phrases:
            for_feel = for_feel.replace(p, " ")
    feel = read_feel(for_feel)
    if not names_music(request):

        if request["playing"] == "different" and feel is not None:
            request["playing"] = None
        request["feel"] = feel
        request["phrase"] = phrase(said)
    elif not request["songs"] and not request["albums"]:

        request["feel"] = feel
    if request["kind"] is not None or request["playing"] is not None:
        request["phrase"] = None

    if request["startsWith"] is not None:
        alone = dict(request, startsWith=None)
        if is_empty(alone) or (not alone["artists"] and not is_read(alone) and alone["phrase"] is None):
            request["songs"] = [request["startsWith"]]
            request["startsWith"] = None
            request["feel"] = None
            request["phrase"] = None
    if is_empty(request):
        return None
    if request["era"] is not None:
        request["era"] = {"from": request["era"][0], "to": request["era"][1]}
    return request
