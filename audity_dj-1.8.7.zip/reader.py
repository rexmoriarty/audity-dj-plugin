









import re
import unicodedata
from collections import Counter
from datetime import datetime



_FEEL_WORDS = {

    "calm": (-1, None), "calmer": (-0.7, None), "chill": (-0.8, None), "chilled": (-0.8, None), "chillout": (-0.8, None),
    "relax": (-0.9, None), "relaxing": (-0.9, None), "relaxed": (-0.9, None), "mellow": (-0.7, None), "mellower": (-0.6, None),
    "soft": (-0.7, None), "softer": (-0.6, None), "quiet": (-0.8, None), "quieter": (-0.6, None), "gentle": (-0.8, None),
    "slow": (-0.8, None), "slower": (-0.6, None), "sleep": (-1, None), "sleepy": (-1, None), "bedtime": (-1, None),
    "study": (-0.6, None), "studying": (-0.6, None), "focus": (-0.5, None), "reading": (-0.7, None), "peaceful": (-0.9, 0.3),
    "soothing": (-0.9, None), "lazy": (-0.7, 0.2), "cozy": (-0.6, 0.3), "cosy": (-0.6, 0.3), "sunday": (-0.5, 0.3),
    "unwind": (-0.8, None), "dreamy": (-0.6, None), "acoustic": (-0.6, None), "laid": (-0.6, 0.2), "easygoing": (-0.5, 0.3),

    "sad": (-0.4, -1), "sadder": (None, -0.8), "melancholic": (-0.4, -0.9), "melancholy": (-0.4, -0.9),
    "heartbroken": (-0.3, -1), "heartbreak": (-0.3, -1), "breakup": (-0.3, -0.9), "lonely": (-0.5, -0.9),
    "cry": (-0.5, -1), "crying": (-0.5, -1), "depressing": (-0.5, -1), "depressed": (-0.5, -1), "gloomy": (-0.4, -0.8),
    "moody": (None, -0.6), "moodier": (None, -0.6), "dark": (None, -0.7), "darker": (None, -0.6), "somber": (-0.6, -0.8),
    "sombre": (-0.6, -0.8), "wistful": (-0.5, -0.5), "bittersweet": (-0.3, -0.4), "emotional": (-0.3, -0.5),
    "blue": (-0.3, -0.7), "rainy": (-0.5, -0.5), "rain": (-0.5, -0.5), "brooding": (None, -0.7), "haunting": (-0.4, -0.6),
    "nostalgic": (-0.3, -0.2), "reflective": (-0.5, -0.3), "introspective": (-0.5, -0.4), "sentimental": (-0.4, -0.3),

    "happy": (0.4, 1), "happier": (None, 0.8), "upbeat": (0.7, 0.8), "cheerful": (0.4, 0.9), "sunny": (0.4, 0.9),
    "summer": (0.4, 0.8), "summery": (0.4, 0.8), "fun": (0.6, 0.8), "joyful": (0.5, 1), "uplifting": (0.4, 0.9),
    "positive": (None, 0.8), "feelgood": (0.4, 0.9), "groovy": (0.5, 0.6), "funky": (0.6, 0.6), "bright": (None, 0.8),
    "brighter": (None, 0.6), "sunshine": (0.4, 0.9), "carefree": (0.3, 0.8), "playful": (0.4, 0.8), "beach": (0.3, 0.7),

    "energetic": (1, None), "energy": (1, None), "lively": (0.8, 0.4), "livelier": (0.7, None), "hype": (1, None),
    "hyped": (1, None), "pump": (1, None), "pumped": (1, None), "workout": (1, None), "gym": (1, None), "exercise": (1, None),
    "running": (1, None), "run": (0.9, None), "lifting": (1, None), "cardio": (1, None), "party": (0.9, 0.7),
    "dance": (0.9, 0.6), "dancing": (0.9, 0.6), "danceable": (0.9, 0.6), "loud": (0.9, None), "louder": (0.6, None),
    "fast": (0.8, None), "faster": (0.6, None), "intense": (0.9, -0.2), "aggressive": (1, -0.5), "angry": (1, -0.7),
    "rage": (1, -0.7), "heavy": (0.9, -0.4), "heavier": (0.7, -0.3), "driving": (0.6, 0.4), "drive": (0.6, 0.4),
    "banger": (0.9, None), "bangers": (0.9, None), "epic": (0.7, None), "cleaning": (0.6, 0.6), "celebrate": (0.7, 0.9),

    "romantic": (-0.4, 0.4), "romance": (-0.4, 0.4), "sexy": (-0.3, 0.3), "sensual": (-0.4, 0.3), "seductive": (-0.3, 0.2),
    "smooth": (-0.5, 0.3), "dinner": (-0.5, 0.2), "coffee": (-0.4, 0.2), "morning": (-0.3, 0.3),
}
_FEEL_PAIRS = {
    "feel good": (0.4, 0.9), "good vibes": (0.3, 0.8), "road trip": (0.6, 0.5), "wake up": (0.6, 0.5),
    "date night": (-0.3, 0.4), "love songs": (-0.3, 0.4), "wind down": (-0.8, None), "calm down": (-0.8, None),
    "slow down": (-0.7, None), "late night": (-0.5, -0.1), "slow dance": (-0.6, 0.4), "rock out": (0.9, None),
    "feeling down": (-0.4, -0.8), "it down": (-0.6, None), "it up": (0.6, None), "pick me": (0.5, 0.8),
    "laid back": (-0.6, 0.2), "easy going": (-0.5, 0.3), "get going": (0.6, 0.4),
}


def read_feel(said):
    """HostFeel.read: {"energy", "brightness"} from the words (as `plain` gives them), each word or pair for a mood,
    a moment or a pace moving one axis or both, "not" or "less" just before turning it, "a little" softening it.
    None when none is said."""
    words = said.split()
    energies, brightnesses = [], []
    index = 0
    while index < len(words):
        length = 1
        entry = _FEEL_WORDS.get(words[index])
        if index + 1 < len(words) and (words[index] + " " + words[index + 1]) in _FEEL_PAIRS:
            entry = _FEEL_PAIRS[words[index] + " " + words[index + 1]]
            length = 2
        if entry:
            before = words[max(0, index - 2):index]
            turn = -0.6 if any(w in ("not", "less", "no", "without", "nothing", "isnt", "too") for w in before)\
                else 0.6 if any(w in ("little", "bit", "slightly", "kinda", "somewhat") for w in before) else 1
            if entry[0] is not None:
                energies.append(entry[0] * turn)
            if entry[1] is not None:
                brightnesses.append(entry[1] * turn)
        index += length
    if not energies and not brightnesses:
        return None
    mean = lambda values: sum(values) / len(values) if values else None
    return {"energy": mean(energies), "brightness": mean(brightnesses)}




def genres_of(song):
    """HostPlanner.genres(of:): every genre a song is tagged with."""
    genres = song.get("genres") or [song.get("genre") or ""]
    return [genre for genre in genres if genre]


def year_of(song):
    """HostPlanner.year(of:): its original release year, else its album's."""
    year = int(song.get("year") or 0)
    return year if year > 0 else int(song.get("albumYear") or 0)


def _tidy(text):
    return " ".join(text.split())


def speech_artist(raw):
    """HostSpeech.artist: "feat." as "featuring", "&" as "and"."""
    text = re.sub(r"\b(feat\.?|ft\.?)(\s)", lambda m: "featuring" + m.group(2), raw, flags=re.IGNORECASE)
    return _tidy(text.replace(" & ", " and "))


def speech_genre(raw):
    """HostSpeech.genre: a genre tag as said mid-sentence, a word with capitals past its first letter kept."""
    def part(p):
        rest = p[1:]
        return p.lower() if rest == rest.lower() else p
    return " ".join("-".join(part(p) for p in word.split("-")) for word in raw.split(" "))




def plain(text):
    """HostRequest.plain: lower case, without accents or punctuation, with a space at each end, so a name is found
    only as whole words; a word's "'s" apart from it. An apostrophe at a word's start or end isn't part of it, one inside
    is ("80's", "jackson's"): "’80s", as the iPhone writes the eighties it hears, is "80s", "rock ’n’ roll" "rock n
    roll", "Foolin’" "foolin"."""
    folded = "".join(c for c in unicodedata.normalize("NFKD", text) if not unicodedata.combining(c)).lower()
    folded = folded.replace("&", " and ").replace("’", "'").replace("‘", "'").replace(".", "")
    words = "".join(c if (c.isalnum() or c == "'") else " " for c in folded).split()


    words = [word.strip("'") for word in words]
    return (" " + " ".join(word for word in words if word) + " ").replace("'s ", " s ")


_OPENERS = ["hey dj", "dj", "can you", "could you", "would you", "please", "i want to hear", "i wanna hear", "i'd like to hear",
            "let s hear", "lets hear", "let s play", "lets play", "play me", "play", "put on", "queue up", "queue",
            "give me", "some", "a little", "the song", "the album", "something by", "anything by", "more"]


def cores(said):
    """The words without the asking, each step of it: "can you play some purple rain please" is "purple rain", and
    "play some velvet morning" "some velvet morning" as well as "velvet morning"."""
    words = said.strip()
    steps = {words}
    changed = True
    while changed:
        changed = False
        for opener in _OPENERS:
            if words == opener or words.startswith(opener + " "):
                words = words[len(opener):].strip()
                steps.add(words)
                changed = True
        for closer in ("please", "next", "now", "for me", "and similar"):
            if words.endswith(" " + closer):
                words = words[:-len(closer)].strip()
                steps.add(words)
                changed = True
    for step in list(steps):
        at = step.find(" by ")
        if at >= 0:
            steps.add(step[:at])
    steps.discard("")
    return steps


def core_of(title):
    """A title without what follows its name: "Shoot to Thrill (Live)", "Dreams - 2004 Remaster" are "Shoot to
    Thrill", "Dreams"."""
    for opening in (" (", " [", " - ", " – ", " — "):
        at = title.find(opening)
        if at > 0:
            title = title[:at]
    return title.strip()


_SAME = {"too": "to", "two": "to", "2": "to", "four": "for", "4": "for", "u": "you", "ur": "your", "n": "and", "tha": "the"}


def loose(said):
    """Plain words as they sound, for titles heard: "too" and "two" as "to", "four" as "for"."""
    return " " + " ".join(_SAME.get(word, word) for word in said.split()) + " "


START_WORDS = [" starting with ", " starting off with ", " start with ", " start off with ", " start it with ",
               " beginning with ", " begin with ", " kick off with ", " kick it off with ", " kicking off with ",
               " open with ", " opening with ", " lead with ", " lead off with ", " leading off with "]


def is_started(title, said):
    """Whether `title` is said right after words that start a set with it ("some AC/DC, starting with Shoot to
    Thrill"), as heard too."""
    titles = {t for t in (plain(title).strip(), plain(core_of(title)).strip()) if t}
    heard = loose(said)
    loose_titles = {loose(" " + t + " ").strip() for t in titles}
    return any(any(phrase + t + " " in said or phrase + "the song " + t + " " in said for t in titles)
               or any(phrase + t + " " in heard or phrase + "the song " + t + " " in heard for t in loose_titles)
               for phrase in START_WORDS)


OUT_WORDS = {"no", "no more", "not", "never", "anything but", "anything except", "anything besides", "except", "besides",
             "other than", "without", "stop playing", "stop", "enough", "enough with", "skip", "tired of", "sick of",
             "instead of", "not feeling", "done with", "over", "get rid of", "lose the", "ditch"}
LESS_WORDS = {"less", "fewer", "not so much", "not as much", "a bit less", "a little less", "too much", "cut down on"}
_TURN_FILLER = {"the", "some", "any", "of", "songs", "song", "music", "stuff", "by", "from", "all", "that", "this", "so",
                "much", "for", "now"}


def turn(name, said):
    """How the words just before `name` turn from it: "out" ("no more", "anything but") or "less"; None when they
    ask for it."""
    at = said.find(" " + name + " ")
    if at < 0:
        return None
    words = said[:at].split()
    for _ in range(2):
        for count in range(min(4, len(words)), 0, -1):
            tail = " ".join(words[-count:])
            if tail in LESS_WORDS:
                return "less"
            if tail in OUT_WORDS:
                return "out"
        while words and words[-1] in _TURN_FILLER:
            words.pop()
    return None


def joins(name, said):
    """Whether `name` follows another with "and", "or" or "nor" between ("no country or folk")."""
    at = said.find(" " + name + " ")
    if at < 0:
        return False
    before = said[:at].split()
    return bool(before) and before[-1] in ("and", "or", "nor", "also")


PLAYING_WORDS = {
    "more": [" more like this ", " more of this ", " more like that ", " more of that ", " keep this going ", " keep it going ",
             " keep going ", " keep this vibe ", " this vibe ", " same vibe ", " similar to this ", " songs like this ",
             " like this ", " love this ", " loving this ", " this is great ", " more stuff like this "],
    "different": [" something different ", " something else ", " anything else ", " switch it up ", " change it up ",
                  " mix it up ", " shake it up ", " not this ", " not feeling this ", " not feeling it ", " not this one ",
                  " surprise me ", " change the vibe ", " different vibe ", " something new for a change "],
    "older": [" something older ", " older ", " go back further ", " further back ", " back in time "],
    "newer": [" something newer ", " newer ", " more recent ", " something recent "],
}


def about(said):
    """What's playing, in the words: "more" like it, something "different", "older" or "newer"."""
    for kind in ("different", "more", "older", "newer"):
        if any(phrase in said for phrase in PLAYING_WORDS[kind]):
            return kind
    return None


def kind(said):
    """A kind of set named by what it is (HostTheme.kind): your most played lately, what you've just added, deep cuts."""
    if any(p in said for p in (" most played", " on repeat", " top songs", " my top ", " been playing", " been listening to",
                               " heavy rotation", " the usual", " go to songs", " my go to ")):
        return "onRepeat"
    if any(p in said for p in (" new releases", " new music ", " new stuff", " new albums", " new additions", " just added",
                               " recently added", " latest ", " newest ")):
        return "fresh"
    if any(p in said for p in (" deep cuts", " deep cut ", " hidden gems", " b sides")):
        return "deepCuts"
    return None


ASKING = {
    "hey", "hi", "yo", "dj", "ok", "okay", "alright", "all", "right", "so", "um", "uh", "well", "now", "then", "can", "could",
    "would", "will", "you", "we", "i", "id", "i'd", "im", "i'm", "ill", "i'll", "me", "us", "my", "let", "lets", "let's", "s",
    "want", "wanna", "like", "love", "to", "hear", "listen", "listening", "play", "playing", "put", "on", "throw", "spin",
    "queue", "add", "up", "give", "some", "a", "an", "the", "little", "bit", "of", "song", "track", "tune", "by", "from",
    "next", "after", "this", "that", "please", "for", "just", "go", "ahead", "and", "how", "about", "maybe", "again",
    "instead", "is", "it", "be", "in", "mood", "really", "need", "with", "thanks", "thank", "start", "starting", "one",
    "similar",
}
_PHRASE_LEADING = (ASKING - {"some", "a", "an", "my", "the", "little", "bit"}) | {
    "change", "switch", "turn", "make", "vibe", "into", "feel", "feeling", "feelin", "something", "music", "songs"}
_WHAT_FOR = {"to", "with", "for", "like", "in", "on", "from"}
_PHRASE_TRAILING = {"please", "now", "next", "thanks", "thank", "you", "for", "me", "instead", "then", "right", "up", "this",
                    "after", "on"}


def said_back(genres, years, as_said):
    """Genres and years alone as the DJ says them back, however they were said or written: "some R and B from the
    nineties", "some music from the eighties". ~~As said~~: "some 80 s", "some rock out", "some what was i into in 2024"."""
    names = list(dict.fromkeys(_SPOKEN.get(name, name) for _, name, tags in genres if tags))
    if not names and not years:
        return as_said
    when = ""
    if years:
        first, last = years
        start = first // 10 * 10
        part = {(0, 9): "", (0, 3): "early ", (4, 6): "mid ", (7, 9): "late "}.get((first - start, last - start))
        if first == last:
            when = " from " + str(first)
        elif last >= 2100 or first <= 1900 < last - 9:
            return as_said
        elif part is None or start < 1900:
            when = f" from {first} to {last}"
        else:
            when = " from the " + part + _decade_said(start)
    if not names:
        return "some music" + when
    if len(names) == 1:
        return "some " + names[0] + when
    return "some " + ", ".join(names[:-1]) + " and " + names[-1] + when


def _decade_said(start):
    """HostSpeech.decade."""
    names = ("tens", "twenties", "thirties", "forties", "fifties", "sixties", "seventies", "eighties", "nineties")
    if start == 2000:
        return "two thousands"
    if start == 1900:
        return "nineteen hundreds"
    return ("twenty " if start > 2000 else "") + names[start % 100 // 10 - 1]


def phrase(said):
    """A sound asked for, as said, to say back: "change the vibe to something more upbeat" is "something more
    upbeat", "give me some gym music" "some gym music", "melancholic" "something melancholic". None past seven
    words, or none."""
    words = said.split()
    while words and (words[0] in _PHRASE_LEADING or (words[0] in ("the", "my") and len(words) > 1 and words[1] in _PHRASE_LEADING)):


        if words[0] in ("something", "anything", "music", "songs") and len(words) > 1\
                and (words[1] not in _PHRASE_LEADING or words[1] in _WHAT_FOR):
            break
        words.pop(0)
    while words and words[-1] in _PHRASE_TRAILING:
        words.pop()
    if not words or len(words) > 7:
        return None
    text = " ".join(words)
    if words[0] in ("something", "some", "a", "an", "music", "songs", "anything", "my", "the", "your"):
        return text
    if read_feel(" " + words[0] + " ") is not None or words[0] in ("more", "less", "kind", "kinda", "bit", "little"):
        return "something " + text
    return "some " + text


def found(said, names):
    """The names among `names` said whole in `said`, none inside a longer one said ("Rock" in "Indie Rock")."""
    hits = []
    for name in names:
        plain_name = plain(name).strip()
        if len(plain_name) >= 3 and " " + plain_name + " " in said:
            hits.append((name, plain_name))
    once = {}
    for name, plain_name in hits:
        once.setdefault(plain_name, name)
    return sorted(name for plain_name, name in once.items()
                  if not any(other != plain_name and " " + plain_name + " " in " " + other + " " for other in once))







_DECADE_WORDS = {"thirties": 1930, "forties": 1940, "fourties": 1940, "fifties": 1950, "sixties": 1960, "seventies": 1970,
                 "eighties": 1980, "eightys": 1980, "nineties": 1990, "ninties": 1990, "ninetys": 1990, "two thousands": 2000,
                 "noughties": 2000, "naughties": 2000, "aughts": 2000, "oughts": 2000, "twenty tens": 2010, "twenty teens": 2010,
                 "two thousand tens": 2010, "two thousand and tens": 2010, "twenty twenties": 2020, "twenties": 2020,
                 "nineteen tens": 1910, "nineteen twenties": 1920, "roaring twenties": 1920, "nineteen thirties": 1930,
                 "nineteen forties": 1940, "nineteen fifties": 1950, "nineteen sixties": 1960, "nineteen seventies": 1970,
                 "nineteen eighties": 1980, "nineteen nineties": 1990,

                 "thirty s": 1930, "forty s": 1940, "fifty s": 1950, "sixty s": 1960, "seventy s": 1970, "eighty s": 1980,
                 "ninety s": 1990}

_DECADE = re.compile(r"(?<= )(?:(?P<word>" + "|".join(sorted(_DECADE_WORDS, key=len, reverse=True)) + r")"
                     r"|(?P<century>1[6-9]|20)?(?P<tens>[0-9])0 ?'?s"

                     r"|(?P<bare>[5-9])0(?= (?:music|hits|classics|jams|anthems|rock|pop|soul|funk|disco|hip|rap|jazz|country|metal|punk|dance) )"
                     r"|(?P<spelled>fifty|sixty|seventy|eighty|ninety)(?= (?:music|hits|classics|jams|anthems) )"
                     r"|(?P<year>1[6-9][0-9][0-9]|20[0-3][0-9]))(?= )")
_UNITS = ("one", "two", "three", "four", "five", "six", "seven", "eight", "nine")
_TENS = {"twenty": 20, "thirty": 30, "forty": 40, "fifty": 50, "sixty": 60, "seventy": 70, "eighty": 80, "ninety": 90}
_YEAR_WORDS = re.compile(r"(?<= )nineteen (" + "|".join(_TENS) + r")(?: (" + "|".join(_UNITS) + r"))?(?= )")
_YEAR_WORDS_2000 = re.compile(r"(?<= )two thousand (?:and )?(" + "|".join(_UNITS) + r")(?= )")
_PARTS = {"early": (0, 3), "mid": (4, 6), "middle": (4, 6), "late": (7, 9)}
_BEFORE = ("before", "pre", "prior to", "older than", "earlier than")
_AFTER = ("after", "post", "newer than", "later than")
_SINCE = ("since",)


def as_years(said):
    """A year said in words as written: "nineteen eighty five" is 1985, "two thousand and five" 2005."""
    said = _YEAR_WORDS.sub(lambda m: str(1900 + _TENS[m.group(1)] + (_UNITS.index(m.group(2)) + 1 if m.group(2) else 0)), said)
    return _YEAR_WORDS_2000.sub(lambda m: str(2001 + _UNITS.index(m.group(1))), said)


def years_said(said):
    """Each decade or year said, as (where, from, to)."""
    out = []
    for match in _DECADE.finditer(said):
        before = said[:match.start()].split()
        one = before[-1] if before else ""
        if match.group("word"):
            start, last = _DECADE_WORDS[match.group("word")], 9
        elif match.group("tens"):

            if not match.group("century") and one in ("my", "his", "her", "their", "your"):
                continue
            digit = int(match.group("tens"))
            century = int(match.group("century")) * 100 if match.group("century") else (1900 if digit >= 3 else 2000)
            start, last = century + digit * 10, 9

            if century < 1900 and digit == 0:
                last = 99
        elif match.group("spelled"):
            if one == "top":
                continue
            start, last = 1900 + _TENS[match.group("spelled")], 9
        elif match.group("bare"):
            if one == "top":
                continue
            start, last = 1900 + int(match.group("bare")) * 10, 9
        else:
            start, last = int(match.group("year")), 0
        first = start
        if last and one in _PARTS:
            low, high = _PARTS[one]
            first, last = start + low, high
            before.pop()
        out.append((len(" ".join(before)), first, start + last))
    return out



_YEARS_OUT = OUT_WORDS | LESS_WORDS | {"rather than", "but not", "nothing from", "none of"}

_YEARS_GOT = {"and got", "i got", "we got", "you played", "keep playing", "kept playing", "that s", "this is", "those are", "these are"}


def years_turned(said):
    """The years said, as (asked for, left out), each where it is as `years_said` has it: "80s not 90s" is the eighties
    asked and the nineties left out."""



    said = as_years(said)
    asked, out, got = [], [], []
    was_out = False
    for mention in years_said(said):
        words = said[:mention[0] + 1].split()
        if words and words[-1] in ("early", "mid", "middle", "late"):
            words.pop()
        if was_out and words and words[-1] in ("or", "nor", "and"):
            out.append(mention)
            continue
        is_out, is_got = False, False
        while words:
            if " ".join(words[-2:]) == "why not":
                break
            tails = {" ".join(words[-count:]) for count in range(1, min(4, len(words)) + 1)}
            is_out = is_out or not tails.isdisjoint(_YEARS_OUT)
            is_got = is_got or not tails.isdisjoint(_YEARS_GOT)

            if words[-1] not in _TURN_FILLER:
                break
            words.pop()
        (out if is_out else got if is_got else asked).append(mention)
        was_out = is_out
    return (asked, out + got) if asked else (got, out)


def leaves_years(said):
    """Years said as left out and none asked for ("anything but the 80s"): something else."""
    asked, out = years_turned(said)
    return bool(out) and not asked


def era(said, now=None):
    """The years said, as (from, to): a decade however it's said or written, its early, mid or late part, a year,
    several as from the first to the last ("70s and 80s", "between 1975 and 1979"), before, after or since one,
    "this year", "last year". None said as left out ("anything but the 80s")."""
    year = (now or datetime.now()).year
    if " this year " in said:
        return (year, year)
    if " last year " in said:
        return (year - 1, year - 1)
    said = as_years(said)
    mentions, _ = years_turned(said)
    if not mentions:
        return None
    low, high = min(m[1] for m in mentions), max(m[2] for m in mentions)
    words = said[:mentions[0][0] + 1].split()
    if words and words[-1] == "the":
        words.pop()
    tail = " " + " ".join(words)
    if len(mentions) == 1:
        if any(tail.endswith(" " + p) for p in _BEFORE):
            return (1900, low - 1) if low > 1900 else (0, low - 1)
        if any(tail.endswith(" " + p) for p in _AFTER):
            return (high + 1, 2100)
        if any(tail.endswith(" " + p) for p in _SINCE):
            return (low, 2100)
    return (low, high)







_SPELLINGS = [(re.compile("(?<= )(?:" + ways + ")(?= )"), one) for ways, one in (
    (r"rhythm and blues|rhythm n blues|r and b|r n b|r b|rnb|randb", "rnb"),
    (r"hip hop|hiphop|hip pop", "hiphop"),
    (r"rock and roll|rock n roll|rock roll|rocknroll", "rocknroll"),
    (r"drum and bass|drum n bass|dnb", "drumnbass"),
    (r"singer songwriters?|singer song writers?", "singersongwriter"),
    (r"synthpop", "synth pop"),
    (r"neosoul", "neo soul"),
    (r"nu metal|new metal", "nu metal"),
    (r"kpop", "k pop"),
    (r"jpop", "j pop"),
    (r"lofi", "lo fi"),
    (r"doowop", "doo wop"),
    (r"electronica", "electronic"),
    (r"country and western", "country"),
    (r"blue eyed soul", "blueeyedsoul"),
    (r"alt(?= (?:rock|country|pop|metal) )", "alternative"),
)]
_SPOKEN = {"rnb": "R and B", "hiphop": "hip-hop", "rocknroll": "rock and roll", "drumnbass": "drum and bass",
           "singersongwriter": "singer-songwriter music", "blueeyedsoul": "blue-eyed soul"}

_SAME_GENRE = {"rap": ("rap", "hiphop"), "hiphop": ("hiphop", "rap"), "rock": ("rock", "rocknroll"), "edm": ("edm", "electronic")}

_ELSE_GENRE = {"rocknroll": "rock", "blueeyedsoul": "soul", "orchestral": "classical", "symphonic": "classical"}

_GENRES = {"rock", "pop", "soul", "funk", "rnb", "hiphop", "rap", "jazz", "vocal jazz", "smooth jazz", "blues", "country", "folk",
           "disco", "techno", "electronic", "edm", "trance", "dubstep", "drumnbass", "reggae", "reggaeton", "ska", "dancehall",
           "gospel", "classical", "baroque", "opera", "metal", "heavy metal", "nu metal", "death metal", "black metal", "punk",
           "post punk", "pop punk", "emo", "indie rock", "indie pop", "alternative rock", "soft rock", "classic rock", "hard rock",
           "progressive rock", "prog rock", "punk rock", "folk rock", "southern rock", "yacht rock", "rocknroll", "rockabilly",
           "new wave", "synth pop", "synthwave", "neo soul", "motown", "doo wop", "singersongwriter", "bossa nova", "grunge",
           "shoegaze", "britpop", "bluegrass", "americana", "salsa", "cumbia", "bachata", "afrobeats", "afrobeat", "k pop",
           "j pop", "polka", "klezmer", "bebop", "blueeyedsoul"}

_LOOSE_GENRES = {"dance", "house", "ambient", "indie", "alternative", "latin", "swing", "big band", "acoustic", "instrumental",
                 "soundtrack", "soundtracks", "christmas", "holiday", "worship", "orchestral", "symphonic", "oldies", "lo fi",
                 "trip hop", "downtempo"}

_NOT_TAGS = {"music", "other", "others", "unknown", "general", "misc", "miscellaneous", "various", "genre", "none", "favorites",
             "favourites", "songs", "new", "best"}
_NOT_GENRES = (" around the house ", " in the house ", " house party ", " house cleaning ", " clean the house ",
               " cleaning the house ", " dance to ", " cross country ", " country drive ")


def as_genres(said):
    """Plain words with each genre spelled one way."""
    for ways, one in _SPELLINGS:
        said = ways.sub(one, said)
    return said


def genres_said(said, library):
    """The genres said, (where, as spelled here, your tags of it), longest first where two overlap: no tags for one
    you haven't any of."""
    words = said
    for phrase_ in _NOT_GENRES:
        words = words.replace(phrase_, " " + "~" * (len(phrase_) - 2) + " ")
    out = []
    for name in library.genre_names:
        at = words.find(" " + name + " ")
        if at < 0:
            continue
        words = words.replace(" " + name + " ", " " + "~" * len(name) + " ")
        tags = library.tagged(name)
        if tags or (library.genres and name in _GENRES):
            out.append((at, name, tags))
    return sorted(out)


def mix(said):
    """Your favorites, throwbacks, or ones you've barely played (HostMix's raw values)."""
    if any(p in said for p in (" throwback", " in a while", " in ages", " in forever", " in years", " forgotten ", " rediscover",
                               " used to ", " old favorite", " old favourite")):
        return "throwbacks"
    if any(p in said for p in (" favorite", " favourite", " loved ", " love the most ")):
        return "favorites"
    if any(p in said for p in (" haven't heard", " havent heard", " barely ", " never played", " haven't played", " havent played",
                               " discover", " new to me", " never heard", " something new ", " rarely ")):
        return "rediscover"
    return None


_NOT_NAMES = {"music", "songs", "song", "something", "anything", "everything", "some", "the", "a", "an", "more", "random",
              "favorites", "favourites", "stuff", "tunes", "hits", "playlist", "mix", "shuffle", "radio", "new"}


def is_generic(name, library):
    """Whether a name is only words that ask for music by its kind or years ("Music", "Jazz", "The Eighties"): it's
    that name only said as one ("the album Jazz", "Jazz by Queen")."""
    words = [w for w in name.split() if w not in _NOT_NAMES]
    if not words:
        return True
    rest = " " + " ".join(words) + " "
    if as_genres(rest).strip() in library.genre_names:
        return True
    return re.sub(r" +", " ", _DECADE.sub("", rest)).strip() in ("", "s") and not rest.strip().isdigit()


_FRAME = ASKING | _NOT_NAMES | {"gimme", "good", "great", "best", "early", "mid", "late", "eighty", "s"}


def only_asks(name):
    """Whether a name has no word but those that ask and a decade's ("Give Me Some", "Some 80s Music"). With music asked
    for by its kind (`asks_by_kind`), those words are the asking, never that name, ~~a name wherever they were found~~: a nineties song called Give Me
    Some took "give me some 80s music" and played songs like it. A year is a name's own (1999, The 1975)."""
    rest, at = [], 0
    padded = " " + name + " "
    for match in _DECADE.finditer(padded):
        if match.group("year"):
            return False
        rest.append(padded[at:match.start()])
        at = match.end()
    rest.append(padded[at:])
    return all(word in _FRAME for word in " ".join(rest).split())


def asks_by_kind(said, library):
    """Whether the words ask for music by its years, a genre or a mood, or just for music."""
    return any(word in ("music", "songs", "tunes", "stuff", "hits", "something", "anything") for word in said.split())\
        or bool(years_said(as_years(said))) or any(tags for _, _, tags in genres_said(as_genres(said), library))\
        or bool(found(said, library.moods)) or read_feel(said) is not None


def artist_names(said, asked, library, by_kind=False):
    """Every artist named, with the name as found in the words, longest first, none inside a longer one found, with
    or without a leading "the"; joined where its name has a slash or a dash ("AC/DC" heard as "ACDC"); a short name
    (under five letters) only when it's all that's asked. In the order said."""
    found_ = []
    for artist_id, name in library.artists.items():
        plain_name = plain(name).strip()
        if plain_name.startswith("the ") and len(plain_name) > 7 and " " + plain_name + " " not in said\
                and not plain_name[4:].isdigit():
            plain_name = plain_name[4:]
        joined = plain_name.replace(" ", "")
        is_joined = False
        if " " + plain_name + " " not in said and any(c in "/-" for c in name) and len(joined) >= 4 and " " + joined + " " in said:
            plain_name = joined
            is_joined = True
        if not plain_name or " " + plain_name + " " not in said:
            continue

        if not (plain_name in asked or (len(plain_name) >= 3 and (len(plain_name) >= 5 or is_joined))):
            continue
        if (is_generic(plain_name, library) or (by_kind and only_asks(plain_name))) and not any(" " + p + plain_name + " " in said for p in ("by ", "artist ", "band ")):
            continue
        found_.append((artist_id, plain_name))
    kept = []
    for artist in sorted(found_, key=lambda a: -len(a[1])):
        if not any(" " + artist[1] + " " in " " + k[1] + " " for k in kept):
            kept.append(artist)
    return sorted(kept, key=lambda a: said.find(" " + a[1] + " "))


class Library:
    """The app's song list, read once for each version (`/app/library`), with what the reader looks up by."""

    def __init__(self, songs, version=""):
        self.version = version
        self.songs = songs
        self.by_id = {song["id"]: song for song in songs}
        credits = {}
        for song in songs:
            credits.setdefault(song.get("artistId") or "", Counter())[song.get("artist") or ""] += 1
        credits.pop("", None)

        self.artists = {artist_id: names.most_common(1)[0][0] for artist_id, names in credits.items()}
        self.genres = sorted({genre for song in songs for genre in genres_of(song)})
        self.moods = sorted({mood for song in songs for mood in (song.get("moods") or [])})
        self._plain = {}
        self._genre_plain = {}
        for tag in self.genres:
            name = as_genres(plain(tag)).strip()
            if len(name) >= 3 and name not in _NOT_TAGS and _DECADE.sub("", " " + name + " ").strip():
                self._genre_plain[tag] = name
        self._tagged = {}
        self.genre_names = dict.fromkeys(sorted(_GENRES | _LOOSE_GENRES | set(self._genre_plain.values()),
                                               key=lambda name: (-len(name), name)))

    def tagged(self, name):
        """Your tags that are the genre `name`, however narrow ("rock": Rock, Hard Rock, Classic Rock)."""
        kept = self._tagged.get(name)
        if kept is None:
            def of(names):
                return [tag for tag, spelled in self._genre_plain.items()
                        if any(" " + one + " " in " " + spelled + " " for one in names)]
            kept = of(_SAME_GENRE.get(name, (name,)))
            if not kept and name in _ELSE_GENRE:
                kept = of((_ELSE_GENRE[name],))
            self._tagged[name] = kept
        return kept

    def titles(self, title):
        """`title` plain as tagged and without what follows its name, worked out once."""
        kept = self._plain.get(title)
        if kept is None:
            kept = self._plain[title] = (plain(title).strip(), plain(core_of(title)).strip())
        return kept


def _empty():
    return {"songs": [], "albums": [], "artists": [], "genres": [], "moods": [], "era": None, "mix": None, "feel": None,
            "later": False, "wholeAlbum": False, "phrase": None, "reply": None,
            "without": {"artists": [], "genres": [], "lessArtists": [], "lessGenres": [], "said": [], "isLess": False},
            "playing": None, "kind": None, "startsWith": None, "refines": False}


def names_music(request):
    return bool(request["songs"] or request["albums"] or request["artists"])


def without_empty(request):
    without = request["without"]
    return not (without["artists"] or without["genres"] or without["lessArtists"] or without["lessGenres"])


def is_empty(request):
    return (not names_music(request) and not request["genres"] and not request["moods"] and request["era"] is None
            and request["mix"] is None and not request["feel"] and without_empty(request) and request["playing"] is None
            and request["kind"] is None and request["startsWith"] is None)


def is_read(request):
    """Whether the words said what to play in a way read here; the rest, a feel AudioMuse-AI's text search reads."""
    return (names_music(request) or bool(request["genres"]) or bool(request["moods"]) or bool(request["feel"])
            or request["era"] is not None or request["mix"] is not None or not without_empty(request)
            or request["playing"] is not None or request["kind"] is not None or request["startsWith"] is not None)




_COMPARATIVES = {"calmer", "mellower", "softer", "quieter", "slower", "sadder", "moodier", "darker", "happier", "brighter",
                 "livelier", "louder", "faster", "heavier", "lighter", "jazzier", "funkier"}
_SOFTLY = ("more", "less", "bit", "little", "slightly")
_ASKED_FIRST = ("ok", "okay", "alright", "now", "and", "can you", "could you", "would you", "please", "hey dj", "dj", "yeah", "actually")


def builds(said):
    """Whether the words build on what's asked or playing rather than ask anew: "but from the 80s", "make it
    calmer", "more upbeat", "from the 80s though"."""
    words = said.strip()
    changed = True
    while changed:
        changed = False
        for first in _ASKED_FIRST:
            if words.startswith(first + " "):
                words = words[len(first):].strip()
                changed = True
    if words.startswith(("but ", "make it ", "make them ", "keep it ", "just make it ")) or words.endswith(" though"):
        return True
    if any(p in said for p in (" change the vibe ", " different ", " switch ", " instead ")):
        return False
    each = words.split()
    return any(word in _COMPARATIVES for word in each) or any(
        before in _SOFTLY and read_feel(" " + word + " ") is not None for before, word in zip(each, each[1:]))




_ANYTHING = {"music", "some music", "any music", "my music", "something", "anything", "whatever", "shuffle", "random", "random music",
             "shuffle my library", "shuffle everything", "shuffle my music", "anything you want", "whatever you want", "you pick"}



SUGGESTED = {"something upbeat for the morning", "something with energy", "something mellow for tonight", "something to wind down"}

_CAPITALS = {"i", "i'm", "i'd", "i'll", "i've", "dj", "monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday",
             "january", "february", "march", "april", "may", "june", "july", "august", "september", "october", "november",
             "december", "christmas", "halloween", "thanksgiving", "easter", "hanukkah", "valentine", "valentines", "new",
             "year", "years", "eve", "early", "mid", "late", "african", "latin", "french", "spanish", "italian", "japanese",
             "brazilian", "irish", "american", "british", "god", "ok", "okay", "tv"}

_SOUND_WORDS = {"something", "anything", "music", "vibe", "vibes", "vibey", "mood", "moods", "sound", "sounds", "sounding", "songs",
                "tunes", "stuff", "tracks", "beats", "jams", "grooves", "for", "while", "instrumental", "instrumentals", "piano",
                "guitar", "guitars", "strings", "sax", "saxophone", "drums", "bass", "vocals", "orchestral", "acoustic", "synths",
                "night", "nighttime", "evening", "afternoon", "morning", "winter", "autumn", "fall", "spring", "summer", "rain",
                "rainy", "snow", "snowy", "storm", "sunset", "sunrise", "campfire", "fireplace", "beach", "pool", "road", "trip",
                "driving", "drive", "cooking", "cleaning", "working", "work", "studying", "coding", "yoga", "meditation", "spa",
                "cafe", "coffeehouse", "lounge", "club", "bar", "barbecue", "bbq", "wedding", "dinner", "party", "gaming",
                "walking", "hiking", "chilling", "relax", "spacey", "dreamy", "atmospheric", "cinematic", "trippy", "psychedelic",
                "ethereal", "tropical", "oldies", "spooky", "warm", "cold", "floaty", "hypnotic", "anthemic", "catchy", "nostalgia"}
_GENERIC_CAPITALS = _SOUND_WORDS | _NOT_NAMES | ASKING


def looks_named(words, library):
    """Whether the words name music, found or not: something by someone, "the song", "and similar", or a name as
    the iPhone writes one, with a capital inside the sentence."""
    said = plain(words)
    if said.endswith(" and similar ") or any(p in said for p in (" the song ", " the album ", " songs by ", " music by ")):
        return True
    match = re.search(r" by (\S+)", said)
    if match and match.group(1) not in ("the", "a", "an", "my"):
        return True
    tokens = [token for token in re.split(r"\s+", words.strip()) if any(c.isalpha() for c in token)]
    if len(tokens) > 2 and all(next(c for c in token if c.isalpha()).isupper() for token in tokens):
        return False
    starts = True
    for token in tokens:
        first, starts = starts, token[-1] in ".!?"
        if first or not next(c for c in token if c.isalpha()).isupper():
            continue
        word = plain(token).strip()
        head = word.split()[0] if word else ""
        if not head or head in _CAPITALS or head in _GENERIC_CAPITALS or read_feel(" " + head + " ") is not None:
            continue
        spelled = as_genres(" " + word + " ")
        if _DECADE.sub("", spelled).strip() in ("", "s")\
                or any(" " + spelled.strip() + " " in " " + name + " " for name in library.genre_names):
            continue
        return True
    return False


def searchable(words, library):
    """Whether words read as nothing are a sound, for AudioMuse-AI's text search, which knows how music sounds and
    no names or years: never a name, years, a number or a genre you haven't any of (those aren't in the library,
    and the app says so). ~~Whatever wasn't read~~, so a name you don't have played whatever sounded like its words."""
    said = as_years(plain(words))
    if any(c.isdigit() for c in said) or years_said(said) or looks_named(words, library):
        return False
    if any(not tags for _, _, tags in genres_said(as_genres(said), library)):
        return False
    return read_feel(said) is not None or any(word in _SOUND_WORDS for word in said.split())


def suggested_artist(said, library, words):
    """The artist of "X and similar" or "More like X", as the DJ's page suggests them, exactly, however short."""
    match = re.match(r"^ (?:more like (.+)|(.+) and similar) $", said)
    raw = re.match(r"^\s*(?:more like (.+?)|(.+?) and similar)\s*$", words, flags=re.IGNORECASE)
    name = next((g for g in match.groups() if g), None) if match else None
    as_written = next((g.casefold() for g in raw.groups() if g), None) if raw else None
    if not name and not as_written:
        return None
    ids = [artist_id for artist_id, artist in library.artists.items() if as_written and artist.casefold() == as_written]
    if not ids and name:
        ids = [artist_id for artist_id, artist in library.artists.items() if plain(artist).strip() == name]
    return ids[0] if ids else None


def read(words, library, playing=None, now=None):
    """HostRequest.read: the request as a dict (HostRequest's fields, `era` as {"from", "to"}), or None when nothing in
    the words is in the library or says a mood. `playing` is the song on (a library song), for words about it."""

    said = plain(re.sub(r"^\s*(?:no|nope|nah)\s*[,.!;:]+\s*(?=\S)", "", words, flags=re.IGNORECASE))
    if not said.strip():
        return None

    if playing:
        artist = plain(playing.get("artist") or "").strip()
        if artist:
            for p in (" this artist ", " this band ", " this singer ", " this group ", " these guys "):
                said = said.replace(p, " " + artist + " ")
        genres = genres_of(playing)
        genre = plain(genres[0]).strip() if genres else ""
        if genre:
            for p in (" this genre ", " this kind of music ", " this style ", " this type of music "):
                said = said.replace(p, " " + genre + " ")
    asked = cores(said)
    request = _empty()
    similar = suggested_artist(said, library, words)
    if similar:
        request["artists"] = [similar]
        return request
    is_suggested = said.strip() in SUGGESTED

    by_kind = asks_by_kind(said, library)
    named = [] if is_suggested else artist_names(said, asked, library, by_kind)
    loosely = loose(said)

    def is_named_plain(title, extra):
        if len(title) < 2:
            return False
        if title in asked or (len(title) >= 12 and " " + title + " " in said):
            return True
        if len(title) >= 12 and " " + loose(" " + title + " ").strip() + " " in loosely:
            return True
        if " " + title + " " not in said or not any(word not in ASKING for word in title.split())\
                or read_feel(" " + title + " ") is not None:
            return False
        rest = said.replace(" " + title + " ", " ")
        for _, name in named:
            rest = rest.replace(" " + name + " ", " ")
        return all(word in ASKING or word in extra for word in rest.split())

    def is_named(title, extra=frozenset()):
        whole, short = library.titles(title)
        return is_named_plain(whole, extra) or (short != whole and len(short) >= 4 and is_named_plain(short, extra))

    artist_called = {name for _, name in named}
    years_here = years_turned(said)[0]

    def is_meant(title, of):
        """A title that's also its artist's name, or only words that ask for music by its kind or years, is that
        song or album only said as one: ~~"play some jazz" an album called Jazz, "play Boston" their album~~."""
        whole, short = library.titles(title)
        name = short if " " + whole + " " not in said else whole
        if not (whole in artist_called or short in artist_called or is_generic(name, library)):
            if not by_kind or not only_asks(name):
                return True


            if " " + name + " from " in said and any(first <= year_of(of) <= last for _, first, last in years_here):
                return True
        artist = plain(of.get("artist") or "").strip()
        ways = [p + name for p in ("the song ", "the track ", "the album ", "the record ")] + [name + " by " + artist]
        if artist.startswith("the "):
            ways.append(name + " by " + artist[4:])
        return any(" " + way + " " in said for way in ways) or is_started(title, said)

    def by_named(matches):
        for song in matches:
            if any(artist_id == song.get("artistId") for artist_id, _ in named):
                return song
        return matches[0] if matches and not named else None

    says_album = any(p in said for p in (" album ", " record ", " lp "))
    album_words = frozenset({"album", "record", "lp", "whole", "entire", "full", "all"})
    songs = library.songs
    tried = [] if is_suggested else songs
    song = None if says_album else by_named([s for s in tried if is_named(s.get("title") or "") and is_meant(s.get("title") or "", s)])
    if song and is_started(song.get("title") or "", said):
        request["startsWith"] = song["id"]
    elif song:
        request["songs"] = [song["id"]]
    else:
        album = by_named([s for s in tried if is_named(s.get("album") or "", album_words) and is_meant(s.get("album") or "", s)])
        if album:
            request["albums"] = [album.get("albumId")]
            request["wholeAlbum"] = any(p in said for p in (" whole ", " entire ", " full ", " all of "))
        elif says_album:
            song = by_named([s for s in tried if is_named(s.get("title") or "", album_words) and is_meant(s.get("title") or "", s)])
            if song:
                request["songs"] = [song["id"]]

    whose = {s.get("artistId") for s in songs if s["id"] in request["songs"] or (request["albums"] and s.get("albumId") in request["albums"])}
    request["artists"] = [artist_id for artist_id, _ in named if artist_id not in whose]


    outside = said
    titles = [s.get("title") or "" for s in songs if s["id"] in request["songs"] or s["id"] == request["startsWith"]]
    if request["albums"]:
        titles += [s.get("album") or "" for s in songs if s.get("albumId") in request["albums"]][:1]
    for title in titles:
        outside = outside.replace(" " + plain(title).strip() + " ", " ")
        outside = outside.replace(" " + plain(core_of(title)).strip() + " ", " ")
    for p in START_WORDS:
        outside = outside.replace(p, " ")
    for _, name in named:
        outside = outside.replace(" " + name + " ", " ")
    request["later"] = any(p in outside for p in (" next ", " after this ", " after that ", " afterwards ", " later ", " queue ", " add "))



    found_era = era(outside, now)
    request["era"] = found_era
    request["mix"] = mix(outside)
    spelled = as_genres(outside)
    genres_here = [] if is_suggested else genres_said(spelled, library)
    request["genres"] = sorted({tag for _, _, tags in genres_here for tag in tags})
    request["moods"] = found(outside, library.moods)



    names_said = {}
    for artist_id, name in named:
        names_said.setdefault(artist_id, name)
    without = {"artists": set(), "genres": set(), "lessArtists": set(), "lessGenres": set(), "said": [], "isLess": False}
    turns = []
    in_full = as_genres(said)
    for artist_id in request["artists"]:
        name = names_said.get(artist_id)
        name = as_genres(" " + name + " ").strip() if name else None
        at = in_full.find(" " + name + " ") if name else -1
        if at < 0:
            continue
        turns.append((at, name, turn(name, in_full), ("artist", artist_id, name)))
    for _, name, tags in genres_here:
        at = in_full.find(" " + name + " ")
        if at < 0:
            continue
        turns.append((at, name, turn(name, in_full), ("genre", tuple(tags), name)))
    last = None
    missing = False
    for at, name, its_turn, (what, key, name_) in sorted(turns, key=lambda t: t[0]):
        joined = joins(name, in_full)
        this = its_turn if its_turn is not None else (last if joined else None)
        if this is not None:
            if what == "artist":
                (without["artists"] if this == "out" else without["lessArtists"]).add(key)
                first = next((s for s in songs if s.get("artistId") == key), None)
                without["said"].append(speech_artist(first["artist"]) if first else name_)
            elif key:
                (without["genres"] if this == "out" else without["lessGenres"]).update(tag.lower() for tag in key)
                exact = next((tag for tag in key if as_genres(plain(tag)).strip() == name_), None)
                without["said"].append(speech_genre(exact) if exact else _SPOKEN.get(name_, name_))
            without["isLess"] = without["isLess"] or this == "less"
        elif what == "genre" and not key:
            missing = True
        last = this
    request["artists"] = [a for a in request["artists"] if a not in without["artists"] and a not in without["lessArtists"]]
    request["genres"] = [g for g in request["genres"] if g.lower() not in without["genres"] and g.lower() not in without["lessGenres"]]
    request["without"] = {key: sorted(value) if isinstance(value, set) else value for key, value in without.items()}



    if missing and not names_music(request) and not request["genres"]:
        return None
    request["kind"] = kind(outside)
    if not names_music(request) and not request["genres"] and not request["moods"] and request["mix"] is None\
            and request["kind"] is None:
        about_it = about(outside)

        if about_it == "different" or (playing and about_it):
            request["playing"] = about_it
        elif request["era"] is None and (leaves_years(outside) or (not request["artists"] and without_empty(request)
                                                                   and any(core in _ANYTHING for core in asked)
                                                                   and read_feel(outside) is None
                                                                   and not looks_named(words, library))):
            request["playing"] = "different"
        if request["playing"] in ("older", "newer"):
            decade = year_of(playing) // 10 * 10
            if decade > 1900:
                if request["era"] is None:
                    request["era"] = (1900, decade - 1) if request["playing"] == "older" else (decade + 10, 2100)
            else:
                request["playing"] = None

    for_feel = spelled
    for _, name, _ in genres_here:
        for_feel = for_feel.replace(" " + name + " ", " ")
    for name in request["moods"]:
        for_feel = for_feel.replace(" " + plain(name).strip() + " ", " ")
    for phrases in PLAYING_WORDS.values():
        for p in phrases:
            for_feel = for_feel.replace(p, " ")
    feel = read_feel(for_feel)
    if not names_music(request):

        if request["playing"] == "different" and feel is not None:
            request["playing"] = None
        request["feel"] = feel
        request["phrase"] = phrase(said)
        if not feel and not request["moods"] and request["mix"] is None and without_empty(request):
            request["phrase"] = said_back(genres_here, request["era"], request["phrase"])
    elif not request["songs"] and not request["albums"]:

        request["feel"] = feel
    if not names_music(request) and request["kind"] is None and request["playing"] is None and request["startsWith"] is None\
            and not is_suggested:

        if not request["genres"] and not request["moods"] and without_empty(request)\
                and (request["feel"] or request["era"] is not None or request["mix"]) and looks_named(words, library):
            return None
        request["refines"] = builds(outside) and not is_empty(request)
    if request["kind"] is not None or request["playing"] is not None or request["refines"]:
        request["phrase"] = None

    if request["startsWith"] is not None:
        alone = dict(request, startsWith=None)
        if is_empty(alone) or (not alone["artists"] and not is_read(alone) and alone["phrase"] is None):
            request["songs"] = [request["startsWith"]]
            request["startsWith"] = None
            request["feel"] = None
            request["phrase"] = None
    if is_empty(request):
        return None
    if request["era"] is not None:
        request["era"] = {"from": request["era"][0], "to": request["era"][1]}
    return request
