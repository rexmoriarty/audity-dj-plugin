



import math
import re
import sqlite3
import threading
import time
import unicodedata

from . import bank_setup




SPELLED = str.maketrans({"ß": "ss", "ẞ": "ss", "ø": "o", "Ø": "o", "æ": "ae", "Æ": "ae", "œ": "oe", "Œ": "oe",
                         "đ": "d", "Đ": "d", "ł": "l", "Ł": "l", "þ": "th", "Þ": "th", "ð": "d", "Ð": "d", "ı": "i"})


def name_key(name):
    """An artist's name as it is looked up: accents folded on Latin, Greek and Cyrillic letters, lower case, "&" as
    " and ", apostrophes kept inside words, letters and digits of any script kept, all else a space; no leading "the"
    (nor a trailing ", The")."""
    text = re.sub(r",\s*the\s*$", "", name.translate(SPELLED), flags=re.I)
    kept, base = [], 0
    for c in unicodedata.normalize("NFKD", text):
        if unicodedata.combining(c):
            if base < 0x500:
                continue
        else:
            base = ord(c)
        kept.append(c)
    text = unicodedata.normalize("NFC", "".join(kept)).casefold()
    text = text.replace("&", " and ").replace("’", "'").replace("‘", "'")
    words = [w.strip("'") for w in re.sub(r"[^\w']+|_", " ", text).split()]
    words = [w for w in words if w]
    if len(words) > 1 and words[0] == "the":
        words = words[1:]
    return " ".join(words)



_GUEST = re.compile(r"\s+[\(\[]?(?:feat\.?|ft\.?|featuring)\s.*$", re.I)

_EDITION = re.compile(r"\s*(?:[\(\[][^\)\]]*[\)\]]|\s-\s.*\b(?:remaster\w*|edition|version|deluxe|anniversary|"
                      r"expanded|mono|stereo|bonus)\b.*)\s*$", re.I)
ASKED_MOST = 500
ALBUMS_MOST = 300
EPS_MOST = 100
_CANDIDATES_MOST = 50
_COLUMNS = "mbid, name, by_name, type, gender, begin, end, country, debut_year"

_local = threading.local()


def album_key(title):
    """An album's title as the library's and the file's are matched: its edition left off, then keyed as a name."""
    title = title or ""
    while True:
        shorter = _EDITION.sub("", title)
        if shorter == title or not shorter.strip():
            break
        title = shorter
    return name_key(title)


def _db():
    """This thread's read-only connection to the facts file in use, or None while it isn't downloaded."""
    if not bank_setup.facts_ready():
        return None
    path = bank_setup.facts_file()
    kept = getattr(_local, "db", None)
    if kept is None or kept[0] != path:
        db = sqlite3.connect("file:" + path + "?mode=ro&immutable=1", uri=True, check_same_thread=False)
        _local.db = kept = (path, db)
    return kept[1]


def _library_albums(library):
    """{name_key of an artist: {album_key of each of their albums}} in an account's library, worked out once for
    each version of it."""
    if library is None:
        return {}
    kept = getattr(library, "_facts_albums", None)
    if kept is None:
        kept = {}
        keys = {}
        for song in library.songs:
            album = song.get("album")
            if not album:
                continue
            for artist in {song.get("artist"), song.get("albumArtist")}:
                if artist:
                    key = keys.get(artist)
                    if key is None:
                        key = keys[artist] = name_key(_GUEST.sub("", artist))
                    kept.setdefault(key, set()).add(album)
        kept = {key: {album_key(album) for album in albums} - {""} for key, albums in kept.items()}
        library._facts_albums = kept
    return kept


def _find(db, mbid, name, albums_here):
    """(the artist's row, how it was found) or (None, None): by MBID, else by name, a shared name told apart by the
    library's albums, else the one the name answers to (by_name), else none."""
    if isinstance(mbid, str) and mbid.strip():
        row = db.execute(f"SELECT {_COLUMNS} FROM artists WHERE mbid = ?", (mbid.strip().lower(),)).fetchone()
        if row:
            return row, "mbid"
    key = name_key(_GUEST.sub("", name)) if isinstance(name, str) else ""
    if not key:
        return None, None
    rows = db.execute(f"SELECT {_COLUMNS} FROM artists WHERE name_key = ? ORDER BY weight DESC LIMIT ?",
                      (key, _CANDIDATES_MOST)).fetchall()
    if len(rows) == 1:
        return rows[0], "name"
    albums = set(albums_here.get(key, ()))
    if rows and albums:
        scored = []
        for row in rows:
            titles = {album_key(title) for (title,) in db.execute("SELECT title FROM releases WHERE artist_mbid = ?",
                                                                    (row[0],))}
            scored.append((len(titles & albums), row))
        best = max(score for score, _ in scored)
        top = [row for score, row in scored if score == best]
        if best > 0 and len(top) == 1:
            return top[0], "albums"
        if best > 0:
            rows = top
    named = [row for row in rows if row[2]]
    return (named[0], "name") if len(named) == 1 else (None, None)


def _facts(db, row, found, here):
    mbid, name, _, kind, gender, begin, end, country, debut = row
    albums, eps = [], []
    for title, date, form, nth in db.execute("SELECT title, date, kind, nth FROM releases WHERE artist_mbid = ? "
                                             "ORDER BY date, nth", (mbid,)):
        (albums if form == "album" else eps).append({"title": title, "date": date, "nth": nth} if form == "album"
                                                    else {"title": title, "date": date})
    if len(albums) > ALBUMS_MOST:
        mine = [album for album in albums if album_key(album["title"]) in here]
        albums = sorted(mine + [album for album in albums if album not in mine][:ALBUMS_MOST - len(mine)],
                        key=lambda album: (album["date"], album["nth"] or 0))
    return {"mbid": mbid, "name": name, "found": found, "type": kind, "gender": gender, "begin": begin, "end": end,
            "country": country, "debutYear": debut, "albums": albums, "eps": eps[:EPS_MOST]}


def artists(asked, library=None):
    """{"<the name asked, or the MBID>": facts or None} for each of `asked` ([{"mbid", "name", "albums"}]), or None
    while the facts file isn't downloaded. `library`, the account's as sent (asking.library), tells apart artists of
    one name by their albums there."""
    db = _db()
    if db is None:
        return None
    from_library = _library_albums(library)
    answer = {}
    for each in asked[:ASKED_MOST]:
        name, mbid = each.get("name"), each.get("mbid")
        label = name if isinstance(name, str) and name else mbid
        if not isinstance(label, str) or not label:
            continue
        key = name_key(_GUEST.sub("", name)) if isinstance(name, str) else ""
        sent = {album_key(album) for album in (each.get("albums") or []) if isinstance(album, str)} - {""}
        albums_here = {key: from_library.get(key, set()) | sent} if key else {}
        row, found = _find(db, mbid, name, albums_here)
        answer[label] = _facts(db, row, found, albums_here.get(key, set())) if row else None
    return answer





PACES = ((80, "slow"), (105, "easy"), (130, "quick"), (math.inf, "fast"))


MUSICNN_MOODS = ("mellow", "chill", "party", "catchy", "sad", "happy", "instrumental", "acoustic")
CLAP_MOODS = ("danceable", "aggressive", "relaxed")

MOOD_TOP = 0.10
MOOD_OF_HIGHEST = 0.5
SONGS_MOST = 2000
SPREAD_SECONDS = 3600

_spread = {"at": None, "value": None, "busy": False}
_spread_lock = threading.Lock()


def _scores(text):
    """"label:0.530,…" as {label lower-cased: 0.53}."""
    out = {}
    for part in (text or "").split(","):
        label, _, value = part.rpartition(":")
        try:
            out[label.strip().lower()] = float(value)
        except ValueError:
            continue
    return out


def _cut(values, at):
    """The value `at` of the way up `values` (0 to 1), or None for none."""
    if not values:
        return None
    values = sorted(values)
    return values[min(len(values) - 1, max(0, int(round(at * (len(values) - 1)))))]


def _measure(db):
    """The library's spread, from the whole table: energy's and danceable's thirds, each mood's top tenth and
    highest."""
    cur = db.cursor()
    try:
        cur.execute("SELECT energy, mood_vector, other_features FROM score")
        rows = cur.fetchall()
    finally:
        cur.close()
    energies, moods = [], {mood: [] for mood in MUSICNN_MOODS + CLAP_MOODS}
    for energy, mood_vector, other in rows:
        if energy is not None:
            energies.append(float(energy))
        heard = _scores(mood_vector)
        heard.update({label: value for label, value in _scores(other).items() if label in CLAP_MOODS})
        for mood in moods:
            moods[mood].append(heard.get(mood, 0.0))
    return {"songs": len(rows), "energy": (_cut(energies, 1 / 3), _cut(energies, 2 / 3)),
            "moods": {mood: (_cut(values, 1 - MOOD_TOP), max(values) if values else None,
                             _cut(values, 1 / 3), _cut(values, 2 / 3)) for mood, values in moods.items()}}


def _library_spread(get_db):
    """The spread, measured again each hour in the background (the first time while asked)."""
    with _spread_lock:
        stale = _spread["at"] is None or time.monotonic() - _spread["at"] > SPREAD_SECONDS
        first = _spread["value"] is None
        if stale and not first and not _spread["busy"]:
            _spread["busy"] = True
            threading.Thread(target=_measure_again, args=(get_db,), name="audity-dj-facts-spread", daemon=True).start()
    if first:
        value = _measure(get_db())
        with _spread_lock:
            _spread.update(at=time.monotonic(), value=value)
    return _spread["value"]


def _measure_again(get_db):
    try:
        value = _measure(get_db())
        with _spread_lock:
            _spread.update(at=time.monotonic(), value=value)
    except Exception:
        with _spread_lock:
            _spread["at"] = time.monotonic() - SPREAD_SECONDS + 60
    finally:
        _spread["busy"] = False


def _band(value, thirds):
    low, high = thirds
    if value is None or low is None or high is None or low == high:
        return None
    return "low" if value <= low else "high" if value >= high else None


def _pace(bpm, lively):
    """(the pace, sure): slow and fast taken as they are only where the song's energy and danceable bear them out,
    as a beat tracker most often slips to half or double (a loud, danceable 70 is likelier 140)."""
    name = next(name for top, name in PACES if bpm < top)
    if name == "slow":
        return name, not lively
    if name == "fast":
        return name, lively
    return name, True


def songs(ids, get_db):
    """{"<song id>": its facts} for each of `ids` AudioMuse-AI has analyzed (FACTS.md); `get_db` is AudioMuse-AI's
    own database connection."""
    ids = [song for song in dict.fromkeys(ids) if isinstance(song, str) and song][:SONGS_MOST]
    if not ids:
        return {}
    spread = _library_spread(get_db)
    db = get_db()
    cur = db.cursor()
    try:
        cur.execute("SELECT item_id, tempo, key, scale, energy, mood_vector, other_features FROM score "
                    "WHERE item_id = ANY(%s)", (ids,))
        rows = cur.fetchall()
    finally:
        cur.close()
    answer = {}
    for item_id, tempo, key, scale, energy, mood_vector, other in rows:
        heard = _scores(mood_vector)
        clap = {label: value for label, value in _scores(other).items() if label in CLAP_MOODS}
        heard.update(clap)
        energy_band = _band(float(energy) if energy is not None else None, spread["energy"])
        dance = spread["moods"]["danceable"]
        dance_band = _band(clap.get("danceable"), (dance[2], dance[3])) if "danceable" in clap else None
        facts = {}
        if tempo:
            bpm = float(tempo)
            pace, sure = _pace(bpm, energy_band == "high" or dance_band == "high")
            facts.update(bpm=round(bpm, 1), pace=pace, paceSure=sure)
        if key:
            facts["key"] = key
        if scale:
            facts["scale"] = scale
        if energy_band:
            facts["energy"] = energy_band
        moods = []
        for mood in MUSICNN_MOODS + CLAP_MOODS:
            top, highest, _, _ = spread["moods"][mood]
            value = heard.get(mood)
            if value and top is not None and highest and value >= top and value >= MOOD_OF_HIGHEST * highest:
                moods.append(mood)
        facts["moods"] = moods
        answer[item_id] = facts
    return answer
