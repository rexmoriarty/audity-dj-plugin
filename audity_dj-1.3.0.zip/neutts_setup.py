











import hashlib
import json
import os
import shutil
import subprocess
import threading
import time

import requests

from plugin.api import logger

from . import install





TORCH = ["torch==2.9.1", "torchaudio==2.9.1"]
PACKAGES = ["neutts==1.1.0", "llama-cpp-python==0.3.36", "torchao==0.14.1", "espeakng-loader==0.2.4"]
LLAMA_INDEX = "https://abetlen.github.io/llama-cpp-python/whl/cpu"
CONSTRAINTS = os.path.join(os.path.dirname(os.path.abspath(__file__)), "neutts-constraints.txt")


RELEASE = "https://github.com/rexmoriarty/audity-dj-plugin/releases/download/neutts-air-1/"
FILES = [
    ("neuphonic/neutts-air-q4-gguf", "0f54a5513ee49708713e49c5122c274df2737047", "neutts-air-Q4_0.gguf",
     "neutts-air-Q4_0.gguf", 527_054_304, "bf66dc21b7588fe720cbdfeac1595e7b7c780515f8d8f1ff9a29062e4ac9119e"),
    ("neuphonic/distill-neucodec", "6f2b93b3fa2bc74740ba1bd10622e1ee37dbbe46", "pytorch_model.bin",
     "distill-neucodec-pytorch_model.bin", 1_025_488_162, "adace21f679b30f071c02e0cb3502d965ab08b50be936a5e81944674a5ae101e"),
    ("neuphonic/distill-neucodec", "6f2b93b3fa2bc74740ba1bd10622e1ee37dbbe46", "meta.yaml",
     "distill-neucodec-meta.yaml", 37, "232631816b83ee6c8929b7f0b960aedb7b215caa73dd96f7a0e60946b2a1319b"),
    ("ntu-spml/distilhubert", "fa87d96265d6b7af66e112faff6ff44df419cec9", "config.json",
     "distilhubert-config.json", 1_302, "0427043d1c4c8d58298d2050420a0c2ce85c8b92ec3865eaecc62c3fc5a97006"),
    ("ntu-spml/distilhubert", "fa87d96265d6b7af66e112faff6ff44df419cec9", "preprocessor_config.json",
     "distilhubert-preprocessor_config.json", 214, "7a8f0fc8ee1272ed28a8b468e183c56a19329a92babd3ca8d4d21ae02ba511cd"),
    ("ntu-spml/distilhubert", "fa87d96265d6b7af66e112faff6ff44df419cec9", "model.safetensors",
     "distilhubert-model.safetensors", 93_973_272, "77ad8f985c97750d8d27d6950c917800d80732a141370bf316058bded71a6cbe"),
]
WEIGHTS_BYTES = sum(file[4] for file in FILES)

DISK_GB = 3.4
GATED = ("neuphonic/neutts-air-q4-gguf", "neuphonic/distill-neucodec")


def folder(*parts):
    return install.folder("neutts", *parts)


def python():
    return folder("env", "bin", "python")


def hf_home():
    return folder("hf")


def gguf():
    repo, revision, name = FILES[0][:3]
    return _cached(repo, revision, name)


def _cached(repo, revision, name):
    owner, model = repo.split("/")
    return os.path.join(hf_home(), "hub", f"models--{owner}--{model}", "snapshots", revision, name)


_state_lock = threading.Lock()
_job = {"thread": None, "process": None, "stop": False}


def _read_state():
    try:
        with open(install.folder("neutts.json")) as file:
            return json.load(file)
    except (OSError, ValueError):
        return {}


def _write_state(**values):
    with _state_lock:
        state = _read_state()
        state.update(values)
        os.makedirs(install.folder(), exist_ok=True)
        temporary = install.folder("neutts.json.new")
        with open(temporary, "w") as file:
            json.dump(state, file)
        os.replace(temporary, install.folder("neutts.json"))


def status():
    """{"state": "none" | "downloading" | "ready" | "failed", "step", "fraction", "error", "needsToken"}"""
    state = _read_state()
    if state.get("state") == "downloading" and not (_job["thread"] and _job["thread"].is_alive()):
        state.update(state="failed", error="The download stopped when AudioMuse-AI restarted. Try again.")
    state.setdefault("state", "none")
    return state


def is_ready():
    return _read_state().get("state") == "ready" and os.path.isfile(python()) and os.path.isfile(gguf())


def start(token=None):
    """Its download begun; `token`, a Hugging Face token typed on the page, is used for this download only
    and never kept."""
    if _job["thread"] and _job["thread"].is_alive():
        return
    _job["stop"] = False
    _write_state(state="downloading", step="Starting", fraction=0.0, error=None, needsToken=False)
    _job["thread"] = threading.Thread(target=_download, args=((token or "").strip() or None,),
                                      name="audity-dj-neutts-download", daemon=True)
    _job["thread"].start()


def stop():
    _job["stop"] = True
    process = _job["process"]
    if process and process.poll() is None:
        process.kill()


def remove():
    stop()
    if _job["thread"]:
        _job["thread"].join(timeout=30)
    shutil.rmtree(folder(), ignore_errors=True)
    _write_state(state="none", step=None, fraction=0.0, error=None, needsToken=False)


class _Stopped(Exception):
    pass


class _NeedsToken(Exception):
    pass


def _run(command, step, fraction, env):
    _write_state(step=step, fraction=fraction)
    if _job["stop"]:
        raise _Stopped()
    with open(install.folder("download.log"), "a") as log:
        log.write(f"\n$ {' '.join(command)}\n")
        log.flush()
        process = subprocess.Popen(command, stdout=log, stderr=subprocess.STDOUT, env=env)
        _job["process"] = process
        code = process.wait()
        _job["process"] = None
    if _job["stop"]:
        raise _Stopped()
    if code != 0:
        raise RuntimeError(f"{step} failed (see {install.folder('download.log')})")


def _download(token):
    try:
        os.makedirs(folder(), exist_ok=True)
        open(install.folder("download.log"), "w").close()
        env = install._clean_env()
        env["HF_HOME"] = hf_home()
        system_python = "/usr/bin/python3" if os.path.isfile("/usr/bin/python3") else "python3"
        pip = [system_python, "-I", "-m", "pip", "--python", python(), "install", "--no-cache-dir", "--only-binary=:all:"]
        if not os.path.isfile(python()):
            _run([system_python, "-I", "-m", "venv", "--without-pip", folder("env")], "Making the voice's Python", 0.01, env)

        _run(pip + TORCH + ["--index-url", install.TORCH_INDEX], "Downloading PyTorch for processors", 0.02, env)
        _run(pip + PACKAGES + TORCH + ["-c", CONSTRAINTS, "--extra-index-url", LLAMA_INDEX,
                                      "--extra-index-url", install.TORCH_INDEX],
             "Downloading the voice's packages", 0.15, env)
        got = 0
        for repo, revision, name, published, size, digest in FILES:
            got = _fetch(repo, revision, name, published, size, digest, token, got)
        _write_state(state="ready", step=None, fraction=1.0, error=None, needsToken=False)
        logger.info("Audity DJ: the faster voice (NeuTTS Air) is downloaded")
    except _Stopped:
        _write_state(state="none", step=None, fraction=0.0, error=None)
    except _NeedsToken as error:
        _write_state(state="failed", error=str(error), needsToken=True)
    except Exception as error:
        logger.exception("Audity DJ: the faster voice's download failed")
        _write_state(state="failed", error=str(error))


def _fetch(repo, revision, name, published, size, digest, token, got):
    """One weights file into Hugging Face's own layout, checked against its SHA-256; returns the bytes
    downloaded so far, for the bar."""
    path = _cached(repo, revision, name)
    owner, model = repo.split("/")
    refs = os.path.join(hf_home(), "hub", f"models--{owner}--{model}", "refs")
    os.makedirs(refs, exist_ok=True)
    with open(os.path.join(refs, "main"), "w") as file:
        file.write(revision)
    if os.path.isfile(path) and os.path.getsize(path) == size:
        return got + size
    os.makedirs(os.path.dirname(path), exist_ok=True)
    sources = [(RELEASE + published, {})]
    if repo not in GATED:
        sources.append((f"https://huggingface.co/{repo}/resolve/{revision}/{name}", {}))
    elif token:
        sources.append((f"https://huggingface.co/{repo}/resolve/{revision}/{name}", {"Authorization": f"Bearer {token}"}))
    problems = []
    for url, headers in sources:
        _write_state(step=f"Downloading the voice ({name})")
        try:
            answer = requests.get(url, headers=headers, stream=True, timeout=60)
        except requests.RequestException as error:
            problems.append(str(error))
            continue
        if answer.status_code != 200:
            problems.append(f"{answer.status_code} from {url.split('/')[2]}")
            answer.close()
            continue
        hashed, done, partial = hashlib.sha256(), 0, path + ".part"
        last = 0.0
        with answer, open(partial, "wb") as out:
            for chunk in answer.iter_content(1 << 20):
                if _job["stop"]:
                    raise _Stopped()
                out.write(chunk)
                hashed.update(chunk)
                done += len(chunk)
                if time.monotonic() - last > 2:
                    last = time.monotonic()
                    _write_state(fraction=0.3 + 0.7 * min((got + done) / WEIGHTS_BYTES, 0.99))
        if hashed.hexdigest() != digest:
            os.remove(partial)
            problems.append(f"{name} came down damaged")
            continue
        os.replace(partial, path)
        return got + size
    if repo in GATED and not token:

        raise _NeedsToken("Neuphonic's voice files are on Hugging Face for accounts that accepted their terms: "
                          "paste a Hugging Face token on the Audity DJ page in AudioMuse-AI (it's used for this download only).")
    raise RuntimeError(f"Couldn't download {name}: {'; '.join(problems)}")


def disk_bytes():
    return install._size(folder())


def threads_measured():
    """Whether the worker has timed llama.cpp's thread counts on this machine (`neutts_worker._pick_threads`)."""
    return os.path.isfile(folder("codes", "threads.json"))
