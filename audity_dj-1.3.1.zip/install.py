







import json
import os
import platform
import shutil
import subprocess
import tarfile
import threading
import time
import urllib.request

from plugin.api import config, logger

MING_COMMIT = "a39b80660bdc5a4394d5e1d41af6dbfd9c443a54"
MING_CODE = f"https://github.com/inclusionAI/Ming-3.0-tts/archive/{MING_COMMIT}.tar.gz"
MING_WEIGHTS = "inclusionAI/Ming-3.0-tts-0.5B"
MING_WEIGHTS_REVISION = "7247f4c94a5b2e987404ed28a5cfec41b1a4ca61"
WEIGHTS_BYTES = 3_000_000_000
TORCH = ["torch==2.6.0", "torchaudio==2.6.0"]
TORCH_INDEX = "https://download.pytorch.org/whl/cpu"

DISK_GB = 4.5


def folder(*parts):
    return os.path.join(config.PLUGINS_DIR, "audity_dj_files", *parts)


def python():
    """The voice's own Python."""
    return folder("env", "bin", "python")


_state_lock = threading.Lock()
_job = {"thread": None, "process": None, "stop": False}


def _read_state():
    try:
        with open(folder("voice.json")) as file:
            return json.load(file)
    except (OSError, ValueError):
        return {}


def _write_state(**values):
    with _state_lock:
        state = _read_state()
        state.update(values)
        os.makedirs(folder(), exist_ok=True)
        temporary = folder("voice.json.new")
        with open(temporary, "w") as file:
            json.dump(state, file)
        os.replace(temporary, folder("voice.json"))


def status():
    """{"state": "none" | "downloading" | "ready" | "failed", "step", "fraction", "error", "model"}"""
    state = _read_state()
    if state.get("state") == "downloading" and not (_job["thread"] and _job["thread"].is_alive()):

        state.update(state="failed", error="The download stopped when AudioMuse-AI restarted. Try again.")
    state.setdefault("state", "none")
    return state


def is_ready():
    state = _read_state()
    return state.get("state") == "ready" and os.path.isfile(python()) and os.path.isdir(state.get("model") or "")


def model_folder():
    return _read_state().get("model")


def start():
    if _job["thread"] and _job["thread"].is_alive():
        return
    _job["stop"] = False
    _write_state(state="downloading", step="Starting", fraction=0.0, error=None)
    _job["thread"] = threading.Thread(target=_download, name="audity-dj-download", daemon=True)
    _job["thread"].start()


def stop():
    _job["stop"] = True
    process = _job["process"]
    if process and process.poll() is None:
        process.kill()


def remove():
    """The voice's packages, code and weights, gone; the voices added stay."""
    stop()
    if _job["thread"]:
        _job["thread"].join(timeout=30)
    for part in ("env", "ming", "hf", "ming.new"):
        shutil.rmtree(folder(part), ignore_errors=True)
    _write_state(state="none", step=None, fraction=0.0, error=None, model=None)


class _Stopped(Exception):
    pass


def _run(command, step, fraction, env=None):
    _write_state(step=step, fraction=fraction)
    if _job["stop"]:
        raise _Stopped()
    log = open(folder("download.log"), "a")
    log.write(f"\n$ {' '.join(command)}\n")
    log.flush()
    process = subprocess.Popen(command, stdout=log, stderr=subprocess.STDOUT, env=env)
    _job["process"] = process
    code = process.wait()
    _job["process"] = None
    log.close()
    if _job["stop"]:
        raise _Stopped()
    if code != 0:
        raise RuntimeError(f"{step} failed (see {folder('download.log')})")


def _clean_env():

    env = {key: value for key, value in os.environ.items() if key not in ("PYTHONPATH", "PYTHONHOME")}
    env["HF_HOME"] = folder("hf")
    env["PIP_DISABLE_PIP_VERSION_CHECK"] = "1"
    return env


def _download():
    try:
        os.makedirs(folder(), exist_ok=True)
        open(folder("download.log"), "w").close()
        env = _clean_env()


        system_python = "/usr/bin/python3" if os.path.isfile("/usr/bin/python3") else "python3"
        pip = [system_python, "-I", "-m", "pip", "--python", python(), "install", "--no-cache-dir"]
        if not os.path.isfile(python()):
            _run([system_python, "-I", "-m", "venv", "--without-pip", folder("env")], "Making the voice's Python", 0.01, env)
        _run(pip + TORCH + ["--index-url", TORCH_INDEX], "Downloading PyTorch for processors", 0.03, env)

        _write_state(step="Downloading Ming's code", fraction=0.12)
        archive = folder("ming.tar.gz")
        urllib.request.urlretrieve(MING_CODE, archive)
        shutil.rmtree(folder("ming.new"), ignore_errors=True)
        os.makedirs(folder("ming.new"))
        with tarfile.open(archive) as tar:
            members = []
            for member in tar.getmembers():
                parts = member.name.split("/", 1)
                if len(parts) < 2 or not parts[1] or member.issym() or member.islnk():
                    continue
                member.name = parts[1]
                members.append(member)
            tar.extractall(folder("ming.new"), members=members, filter="data")
        os.remove(archive)
        shutil.rmtree(folder("ming"), ignore_errors=True)
        os.replace(folder("ming.new"), folder("ming"))

        with open(os.path.join(folder("ming"), "requirements.txt")) as file:
            wanted = [line.split("#")[0].strip() for line in file]
        wanted = [line for line in wanted if line and not line.startswith(("torch==", "torchaudio=="))]
        if platform.machine() in ("aarch64", "arm64"):

            wanted = ["soundfile==0.13.1" if line.startswith("soundfile") else line for line in wanted]
        _run(pip + wanted + TORCH, "Downloading Ming's packages", 0.16, env)

        _write_state(step="Downloading the voice", fraction=0.25)
        fetch = ("from huggingface_hub import snapshot_download\n"
                 f"print(snapshot_download({MING_WEIGHTS!r}, revision={MING_WEIGHTS_REVISION!r}))\n")
        out = folder("weights.txt")
        with open(out, "w") as written:
            process = subprocess.Popen([python(), "-I", "-c", fetch], stdout=written,
                                       stderr=open(folder("download.log"), "a"), env=env)
            _job["process"] = process
            while process.poll() is None:
                time.sleep(2)
                got = _size(folder("hf"))
                _write_state(fraction=0.25 + 0.75 * min(got / WEIGHTS_BYTES, 0.99))
            _job["process"] = None
        if _job["stop"]:
            raise _Stopped()
        if process.returncode != 0:
            raise RuntimeError(f"Downloading the voice failed (see {folder('download.log')})")
        with open(out) as file:
            model = file.read().strip().splitlines()[-1]
        _write_state(state="ready", step=None, fraction=1.0, error=None, model=model)
        logger.info("Audity DJ: the voice is downloaded")
    except _Stopped:
        _write_state(state="none", step=None, fraction=0.0, error=None)
    except Exception as error:
        logger.exception("Audity DJ: the voice's download failed")
        _write_state(state="failed", error=str(error))


def _size(path):
    total = 0
    for root, _, files in os.walk(path):
        for name in files:
            path = os.path.join(root, name)

            if os.path.islink(path):
                continue
            try:
                total += os.path.getsize(path)
            except OSError:
                pass
    return total


_measured = {}


def kept_size(path, state_file):
    """`_size(path)`, measured again only once `state_file` has changed, as a download or a removal
    writes it. Measuring walks every file (with both voices, 115,000 on the Mac's test server, about 5 s),
    and the plugin's page asks for the sizes every 3 s (2026-11-10: each ask took 5 s, so the page's rows
    stayed "…" that long and the asks piled up while it was open). Keyed by the file's time, so every
    process of AudioMuse-AI's sees the change."""
    try:
        stamp = os.stat(state_file).st_mtime_ns
    except OSError:
        stamp = None
    kept = _measured.get(path)
    if kept is None or kept[0] != stamp:
        kept = (stamp, _size(path))
        _measured[path] = kept
    return kept[1]


def disk_bytes():
    return sum(kept_size(folder(part), folder("voice.json")) for part in ("env", "ming", "hf"))
