














import collections
import hashlib
import io
import json
import os
import re
import socket
import subprocess
import threading
import time
import uuid
import wave

import numpy as np
import requests

from plugin.api import logger

from . import install, neutts_setup, voices

HOLD_FOR = 120





SAMPLE_RATE = 44_100
EARLIER_APPS = 24_000
LOAD_WAIT = 600



NAME_PAUSE = 0.45



SENTENCE_PAUSE = 0.4
PHRASE_PAUSE = 0.2

FEWEST_WORDS = 3

ABBREVIATIONS = {"mr", "mrs", "ms", "dr", "st", "jr", "sr", "vs", "mt", "ft", "feat", "vol", "no", "pt"}

EDGE = 0.08

LONGEST_PAUSE = 0.4






LEAD_IN = 0.03
TAIL = 0.06
BLEND = 0.015
SHORTEST_FADE = 0.005

MISHEARD = 0.2







KEEP_LINES = 150
RENDER = "3"


LONGEST_FOR_LETTERS = 0.2


class _Job:
    def __init__(self, listener, text, voice, takes, full_band=False):
        self.id = uuid.uuid4().hex
        self.listener = listener
        self.text = text
        self.voice = voice
        self.takes = max(1, min(int(takes or 1), 3))

        self.full_band = full_band
        self.state = "waiting"
        self.wav = None
        self._cut = None
        self.info = {}
        self.error = None
        self.made = time.monotonic()
        self.cancelled = False

        self.engine = None



        self.finished = threading.Event()

    def end(self, state):
        self.state = state
        self.finished.set()

    def wav_for_app(self):
        """The line as whoever asked can play it: as made, or cut to EARLIER_APPS for an app that
        plays only that."""
        if self.full_band or self.wav is None:
            return self.wav
        if self._cut is None:
            samples, rate = from_wav(self.wav)
            self._cut = to_wav(resample(samples, rate, EARLIER_APPS), EARLIER_APPS)
        return self._cut


class Voicebox:
    def __init__(self):
        self._lock = threading.RLock()
        self._work = threading.Condition(self._lock)
        self._holds = {}
        self._process = None
        self._port = None
        self._began = None
        self._jobs = collections.OrderedDict()
        self._queue = collections.deque()
        self._later = collections.deque()
        self._keeper = None
        self._maker = None
        self._whisper_loaded = False
        self._told_refused = False
        self._engine = None

        self._hearing_soon = False
        self.last_error = None



    def hold(self, listener):
        """`listener`'s session is on: the voice starts if it isn't running, and stays."""
        if engine() is None:
            raise VoiceNotReady()
        with self._lock:
            self._holds[listener] = time.monotonic() + HOLD_FOR
            self._start_process()
            if self._keeper is None or not self._keeper.is_alive():
                self._keeper = threading.Thread(target=self._keep, name="audity-dj-keeper", daemon=True)
                self._keeper.start()

    def release(self, listener):
        with self._lock:
            self._holds.pop(listener, None)
            for job in list(self._jobs.values()):
                if job.listener == listener and job.state == "waiting":
                    job.cancelled = True
            if not self._holds:
                self._stop_process()

    def status(self):
        with self._lock:
            running = self._process is not None and self._process.poll() is None
            loaded = running and self._ready()
            return {
                "running": running,
                "loaded": bool(loaded),
                "warming": running and not loaded,
                "since": None if not running else round(time.monotonic() - self._began),
                "listeners": sorted(self._holds),
                "waiting": sum(1 for job in self._jobs.values() if job.state in ("waiting", "making")),
                "engine": self._engine if running else engine(),
                "error": self.last_error,
            }

    def _start_process(self):
        wanted = engine()
        if self._process is not None and self._process.poll() is None:
            if wanted == self._engine or any(job.state == "making" for job in self._jobs.values()):
                return

            self._stop_process()
        with socket.socket() as probe:
            probe.bind(("127.0.0.1", 0))
            self._port = probe.getsockname()[1]
        env = install._clean_env()
        env["HF_HUB_OFFLINE"] = "1"
        threads = os.environ.get("AUDITY_DJ_THREADS", "0")
        here = os.path.dirname(os.path.abspath(__file__))
        if wanted == "neutts":
            env["HF_HOME"] = neutts_setup.hf_home()
            command = [neutts_setup.python(), "-I", os.path.join(here, "neutts_worker.py"), "--port", str(self._port),
                       "--model", neutts_setup.gguf(), "--codes", neutts_setup.folder("codes"),
                       "--threads", threads, "--idle", "90"]
        else:
            command = [install.python(), "-I", os.path.join(here, "worker.py"),
                       "--port", str(self._port), "--ming", install.folder("ming"), "--model", install.model_folder(),
                       "--threads", threads, "--idle", "90",
                       "--precision", os.environ.get("AUDITY_DJ_PRECISION", "float32"),
                       "--flow", os.environ.get("AUDITY_DJ_FLOW", "int8")]
        self._engine = wanted
        log = open(install.folder("voice.log"), "w")
        self._process = subprocess.Popen(command, stdout=log, stderr=subprocess.STDOUT, env=env)
        self._began = time.monotonic()
        self.last_error = None
        logger.info("Audity DJ: the voice is starting for a DJ session")

    def _stop_process(self):
        process = self._process
        self._process = None
        if process is not None and process.poll() is None:
            process.terminate()
            try:
                process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                process.kill()
            logger.info("Audity DJ: no DJ session is on; the voice stopped and let its memory go")
        self._unload_whisper()

    def _keep(self):
        while True:
            time.sleep(5)
            with self._lock:
                now = time.monotonic()
                for listener, until in list(self._holds.items()):
                    if until < now:
                        self._holds.pop(listener)
                        logger.info("Audity DJ: %s's session went quiet; let go", listener)
                if not self._holds:
                    self._stop_process()
                    self._keeper = None
                    return



                for job_id, job in list(self._jobs.items()):
                    if now - job.made > 900 and job.finished.is_set():
                        self._jobs.pop(job_id)
                port = self._port
            try:
                requests.post(f"http://127.0.0.1:{port}/beat", timeout=3)
            except requests.RequestException:
                pass

    def _ready(self):
        try:
            answer = requests.get(f"http://127.0.0.1:{self._port}/ready", timeout=2).json()
        except (requests.RequestException, ValueError):
            return False
        if answer.get("error"):
            self.last_error = answer["error"]
        return bool(answer.get("loaded"))



    def ask(self, listener, text, voice_id, takes=1, later=False, full_band=False, any_voice=False):
        """A line to make, or kept from before; its id, to fetch it by. One asked `later` is made only
        when no other line is waiting; `full_band` by an app that plays any rate. `any_voice` for the
        page, whose owner can try every voice, those added for one account too."""
        voice = voices.find(voice_id, None if any_voice else listener) or voices.find(voices.DEFAULT)
        job = _Job(listener, text, voice, takes, full_band)
        job.engine = engine()
        kept = _kept_line(voice, text, job.engine)
        if kept is not None:
            job.wav, info = kept

            job.info = {part: value for part, value in dict(info, madeIn=0.0, kept=True).items() if part != "spent"}
            job.end("done")
            with self._lock:
                self._remember_job(job)
            return job.id
        self.hold(listener)
        with self._lock:
            self._remember_job(job)
            (self._later if later else self._queue).append(job)
            if self._maker is None or not self._maker.is_alive():
                self._maker = threading.Thread(target=self._make_all, name="audity-dj-maker", daemon=True)
                self._maker.start()
            self._work.notify()
        return job.id

    def _remember_job(self, job):
        self._jobs[job.id] = job

        while len(self._jobs) > 500:
            self._jobs.popitem(last=False)

    def line(self, job_id):
        with self._lock:
            return self._jobs.get(job_id)

    def cancel(self, job_id):
        with self._lock:
            job = self._jobs.get(job_id)
            if job is not None:
                job.cancelled = True

    def ahead_of(self, job):
        with self._lock:
            ahead = sum(1 for queued in self._queue if queued is not job and queued.made <= job.made)
            if job in self._later:
                ahead = len(self._queue) + sum(1 for queued in self._later if queued is not job and queued.made <= job.made)
            return ahead

    def _make_all(self):
        while True:
            with self._lock:
                while not self._queue and not self._later:
                    if not self._work.wait(timeout=60):
                        self._maker = None
                        return
                job = self._queue.popleft() if self._queue else self._later.popleft()
                if job.cancelled:
                    job.end("cancelled")
                    continue
                job.state = "making"
            try:
                self._make(job)
                _keep_line(job)
                job.end("done")
            except Cancelled:


                job.end("cancelled")
            except Exception as error:
                logger.exception("Audity DJ: a line couldn't be made")
                job.error = str(error)
                job.end("failed")

    def _wait_for_voice(self, job):
        """How long it waited for the voice to load (nothing when it was loaded)."""
        began = time.monotonic()
        until = began + LOAD_WAIT


        if self._engine != "neutts" or neutts_setup.threads_measured():
            self._hear_soon()
        while time.monotonic() < until:
            if job.cancelled:
                raise Cancelled()
            with self._lock:
                running = self._process is not None and self._process.poll() is None
            if not running:
                raise RuntimeError(self.last_error or "The voice stopped.")
            if self._ready():
                self._hear_soon()
                return time.monotonic() - began
            if self.last_error:
                raise RuntimeError(self.last_error)
            time.sleep(1)
        raise RuntimeError("The voice took too long to load.")

    def _make(self, job):
        loading = self._wait_for_voice(job)
        began = time.monotonic()

        job.engine = self._engine or job.engine



        pieces = beats(job.text) if job.engine == "neutts" else split(job.text)
        made, heard_all, takes_used = [], [], 0

        spent = {"loading": loading, "speaking": 0.0, "checking": 0.0, "engine": job.engine}
        for index, (piece, pause) in enumerate(pieces):
            clips = voices.clips_for(job.voice, job.text, job.engine)
            best = None

            for take in range(1, max(job.takes, 2) + 1):
                if job.cancelled:
                    raise Cancelled()
                samples, parts = self._say(piece, clips, seed=take + index * 7)
                spent["speaking"] += parts.pop("total", 0.0)
                threads, bits = parts.pop("threads", None), parts.pop("flowBits", None)
                for part, seconds in parts.items():
                    spent[part] = spent.get(part, 0) + seconds
                if threads:
                    spent["threads"] = threads
                if bits:
                    spent["flowBits"] = bits



                if job.cancelled:
                    raise Cancelled()
                if samples.size == 0:


                    takes_used += 1
                    continue
                samples = tidy(slower(samples, voices.pace(job.voice, job.engine)))
                letters = len(re.findall(r"\w", piece))
                if samples.size / SAMPLE_RATE > LONGEST_FOR_LETTERS * letters + 2:

                    heard, missing = "(ran on past its words)", 1.0
                else:
                    hearing = time.monotonic()
                    heard, missing = self._hear(samples, piece)
                    spent["checking"] += time.monotonic() - hearing
                takes_used += 1
                if best is None or missing < best[2]:
                    best = (samples, heard, missing)
                if missing <= MISHEARD:
                    break
            if best is None:
                raise RuntimeError(f"No speech in {takes_used} takes of “{piece}”")
            made.append((best[0], pause))
            heard_all.append(best[1])
        silence = lambda seconds: np.zeros(int(seconds * SAMPLE_RATE), dtype=np.float32)
        joined = [silence(EDGE)]
        for samples, pause in made:

            joined += [samples, silence(max(pause - TAIL - LEAD_IN, 0))]
        joined.append(silence(EDGE))
        samples = np.concatenate(joined)
        peak = float(np.max(np.abs(samples))) or 1.0
        samples = samples * min(0.89 / peak, 4.0)
        words = len(re.findall(r"[\w']+", job.text))
        seconds = len(samples) / SAMPLE_RATE
        job.info = {"seconds": round(seconds, 2), "pace": round(words / max(seconds, 0.1) * 60),
                    "heard": " | ".join(heard_all), "takes": takes_used,
                    "madeIn": round(time.monotonic() - began, 1), "voice": job.voice["id"], "engine": job.engine,
                    "spent": {part: round(value, 2) if isinstance(value, float) else value for part, value in spent.items()}}
        job.wav = to_wav(samples)
        logger.info("Audity DJ: a line of %.1f s made in %.0f s (%d takes)", seconds, job.info["madeIn"], takes_used)

    def _say(self, text, clips, seed):
        answer = requests.post(f"http://127.0.0.1:{self._port}/say", timeout=900,
                               data=json.dumps({"text": text, "clips": clips, "seed": seed}))
        if answer.status_code != 200:
            raise RuntimeError(answer.text[:300])
        try:
            parts = json.loads(answer.headers.get("X-Spent") or "{}")
        except ValueError:
            parts = {}
        return np.frombuffer(answer.content, dtype=np.float32).copy(), parts



    def _hear(self, samples, text):
        """What Whisper heard, and the share of the piece's words it didn't hear."""
        try:
            from lyrics import whisper_onnx



            try:
                whisper_onnx.load_whisper_model()
            except whisper_onnx.WhisperLoadRefused as refused:
                if not self._told_refused:
                    logger.warning("Audity DJ: speech-to-text can't check lines now: %s", refused)
                    self._told_refused = True
                return "(not checked: too little memory free)", 0.0
            sixteen = resample(samples, SAMPLE_RATE, 16_000)
            heard = str(whisper_onnx.transcribe(sixteen, 16_000, language="en").get("text", "")).strip()
            self._whisper_loaded = True
        except Exception:
            logger.exception("Audity DJ: speech-to-text couldn't check a line; kept as made")
            return "", 0.0
        wanted = _words(text)
        if not wanted:
            return heard, 0.0
        got = set(_words(heard))
        missing = sum(1 for word in wanted if word not in got)
        return heard, missing / len(wanted)

    def _hear_soon(self):
        """Speech-to-text loaded while the voice loads, not once the session's first line is made: that
        line, the one the app waits for, came about 15 s sooner on the Mac's test (2026-11-10, its check
        18.6 s with the load, 3 to 4 s after)."""
        if self._whisper_loaded or self._hearing_soon:
            return
        self._hearing_soon = True

        def load():
            try:
                from lyrics import whisper_onnx

                whisper_onnx.load_whisper_model()
                self._whisper_loaded = True
            except Exception:
                pass
            finally:
                self._hearing_soon = False

        threading.Thread(target=load, name="audity-dj-hearing", daemon=True).start()

    def _unload_whisper(self):
        if not self._whisper_loaded:
            return
        try:
            from lyrics import whisper_onnx

            whisper_onnx.unload()
        except Exception:
            logger.exception("Audity DJ: couldn't let speech-to-text go")
        self._whisper_loaded = False


class VoiceNotReady(Exception):
    pass


class Cancelled(Exception):
    pass


def _kept_path(voice, text, engine="ming"):
    """Where a line in `voice` saying `text` is kept: the same voice (its clips, pace and when it was
    added) and the same words, made the same way (RENDER) by the same engine."""
    clips = [clip.get("file") for clip in voices.clips_of(voice, engine)]
    key = [RENDER, voice.get("id"), voice.get("addedAt"), voices.pace(voice, engine), clips, text]
    if engine != "ming":

        key.append(engine)
    return install.folder("kept-lines", hashlib.sha256(json.dumps(key).encode()).hexdigest()[:32])


def _kept_line(voice, text, engine="ming"):
    """(WAV, its info) for a line made before, or None."""
    path = _kept_path(voice, text, engine)
    try:
        with open(path + ".wav", "rb") as file:
            wav = file.read()
        with open(path + ".json") as file:
            info = json.load(file)
        os.utime(path + ".wav")
    except (OSError, ValueError):
        return None
    return wav, info


def _keep_line(job):
    try:
        path = _kept_path(job.voice, job.text, job.engine)
        os.makedirs(os.path.dirname(path), exist_ok=True)
        for ending, data, mode in ((".json", json.dumps(job.info), "w"), (".wav", job.wav, "wb")):
            temporary = path + ending + ".new"
            with open(temporary, mode) as file:
                file.write(data)
            os.replace(temporary, path + ending)
        folder = os.path.dirname(path)
        made = sorted((entry for entry in os.scandir(folder) if entry.name.endswith(".wav")),
                      key=lambda entry: entry.stat().st_mtime, reverse=True)
        for entry in made[KEEP_LINES:]:
            for ending in (".wav", ".json"):
                try:
                    os.remove(entry.path[:-4] + ending)
                except OSError:
                    pass
    except OSError:
        logger.exception("Audity DJ: couldn't keep a line made")


def split(text):
    """The line's pieces, each with the quiet after it: a beat at each "..." before a name, a pause
    after each sentence and each phrase, none at the end."""
    beats = [part.strip() for part in re.split(r"\.\.\.|…", text)]
    beats = [part for part in beats if re.search(r"\w", part)]
    if not beats:
        return [(text.strip(), 0.0)]
    pieces = []
    for beat in beats:
        phrases = _phrases(beat)
        pieces += phrases[:-1] + [(phrases[-1][0], NAME_PAUSE)]
    pieces[-1] = (pieces[-1][0], 0.0)
    return pieces


def beats(text):
    """The line's beats, each whole, with the quiet after it: a beat at each "..." before a name, none
    at the end."""
    parts = [part.strip() for part in re.split(r"\.\.\.|…", stops(text))]
    parts = [part for part in parts if re.search(r"\w", part)]
    if not parts:
        return [(text.strip(), 0.0)]
    return [(part, NAME_PAUSE) for part in parts[:-1]] + [(parts[-1], 0.0)]








_STOP = re.compile(r"(?:\s*[:;]|\s+[—–-])\s+(\w)")


def stops(text):
    """`text` with each colon, semicolon or dash between words made a full stop, the next word capitalized."""
    return _STOP.sub(lambda match: ". " + match.group(1).upper(), text)


def engine():
    """The voice lines are made in: NeuTTS Air once it's downloaded, ~~Ming~~ until then, or None."""
    if neutts_setup.is_ready():
        return "neutts"
    if install.is_ready():
        return "ming"
    return None


def _sentences(text):
    sentences, start = [], 0
    for match in re.finditer(r"[.!?]+(?=\s)", text):
        if match.group() == ".":
            word = re.search(r"([\w']+)$", text[start:match.start()])
            if word is None or len(word.group(1)) == 1 or word.group(1).lower() in ABBREVIATIONS:
                continue
        sentences.append(text[start:match.end()].strip())
        start = match.end()
    sentences.append(text[start:].strip())
    return [sentence for sentence in sentences if re.search(r"\w", sentence)]


def _phrases(text):
    """`text`'s sentences, each cut at its commas where both sides keep FEWEST_WORDS words, with the
    pause after each."""
    phrases = []
    for sentence in _sentences(text) or [text.strip()]:
        parts = [part for part in re.split(r"(?<=,)\s+", sentence) if part.strip()]
        current = ""
        for index, part in enumerate(parts):
            current = f"{current} {part}".strip()
            rest = " ".join(parts[index + 1:])
            if rest and len(_words(current)) >= FEWEST_WORDS and len(_words(rest)) >= FEWEST_WORDS:
                phrases.append((current, PHRASE_PAUSE))
                current = ""
        if current:
            phrases.append((current, SENTENCE_PAUSE))
    return phrases


def _words(text):

    words = re.findall(r"[a-z0-9']+", text.lower().replace("’", "'"))
    return [word.strip("'").split("'")[0] for word in words if word.strip("'")]


def slower(samples, pace):
    """`samples` said at `pace` of their speed (0.85: 15% slower) with their pitch kept: 40 ms pieces
    laid further apart, each moved up to 10 ms to where it lines up best with the one before (WSOLA),
    so it doesn't warble the way a plain stretch does."""
    if pace >= 0.999 or samples.size < SAMPLE_RATE // 10:
        return samples
    frame = int(0.04 * SAMPLE_RATE)
    hop = frame // 2
    step = hop * pace
    tolerance = int(0.01 * SAMPLE_RATE)
    window = np.hanning(frame).astype(np.float32)
    padded = np.concatenate([np.zeros(tolerance, np.float32), samples.astype(np.float32),
                             np.zeros(frame + tolerance, np.float32)])
    count = int((samples.size - frame) / step) + 1
    out = np.zeros(count * hop + frame, np.float32)
    weight = np.zeros_like(out)
    previous = None
    for index in range(count):
        position = int(round(index * step)) + tolerance
        if previous is not None:
            follows = padded[previous + hop:previous + hop + frame]
            around = padded[position - tolerance:position + tolerance + frame]
            position += int(np.argmax(np.correlate(around, follows, mode="valid"))) - tolerance
        out[index * hop:index * hop + frame] += padded[position:position + frame] * window
        weight[index * hop:index * hop + frame] += window
        previous = position
    weight[weight < 1e-3] = 1.0
    return (out / weight)[:int(samples.size / pace)]


def tidy(samples, threshold_db=-40):
    """Quiet trimmed from both ends down to LEAD_IN and TAIL, faded, and any pause inside longer than
    LONGEST_PAUSE shortened to it with its two sides blended: never cut mid-wave (see LEAD_IN)."""
    if samples.size == 0:
        return samples
    window = int(0.02 * SAMPLE_RATE)
    frames = len(samples) // window
    if frames == 0:
        return samples
    energy = np.sqrt(np.mean(samples[:frames * window].reshape(frames, window) ** 2, axis=1) + 1e-12)
    loud = energy > (np.max(energy) * 10 ** (threshold_db / 20))
    if not loud.any():
        return samples
    first, last = int(np.argmax(loud)), int(len(loud) - np.argmax(loud[::-1]) - 1)
    lead, tail, blend = int(LEAD_IN * SAMPLE_RATE), int(TAIL * SAMPLE_RATE), int(BLEND * SAMPLE_RATE)

    start, end = first * window - lead, (last + 1) * window + tail
    padded = np.concatenate([np.zeros(max(-start, 0), np.float32), samples.astype(np.float32),
                             np.zeros(max(end - len(samples), 0), np.float32)])
    shift = max(-start, 0)


    kept = [[start + shift, end + shift]]
    longest = int(LONGEST_PAUSE / 0.02)
    frame = first
    while frame <= last:
        if loud[frame]:
            frame += 1
            continue
        run = frame
        while not loud[run]:
            run += 1
        if run - frame > longest:
            keep = longest * window
            kept[-1][1] = frame * window + keep // 2 + shift
            kept.append([run * window - (keep - keep // 2) + shift, end + shift])
        frame = run
    out = padded[kept[0][0]:kept[0][1]]
    for begin, finish in kept[1:]:
        out = crossfade(out, padded[begin:finish], blend)


    out = out.copy()
    added_before, added_after = max(-start, 0), max(end - len(samples), 0)
    shortest = int(SHORTEST_FADE * SAMPLE_RATE)
    fade_in = min(max(lead - added_before, shortest), out.size // 2)
    fade_out = min(max(tail - added_after, shortest), out.size // 2)
    fade(out[added_before:added_before + fade_in], rising=True)
    fade(out[max(out.size - added_after - fade_out, 0):out.size - added_after], rising=False)
    return out


def fade(part, rising):
    """`part` (a view, changed in place) faded smoothly in from silence, or out to it."""
    ramp = np.sin(np.linspace(0, np.pi / 2, part.size, dtype=np.float32)) ** 2
    part *= ramp if rising else ramp[::-1]


def crossfade(before, after, length):
    """`before` running into `after`, the last `length` samples of one blended into the first of the other."""
    length = min(length, before.size, after.size)
    if length == 0:
        return np.concatenate([before, after])
    ramp = np.sin(np.linspace(0, np.pi / 2, length, dtype=np.float32)) ** 2
    middle = before[-length:] * (1 - ramp) + after[:length] * ramp
    return np.concatenate([before[:-length], middle, after[length:]])


def resample(samples, rate, to):
    """`samples` at `to` a second, with all the new rate can't hold taken out first, eased off over
    its top 8%. ~~Read between the old samples~~, which folded what was above the new rate back down
    as a hiss: fine for speech-to-text's 16 kHz, not for a line someone hears (2026-11-09). A whole
    line at once: each starts and ends in quiet (EDGE), so nothing wraps round from its other end."""
    samples = np.asarray(samples, dtype=np.float32)
    if rate == to or samples.size < 2:
        return samples
    length = max(int(round(samples.size * to / rate)), 1)
    spectrum = np.fft.rfft(samples.astype(np.float64))
    kept = np.zeros(length // 2 + 1, dtype=np.complex128)
    count = min(spectrum.size, kept.size)
    kept[:count] = spectrum[:count]
    if to < rate:
        top = kept.size - 1
        ease = max(int(top * 0.08), 1)
        kept[top - ease + 1:] *= np.cos(np.linspace(0, np.pi / 2, ease)) ** 2
    return (np.fft.irfft(kept, length) * (length / samples.size)).astype(np.float32)


def to_wav(samples, rate=SAMPLE_RATE):
    pcm = (np.clip(samples, -1, 1) * 32767).astype("<i2").tobytes()
    out = io.BytesIO()
    with wave.open(out, "wb") as file:
        file.setnchannels(1)
        file.setsampwidth(2)
        file.setframerate(rate)
        file.writeframes(pcm)
    return out.getvalue()


def from_wav(data):
    """(samples, rate) of a line `to_wav` wrote."""
    with wave.open(io.BytesIO(data), "rb") as file:
        rate = file.getframerate()
        pcm = file.readframes(file.getnframes())
    return np.frombuffer(pcm, dtype="<i2").astype(np.float32) / 32768, rate


box = Voicebox()
