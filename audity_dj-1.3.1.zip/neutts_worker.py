

















import argparse
import hashlib
import json
import os
import re
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

parser = argparse.ArgumentParser()
parser.add_argument("--port", type=int, required=True)
parser.add_argument("--model", required=True, help="NeuTTS Air's GGUF file")
parser.add_argument("--codes", required=True, help="a folder where each clip's codes are kept")
parser.add_argument("--threads", type=int, default=0, help="llama.cpp's threads; 0 measures them once")
parser.add_argument("--idle", type=float, default=90, help="seconds without a word from the plugin before it stops")
args = parser.parse_args()


import espeakng_loader
from phonemizer.backend.espeak.wrapper import EspeakWrapper

EspeakWrapper.set_library(espeakng_loader.get_library_path())
EspeakWrapper.set_data_path(espeakng_loader.get_data_path())

import numpy as np
import torch
import torchaudio
from llama_cpp import Llama
from neutts import NeuTTS

SAMPLE_RATE = 44_100
MADE_RATE = 24_000
state = {"loaded": False, "error": None, "heard_from": time.monotonic()}
speaking = threading.Lock()
tts = None
spent = {}


class _Voice(NeuTTS):
    """NeuTTS with its language model loaded for a processor: no memory lock (its own asks for one, which
    a container may refuse), and the thread count set after."""

    def _load_backbone(self, backbone_repo, backbone_device):
        self.backbone = Llama(model_path=backbone_repo, verbose=False, n_gpu_layers=0, n_ctx=self.max_context,
                              n_threads_batch=len(os.sched_getaffinity(0)))
        self._is_quantized_model = True


def _threads_file():
    return os.path.join(args.codes, "threads.json")


def _pick_threads(made):
    """llama.cpp's fastest thread count here, measured once (a few seconds) and kept. A step waits for its
    slowest thread, so on a processor with slow cores beside fast ones fewer can be quicker."""
    if args.threads > 0:
        return args.threads
    count = len(os.sched_getaffinity(0))
    try:
        with open(_threads_file()) as file:
            kept = json.load(file)
        if kept.get("count") == count and kept.get("threads"):
            return int(kept["threads"])
    except (OSError, ValueError):
        pass






    if os.getloadavg()[0] > count:
        print(f"The machine is busy: {max(1, count // 2)} threads, measured another time", flush=True)
        return max(1, count // 2)
    busy = False
    prompt =("user: Convert the text to speech:<|TEXT_PROMPT_START|>ðə dˈiːdʒˈeɪ ɪz ˈɑːn<|TEXT_PROMPT_END|>\n"
              "assistant:<|SPEECH_GENERATION_START|>")
    counts = sorted({n for n in (2, 4, 6, 8, count // 2, count) if 1 <= n <= count})
    times = {}
    for _ in range(2):
        for threads in counts:
            made.backbone._ctx.set_n_threads(threads, count)
            made.backbone.reset()
            made.backbone.set_seed(1)
            began = time.monotonic()
            made.backbone(prompt, max_tokens=48, temperature=1.0, top_k=50)
            times[threads] = min(times.get(threads, float("inf")), time.monotonic() - began)
    busy = busy or os.getloadavg()[0] > count
    best = min(times, key=times.get)
    print("Threads measured: " + ", ".join(f"{n}: {s:.2f} s" for n, s in sorted(times.items())) + f"; using {best}"
          + (" (the machine was busy: measured again next time)" if busy else ""), flush=True)
    if not busy:
        try:
            with open(_threads_file(), "w") as file:
                json.dump({"count": count, "threads": best, "measured": times}, file)
        except OSError:
            pass
    return best


def load():
    global tts
    try:
        began = time.monotonic()
        os.makedirs(args.codes, exist_ok=True)
        made = _Voice(backbone_repo=args.model, language="en-us", codec_repo="neuphonic/distill-neucodec")


        made.watermarker = None
        threads = _pick_threads(made)
        made.backbone._ctx.set_n_threads(threads, len(os.sched_getaffinity(0)))
        made.backbone.n_threads = threads
        tts = made
        state["loaded"] = True
        print(f"Voice loaded in {time.monotonic() - began:.0f} s ({threads} threads)", flush=True)
    except Exception as error:
        state["error"] = f"{type(error).__name__}: {error}"
        print(f"Voice failed to load: {state['error']}", flush=True)


def _codes(path):
    """A clip's sound codes, worked out the first time it's used and kept beside the others."""
    info = os.stat(path)
    key = hashlib.sha256(f"{os.path.abspath(path)}|{info.st_size}|{int(info.st_mtime)}".encode()).hexdigest()[:32]
    kept = os.path.join(args.codes, key + ".npy")
    if os.path.isfile(kept):
        return np.load(kept).tolist()
    codes = tts.encode_reference(path)
    codes = codes.cpu().numpy() if hasattr(codes, "cpu") else np.asarray(codes)
    np.save(kept + ".new.npy", codes.astype(np.int32))
    os.replace(kept + ".new.npy", kept)
    return codes.astype(np.int32).tolist()


def say(text, clips, seed):
    clip = clips[0]
    with speaking:
        spent.clear()
        spent["threads"] = tts.backbone.n_threads
        began = time.monotonic()
        codes = _codes(clip["path"])
        spent["clip"] = time.monotonic() - began
        tts.backbone.set_seed(int(seed))
        began = time.monotonic()
        written = tts._infer_ggml(codes, clip["words"].strip(), text)
        spent["languageModel"] = time.monotonic() - began

        spent["steps"] = len(re.findall(r"<\|speech_(\d+)\|>", written))
        if spent["steps"] == 0:



            return np.zeros(0, dtype=np.float32)
        began = time.monotonic()
        wave = torch.from_numpy(np.asarray(tts._decode(written), dtype=np.float32))
        spent["decoder"] = time.monotonic() - began


    held = int(0.1 * MADE_RATE)
    wave = torch.cat([wave[:1].repeat(held), wave, wave[-1:].repeat(held)])
    wave = torchaudio.functional.highpass_biquad(wave, MADE_RATE, 50.0)[held:-held]
    wave = torchaudio.functional.resample(wave, MADE_RATE, SAMPLE_RATE)
    return wave.numpy().astype(np.float32)


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *_):
        pass

    def _send(self, status, body, kind="application/json", headers=None):
        self.send_response(status)
        self.send_header("Content-Type", kind)
        for name, value in (headers or {}).items():
            self.send_header(name, value)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        state["heard_from"] = time.monotonic()
        if self.path == "/ready":
            self._send(200, json.dumps({"loaded": state["loaded"], "error": state["error"]}).encode())
        else:
            self._send(404, b"{}")

    def do_POST(self):
        state["heard_from"] = time.monotonic()
        length = int(self.headers.get("Content-Length") or 0)
        asked = json.loads(self.rfile.read(length) or b"{}")
        if self.path == "/beat":
            self._send(200, b"{}")
        elif self.path == "/say":
            if not state["loaded"]:
                self._send(503, json.dumps({"error": state["error"] or "loading"}).encode())
                return
            try:
                began = time.monotonic()
                samples = say(asked["text"], asked["clips"], asked.get("seed", 1))
                parts = dict(spent, total=time.monotonic() - began)
            except Exception as error:
                self._send(500, json.dumps({"error": f"{type(error).__name__}: {error}"}).encode())
                return
            finally:
                state["heard_from"] = time.monotonic()
            self._send(200, samples.tobytes(), "application/octet-stream", {"X-Spent": json.dumps(parts)})
        else:
            self._send(404, b"{}")


def watch():
    while True:
        time.sleep(5)
        if not speaking.locked() and time.monotonic() - state["heard_from"] > args.idle:
            print("No word from the plugin; stopping", flush=True)
            os._exit(0)


threading.Thread(target=load, daemon=True).start()
threading.Thread(target=watch, daemon=True).start()
ThreadingHTTPServer(("127.0.0.1", args.port), Handler).serve_forever()
