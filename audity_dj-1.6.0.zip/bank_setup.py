














import hashlib
import json
import os
import shutil
import subprocess
import threading
import time
import zipfile

import requests

from plugin.api import logger

from . import install




TORCH = ["torch==2.9.1"]
POCKET = "pocket-tts==4.0.1"
PACKAGES = ["numpy", "scipy", "safetensors", "sentencepiece", "tokenizers", "huggingface_hub", "requests",
            "pydantic", "pyyaml", "einops", "soundfile", "typing_extensions"]
CONSTRAINTS = os.path.join(os.path.dirname(os.path.abspath(__file__)), "bank-constraints.txt")


RELEASE = os.environ.get("AUDITY_DJ_RELEASES",
                         "https://github.com/rexmoriarty/audity-dj-plugin/releases/download").rstrip("/")
POCKET_TAG = "pocket-tts-1"

POCKET_FILES = [
    ("pocket-tts-english.safetensors", "pocket/model.safetensors", 219_029_196,
     "bc96b82436c5ec00d3118ef3b01bc3358423e1766ecae3dca0aeea84789e7d74",
     "https://huggingface.co/kyutai/pocket-tts/resolve/db04f0e653473e5c7333c69686ac92b7460b0c1d/languages/english/model.safetensors"),
    ("pocket-tts-english-tokenizer.json", "pocket/tokenizer.json", 245_020,
     "f498428e1eafee50492f7be13dc9bfafcfc12e508cd0eb1b01c92ecd5d8c6687",
     "https://huggingface.co/kyutai/pocket-tts-without-voice-cloning/resolve/00eac05ed3d16bdc3f6b5d598874019c34a89214/languages/english/tokenizer.json"),
]
GATED = ("pocket-tts-english.safetensors",)





PACK = {"id": "theo-qwen-1", "tag": "bank-theo-qwen-1", "file": "bank-theo-qwen-1.zip", "bytes": 286_743_609,
        "sha256": "1836cd6b944e5f6bb442d431fed5fbec504430a0394738d3ebb0998519149636"}


DISK_GB = 1.6


def folder(*parts):
    return install.folder("bank", *parts)


def python():
    return folder("env", "bin", "python")


def pack_dir(pack_id=None):
    return folder("packs", pack_id or _read_state().get("pack") or PACK["id"])


def model_file():
    return folder("pocket", "model.safetensors")


def tokenizer_file():
    return folder("pocket", "tokenizer.json")


_packs = {}


def pack():
    """The bank's pack.json in use, or {}: read again only once it's changed (5,870 clips, asked for by
    every hello and every refresh of the page)."""
    path = os.path.join(pack_dir(), "pack.json")
    try:
        stamp = os.stat(path).st_mtime_ns
        kept = _packs.get(path)
        if kept is None or kept[0] != stamp:
            with open(path, encoding="utf-8") as file:
                kept = (stamp, json.load(file))
            _packs.clear()
            _packs[path] = kept
        return kept[1]
    except (OSError, ValueError):
        return {}


def pack_id():
    return _read_state().get("pack")


_state_lock = threading.Lock()
_job = {"thread": None, "process": None, "stop": False}


def _read_state():
    try:
        with open(install.folder("bank.json")) as file:
            return json.load(file)
    except (OSError, ValueError):
        return {}


def _write_state(**values):
    with _state_lock:
        state = _read_state()
        state.update(values)
        os.makedirs(install.folder(), exist_ok=True)
        temporary = install.folder("bank.json.new")
        with open(temporary, "w") as file:
            json.dump(state, file)
        os.replace(temporary, install.folder("bank.json"))


def status():
    """{"state": "none" | "downloading" | "ready" | "failed", "step", "fraction", "error", "needsToken",
    "pack", "newer"}: "newer" when a bank newer than the one in use can be downloaded."""
    state = _read_state()
    if state.get("state") == "downloading" and not (_job["thread"] and _job["thread"].is_alive()):
        state.update(state="failed", error="The download stopped when AudioMuse-AI restarted. Try again.")
        if _ready_files():
            state["state"] = "ready"
    state.setdefault("state", "none")
    state["newer"] = bool(_ready_files()) and state.get("pack") != PACK["id"]
    return state


def _ready_files():
    return (os.path.isfile(python()) and os.path.isfile(model_file()) and os.path.isfile(tokenizer_file())
            and bool(_read_state().get("pack")) and os.path.isfile(os.path.join(pack_dir(), "pack.json")))


def is_ready():
    """Whether the bank can talk: downloaded once, even while a newer bank comes down."""
    state = _read_state()
    return bool(state.get("state") == "ready" or state.get("ready")) and _ready_files()


def start(token=None):
    """Its download begun; `token`, a Hugging Face token typed on the page, is used for this download only
    and never kept."""
    if _job["thread"] and _job["thread"].is_alive():
        return
    _job["stop"] = False
    _write_state(state="downloading", step="Starting", fraction=0.0, error=None, needsToken=False, ready=is_ready())
    _job["thread"] = threading.Thread(target=_download, args=((token or "").strip() or None,),
                                      name="audity-dj-bank-download", daemon=True)
    _job["thread"].start()


def stop():
    _job["stop"] = True
    process = _job["process"]
    if process and process.poll() is None:
        process.kill()


def remove():
    stop()
    if _job["thread"]:
        _job["thread"].join(timeout=30)
    shutil.rmtree(folder(), ignore_errors=True)
    _write_state(state="none", step=None, fraction=0.0, error=None, needsToken=False, pack=None, ready=False)


class _Stopped(Exception):
    pass


class _NeedsToken(Exception):
    pass


def _run(command, step, fraction, env):
    _write_state(step=step, fraction=fraction)
    if _job["stop"]:
        raise _Stopped()
    with open(install.folder("download.log"), "a") as log:
        log.write(f"\n$ {' '.join(command)}\n")
        log.flush()
        process = subprocess.Popen(command, stdout=log, stderr=subprocess.STDOUT, env=env)
        _job["process"] = process
        code = process.wait()
        _job["process"] = None
    if _job["stop"]:
        raise _Stopped()
    if code != 0:
        raise RuntimeError(f"{step} failed (see {install.folder('download.log')})")


def _packages_ready():
    if not os.path.isfile(python()):
        return False
    try:
        with open(folder("env", "audity-packages.json")) as file:
            return json.load(file) == [POCKET] + TORCH + PACKAGES
    except (OSError, ValueError):
        return False


def _download(token):
    try:
        os.makedirs(folder(), exist_ok=True)
        open(install.folder("download.log"), "w").close()
        env = install._clean_env()
        if not _packages_ready():
            system_python = "/usr/bin/python3" if os.path.isfile("/usr/bin/python3") else "python3"
            pip = [system_python, "-I", "-m", "pip", "--python", python(), "install", "--no-cache-dir", "--only-binary=:all:"]
            if not os.path.isfile(python()):
                _run([system_python, "-I", "-m", "venv", "--without-pip", folder("env")], "Making the voice's Python", 0.01, env)

            _run(pip + TORCH + ["--index-url", install.TORCH_INDEX], "Downloading PyTorch for processors", 0.02, env)
            _run(pip + [POCKET, "--no-deps"], "Downloading Pocket TTS", 0.2, env)
            _run(pip + PACKAGES + TORCH + ["-c", CONSTRAINTS, "--extra-index-url", install.TORCH_INDEX],
                 "Downloading the voice's packages", 0.25, env)
            with open(folder("env", "audity-packages.json"), "w") as file:
                json.dump([POCKET] + TORCH + PACKAGES, file)
        files = [(POCKET_TAG, *each) for each in POCKET_FILES]
        unpacked = os.path.isfile(folder("packs", PACK["id"], "pack.json")) and _read_state().get("pack") == PACK["id"]
        if not unpacked:
            files.append((PACK["tag"], PACK["file"], os.path.join("packs", PACK["file"]), PACK["bytes"], PACK["sha256"], None))
        total = sum(each[3] for each in files) or 1
        got = 0
        for tag, published, target, size, digest, mirror in files:
            got = _fetch(tag, published, folder(target), size, digest, mirror, token, got, total)
        if not unpacked:
            _unpack(folder("packs", PACK["file"]), PACK["id"])
        _write_state(state="ready", step=None, fraction=1.0, error=None, needsToken=False, pack=PACK["id"], ready=True)

        for name in os.listdir(folder("packs")):
            if name != PACK["id"] and not name.startswith("."):
                shutil.rmtree(folder("packs", name), ignore_errors=True)
        logger.info("Audity DJ: Theo's bank and Pocket TTS are downloaded")
    except _Stopped:
        _write_state(state="ready" if is_ready() else "none", step=None, fraction=0.0, error=None)
    except _NeedsToken as error:
        _write_state(state="failed", error=str(error), needsToken=True)
    except Exception as error:
        logger.exception("Audity DJ: the bank's download failed")
        _write_state(state="failed", error=str(error))


def _fetch(tag, published, path, size, digest, mirror, token, got, total):
    """One file, checked against its SHA-256; returns the bytes downloaded so far, for the bar."""
    if os.path.isfile(path) and os.path.getsize(path) == size and _sha256(path) == digest:
        return got + size
    os.makedirs(os.path.dirname(path), exist_ok=True)
    sources = [(f"{RELEASE}/{tag}/{published}", {})]
    if mirror and (published not in GATED or token):
        sources.append((mirror, {"Authorization": f"Bearer {token}"} if token and published in GATED else {}))
    problems = []
    for url, headers in sources:
        _write_state(step=f"Downloading {published}")
        try:
            answer = requests.get(url, headers=headers, stream=True, timeout=60)
        except requests.RequestException as error:
            problems.append(str(error))
            continue
        if answer.status_code != 200:
            problems.append(f"{answer.status_code} from {url.split('/')[2]}")
            answer.close()
            continue
        hashed, done, partial = hashlib.sha256(), 0, path + ".part"
        last = 0.0
        with answer, open(partial, "wb") as out:
            for chunk in answer.iter_content(1 << 20):
                if _job["stop"]:
                    raise _Stopped()
                out.write(chunk)
                hashed.update(chunk)
                done += len(chunk)
                if time.monotonic() - last > 2:
                    last = time.monotonic()
                    _write_state(fraction=0.3 + 0.68 * min((got + done) / total, 1.0))
        if hashed.hexdigest() != digest:
            os.remove(partial)
            problems.append(f"{published} came down damaged")
            continue
        os.replace(partial, path)
        return got + size
    if published in GATED and not token:
        raise _NeedsToken("Kyutai's Pocket TTS weights are on Hugging Face for accounts that accepted their terms: "
                          "paste a Hugging Face token on the Audity DJ page in AudioMuse-AI (it's used for this download only).")
    raise RuntimeError(f"Couldn't download {published}: {'; '.join(problems)}")


def _sha256(path):
    hashed = hashlib.sha256()
    with open(path, "rb") as file:
        for chunk in iter(lambda: file.read(1 << 20), b""):
            hashed.update(chunk)
    return hashed.hexdigest()


def _unpack(archive, pack_id):
    """The bank's zip opened into packs/<id>, only its own files (no paths out of it), then the zip
    removed."""
    _write_state(step="Opening the bank", fraction=0.99)
    target, temporary = folder("packs", pack_id), folder("packs", f".{pack_id}.new")
    shutil.rmtree(temporary, ignore_errors=True)
    os.makedirs(temporary)
    with zipfile.ZipFile(archive) as package:
        for info in package.infolist():
            name = os.path.normpath(info.filename)
            if info.is_dir() or name.startswith(("..", os.sep)) or os.path.isabs(name):
                continue
            out = os.path.join(temporary, name)
            os.makedirs(os.path.dirname(out), exist_ok=True)
            with package.open(info) as source, open(out, "wb") as dest:
                shutil.copyfileobj(source, dest)
    with open(os.path.join(temporary, "pack.json"), encoding="utf-8") as file:
        if json.load(file).get("id") != pack_id:
            raise RuntimeError("The bank that came down isn't the one asked for.")
    shutil.rmtree(target, ignore_errors=True)
    os.replace(temporary, target)
    os.remove(archive)


def disk_bytes():
    return install.kept_size(folder(), install.folder("bank.json"))
