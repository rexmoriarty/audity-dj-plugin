





from html import escape

from . import bank_setup

_STYLE = """
<style>
.adj { max-width: 760px; margin: 0 auto; }
.adj [hidden] { display: none !important; }
.adj .intro { text-align: center; color: var(--text-muted); max-width: 560px; margin: 0 auto 1.5rem; line-height: 1.5; }
.adj section { margin: 0 0 1.25rem; }
.adj h3 { margin: 0 0 .75rem; font-size: 1.125rem; color: var(--text-title); }
.adj h4 { margin: 1.75rem 0 .75rem; font-size: 1rem; color: var(--text-title); }
.adj p { margin: 0; }
.adj .muted { color: var(--text-muted); }
.adj .note { color: var(--text-muted); font-size: .875rem; margin-top: .75rem; line-height: 1.5; }
.adj .list { border-top: 1px solid var(--border-color); }
.adj .item { border-bottom: 1px solid var(--border-color); }
.adj .line { display: flex; align-items: center; gap: .75rem; min-height: 3.25rem; padding: .55rem 0; }
.adj .grow { flex: 1; min-width: 0; }
.adj .title { color: var(--text-title); font-weight: 500; }
.adj .sub { color: var(--text-muted); font-size: .875rem; margin-top: .1rem; }
.adj .side { color: var(--text-muted); font-size: .875rem; white-space: nowrap; }
.adj .badge { display: inline-block; font-size: .75rem; font-weight: 500; color: var(--text-muted);
  border: 1px solid var(--border-color-darker); border-radius: 999px; padding: 0 .45rem; margin-left: .4rem; vertical-align: 1px; }
.adj .dot { display: inline-block; width: .5rem; height: .5rem; border-radius: 50%; background: var(--border-color-darker); margin-right: .45rem; vertical-align: 1px; }
.adj .dot.on { background: var(--color-success); }
.adj .dot.warm { background: #D97706; }
.adj .play { flex: none; width: 2.25rem; height: 2.25rem; border-radius: 50%; border: 1px solid var(--border-color-darker);
  background: transparent; color: var(--text-title); cursor: pointer; display: inline-grid; place-items: center; padding: 0; }
.adj .play:hover { background: var(--bg-body); }
.adj .play svg { width: .8rem; height: .8rem; fill: currentColor; }
.adj .quiet { background: none; border: none; padding: .35rem .5rem; font-size: .875rem; font-weight: 500; cursor: pointer; color: var(--color-primary); border-radius: .375rem; }
.adj .quiet:hover { background: var(--bg-body); }
.adj .quiet.danger { color: var(--color-danger); }
.adj form.inline { display: inline; margin: 0; }
.adj .actions { display: flex; align-items: center; gap: .75rem; flex-wrap: wrap; margin-top: 1rem; }
.adj .actions.end { justify-content: flex-end; }
.adj progress { flex: 1; min-width: 160px; height: .5rem; accent-color: var(--color-primary); }
.adj .fields { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 1rem; }
.adj .fields.two { grid-template-columns: repeat(2, minmax(0, 1fr)); }
.adj .field { margin-top: 1rem; }
.adj .fields .field { margin-top: 0; }
.adj .field label { margin-bottom: .35rem; }
.adj select { margin-bottom: .75rem; -webkit-appearance: none; appearance: none; padding-right: 2.75rem;
  background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 12 8'%3E%3Cpath d='M1 1.5l5 5 5-5' fill='none' stroke='%234B5563' stroke-width='1.6' stroke-linecap='round' stroke-linejoin='round'/%3E%3C/svg%3E"); background-repeat: no-repeat; background-position: right .9rem center; background-size: .75rem; }
html.dark-mode .adj select, body.dark-mode .adj select { background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 12 8'%3E%3Cpath d='M1 1.5l5 5 5-5' fill='none' stroke='%239CA3AF' stroke-width='1.6' stroke-linecap='round' stroke-linejoin='round'/%3E%3C/svg%3E"); }
.adj textarea { min-height: 0; font: inherit; line-height: 1.5; }
.adj input[type=file] { display: block; width: 100%; font-size: .875rem; color: var(--text-sub); }
.adj input[type=file]::file-selector-button { font: inherit; font-weight: 500; color: var(--text-sub); background: transparent;
  border: 1px solid var(--border-color-darker); border-radius: .375rem; padding: .35rem .7rem; margin-right: .75rem; cursor: pointer; }
.adj input[type=file]::file-selector-button:hover { background: var(--bg-body); }
.adj .editor { padding: 0 0 1rem 3rem; }
.adj .empty { text-align: center; color: var(--text-muted); padding: 1.25rem 0 .5rem; }
.adj audio { display: block; width: 100%; margin-top: 1rem; }
.adj .error { color: var(--color-danger); font-size: .875rem; margin-top: .5rem; }
.adj .sub .error { margin: 0; }
.adj pre { white-space: pre-wrap; word-break: break-word; font-size: .75rem; margin: .5rem 0 0; }
@media (max-width: 640px) {
  .adj .fields, .adj .fields.two { grid-template-columns: minmax(0, 1fr); }
  .adj .editor { padding-left: 0; }
  .adj .line { flex-wrap: wrap; }
}
</style>
"""

_SCRIPT = """
<script>
(function () {
  const $ = (id) => document.getElementById(id);
  const PLAY = '<svg viewBox="0 0 12 12" aria-hidden="true"><path d="M3 1.5v9l7.5-4.5z"/></svg>';
  const STOP = '<svg viewBox="0 0 12 12" aria-hidden="true"><rect x="2.5" y="2.5" width="7" height="7" rx="1"/></svg>';
  const sample = new Audio();
  let playing = null, shownVoices = '', shownFor = '';
  function esc(t) { const d = document.createElement('div'); d.textContent = t == null ? '' : String(t); return d.innerHTML; }
  function gb(bytes) { return (bytes / 1e9).toFixed(1) + ' GB'; }
  function stopSample() {
    sample.pause();
    if (playing) { playing.innerHTML = PLAY; playing.setAttribute('aria-label', playing.dataset.label); }
    playing = null;
  }
  sample.onended = stopSample;
  // A voice's clip, the one it's copied from; a second tap stops it.
  document.addEventListener('click', function (event) {
    const button = event.target.closest('.adj .play');
    if (button) {
      const again = playing === button;
      stopSample();
      if (again) return;
      sample.src = button.dataset.clip;
      sample.play();
      playing = button;
      button.innerHTML = STOP;
      button.setAttribute('aria-label', 'Stop');
      return;
    }
    const edit = event.target.closest('.adj [data-edit]');
    if (edit) {
      const editor = $('edit-' + edit.dataset.edit);
      editor.hidden = !editor.hidden;
      edit.textContent = editor.hidden ? 'Edit' : 'Cancel';
      if (!editor.hidden) editor.querySelector('input').focus();
    }
  });
  function voiceRow(x) {
    const id = encodeURIComponent(x.id), label = 'Play ' + x.name;
    return '<div class="item"><div class="line">'
      + '<button type="button" class="play" data-clip="voices/' + id + '/clip" data-label="' + esc(label) + '" aria-label="' + esc(label) + '">' + PLAY + '</button>'
      + '<div class="grow"><div class="title">' + esc(x.name) + (x.isDefault ? '<span class="badge">Default</span>' : '') + '</div>'
      + (x.detail ? '<div class="sub">' + esc(x.detail) + '</div>' : '') + '</div>'
      + '<div class="side">' + (x.onlyFor ? 'Only ' + esc(x.onlyFor) : 'Everyone') + '</div>'
      + '<button type="button" class="quiet" data-edit="' + esc(x.id) + '">Edit</button>'
      + (x.added ? '<form class="inline" method="post" action="voices/' + id + '/remove" onsubmit="return confirm(\\'Remove ' + esc(x.name).replace(/'/g, '&#39;') + '? Anyone using it goes back to the default voice.\\')"><button class="quiet danger">Remove</button></form>' : '')
      + '</div>'
      + '<form class="editor" id="edit-' + esc(x.id) + '" method="post" action="voices/' + id + '/edit" hidden>'
      + '<div class="fields' + (x.added ? '' : ' two') + '">'
      + '<div class="field"><label>Name</label><input type="text" name="name" maxlength="40" required value="' + esc(x.name) + '"></div>'
      + '<div class="field"><label>Description</label><input type="text" name="detail" maxlength="60" placeholder="Optional" value="' + esc(x.detail || '') + '"></div>'
      + (x.added ? '<div class="field"><label>Only for the account</label><input type="text" name="onlyFor" placeholder="Everyone if empty" value="' + esc(x.onlyFor || '') + '"></div>' : '')
      + '</div><div class="actions end"><button class="btn btn-primary btn-sm">Save</button></div></form></div>';
  }
  async function refresh() {
    let s;
    try { s = await (await fetch('status.json', {credentials: 'same-origin'})).json(); } catch (e) { return; }
    const v = s.voice;
    $('voice-ready').hidden = !v.ready || v.state === 'downloading';
    $('voice-none').hidden = !(v.state === 'none' || v.state === 'failed' || (v.newer && v.state !== 'downloading'));
    $('voice-coming').hidden = v.state !== 'downloading';
    $('voice-sub').textContent = v.state === 'downloading' ? (v.step || 'Downloading')
      : v.state === 'failed' ? 'The download failed' + (v.ready ? '; the bank before it still talks' : '')
      : v.ready ? 'Downloaded, ' + gb(v.diskBytes) + ', ' + v.clips + ' clips' + (v.newer ? '. A newer bank is out.' : '')
      : 'Not downloaded';
    $('voice-error').textContent = v.state === 'failed' ? (v.error || '') : '';
    $('voice-token').hidden = !v.needsToken;
    $('voice-go').textContent = v.newer ? 'Download the New Bank' : 'Download the Voice';
    // The voices before 1.4.0, while they're on the disk.
    $('earlier').innerHTML = s.earlier.filter((x) => x.present).map((x) => '<div class="item"><div class="line">'
      + '<div class="grow"><div class="title">Earlier Voice: ' + esc(x.name) + '</div><div class="sub">'
      + (x.inUse ? 'The DJ&#39;s voice until Theo&#39;s bank is downloaded' : x.ready ? 'Not used now' : 'Not downloaded')
      + (x.diskBytes ? ', ' + gb(x.diskBytes) : '') + '</div></div>'
      + '<form class="inline" method="post" action="download" onsubmit="return confirm(&#39;Remove ' + esc(x.name)
      + ', an earlier voice? Theo&#92;&#39;s bank is the DJ&#92;&#39;s voice once it&#92;&#39;s downloaded.&#39;)">'
      + '<input type="hidden" name="action" value="' + (x.id === 'neutts' ? 'remove-neutts' : 'remove-earlier') + '">'
      + '<button class="quiet danger">Remove</button></form></div></div>').join('');
    if (v.state === 'downloading') {
      $('voice-bar').value = v.fraction || 0;
      $('voice-percent').textContent = Math.round((v.fraction || 0) * 100) + '%';
    }
    const se = s.session;
    $('session-dot').className = 'dot' + (!se.running ? '' : se.warming ? ' warm' : ' on');
    $('session').textContent = !se.running ? (se.alwaysOn ? 'Starting the voice…' : 'Off. Nothing of the voice is running.')
      : (se.warming ? 'Starting the voice (' + se.since + ' s)…'
        : se.alwaysOn ? 'Loaded, and kept loaded.' + (se.listeners.length ? ' DJ on for ' + se.listeners.join(', ') + '.' : '')
        : 'On for ' + se.listeners.join(', ') + '.')
        + (se.names === false && !se.namesError ? ' Pocket TTS is loading for names.' : '')
        + (se.waiting ? ' ' + se.waiting + ' line(s) being made.' : '');
    if (se.namesError) { $('session').textContent += ' Names can\\'t be said: ' + se.namesError; }
    if (se.error) { $('session').textContent += ' Problem: ' + se.error; }
    // Drawn again only when they change, so a clip playing or a name being edited isn't lost.
    const voices = JSON.stringify(s.voices);
    if (voices !== shownVoices || v.engine !== shownFor) {
      shownVoices = voices;
      shownFor = v.engine;
      stopSample();
      $('voices').innerHTML = s.voices.map(voiceRow).join('');
      const pick = $('try-voice'), was = pick.value;
      // Theo's bank is Theo alone.
      const offered = v.engine === 'bank' ? s.voices.filter((x) => x.isDefault) : s.voices;
      pick.innerHTML = offered.map((x) => '<option value="' + esc(x.id) + '">' + esc(x.name) + '</option>').join('');
      if (was) pick.value = was;
    }
    // The last lines asked, newest first: how each was made, in how long, and when the app fetched it.
    $('recent').innerHTML = s.recent.length ? s.recent.map((r) => {
      const how = r.state === 'done' ? (r.kept ? 'Kept from before' : !r.newWords ? 'Bank clips'
          : r.namesLeftOut ? 'Clips, names left out' : r.clips ? 'Clips and Pocket TTS' : 'Pocket TTS alone')
        : r.state === 'failed' ? 'Failed' : r.state === 'cancelled' ? 'Let go' : r.state === 'making' ? 'Being made' : 'Waiting';
      const when = r.state === 'done' || r.state === 'failed' ? ' in ' + r.madeIn + ' s' : '';
      const got = r.state !== 'done' ? '' : r.fetched != null ? ' · fetched at ' + r.fetched + ' s' : ' · not fetched';
      return '<div class="item"><div class="line"><div class="grow"><div class="title">' + esc(r.text) + '</div>'
        + '<div class="sub">' + esc(how + when + got) + (r.newWords ? ' · Pocket TTS: ' + esc(r.newWords) : '')
        + (r.error ? '<span class="error"> ' + esc(r.error) + '</span>' : '') + '</div></div>'
        + '<div class="side">' + esc(new Date(r.at * 1000).toLocaleTimeString()) + ' · ' + esc(r.listener) + '</div></div></div>';
    }).join('') : '<div class="empty">No lines asked since AudioMuse-AI started.</div>';
    $('voice-log').textContent = (s.voiceLog || []).join('\\n') + (s.voiceLogBefore && s.voiceLogBefore.length
      ? '\\n\\nBefore it last started:\\n' + s.voiceLogBefore.join('\\n') : '');
    const names = Object.fromEntries(s.voices.map((x) => [x.id, x.name]));
    $('listeners').innerHTML = s.listeners.length ? s.listeners.map((l) => '<div class="item"><div class="line"><div class="grow">'
      + '<div class="title">' + esc(l.username) + '</div><div class="sub">' + esc(names[l.voice] || l.voice || names[s.voices.find((x) => x.isDefault)?.id] || 'The default voice') + ' · '
      + l.lines + (l.lines === 1 ? ' line kept' : ' lines kept') + '</div></div><div class="side">'
      + (l.updated ? esc(new Date(l.updated).toLocaleString()) : '') + '</div></div></div>').join('')
      : '<div class="empty">No one has used the DJ yet.</div>';
  }
  $('try-go').onclick = async function () {
    const text = $('try-text').value.trim();
    if (!text) return;
    stopSample();
    $('try-go').disabled = true;
    $('try-state').textContent = 'Asked…';
    $('try-spent').textContent = '';
    const begun = Date.now();
    const asked = await fetch('try', {method: 'POST', headers: {'Content-Type': 'application/json'},
      credentials: 'same-origin', body: JSON.stringify({text: text, voice: $('try-voice').value})});
    const got = await asked.json();
    if (!asked.ok) { $('try-state').textContent = got.error || 'Couldn\\'t ask.'; $('try-go').disabled = false; return; }
    while (true) {
      await new Promise((r) => setTimeout(r, 2000));
      const answer = await fetch('try/' + got.id, {credentials: 'same-origin'});
      if (answer.status === 200) {
        const info = JSON.parse(answer.headers.get('X-Audity-Line') || '{}');
        $('try-audio').src = URL.createObjectURL(await answer.blob());
        $('try-audio').hidden = false;
        $('try-audio').play();
        fetch('try/' + got.id + '?done=1', {credentials: 'same-origin'});
        const voice = shownVoices ? (JSON.parse(shownVoices).find((x) => x.id === info.voice) || {}).name : null;
        $('try-state').textContent = 'Made in ' + Math.round((Date.now() - begun) / 1000) + ' s ('
          + info.seconds + ' s of speech' + (voice ? ', in ' + voice : '') + '). '
          + (info.engine !== 'bank' ? 'Heard back: “' + (info.heard || '') + '”'
            : info.newWords ? 'Said by Pocket TTS: “' + info.newWords + '”' + (info.namesLeftOut ? ', left out as it wasn\\'t ready in time' : '')
            : 'All from the bank.');
        // Where the time went on this machine (kept lines say nothing: made before).
        const sp = info.spent, one = (x) => (Math.round(10 * (x || 0)) / 10) + ' s';
        $('try-spent').textContent = !sp ? '' : sp.engine === 'bank'
          ? 'Bank clips ' + (info.clips || 0) + ' (reading them ' + one(sp.reading) + ') · Pocket TTS ' + one(sp.pocket)
            + ' for ' + (sp.newWords || 0) + ' words · its codec ' + one(sp.codec) + ' · waiting for it ' + one(sp.loading)
            + ' · ' + (sp.threads || '?') + ' threads'
          : sp.engine === 'neutts'
          ? 'NeuTTS Air: loading the voice ' + one(sp.loading) + ' · speaking ' + one(sp.speaking) + ' (language model '
            + one(sp.languageModel) + ' for ' + (sp.steps || 0) + ' sound codes, ' + Math.round(1000 * (sp.languageModel || 0) / Math.max(sp.steps || 1, 1))
            + ' ms each; decoder ' + one(sp.decoder) + ') · checking ' + one(sp.checking) + ' · ' + (sp.threads || '?') + ' threads'
          : 'Ming: loading the voice ' + Math.round(sp.loading) + ' s · speaking '
          + Math.round(sp.speaking) + ' s (' + (sp.steps || 0) + ' steps: ' + Math.round(1000 * (sp.languageModel || 0) / Math.max(sp.steps || 1, 1))
          + ' ms each in the language model, ' + Math.round(1000 * (sp.flowHead || 0) / Math.max(sp.steps || 1, 1)) + ' ms in the flow head' + (sp.flowBits ? ' (' + sp.flowBits + '-bit)' : '') + '; '
          + Math.round(sp.decoder || 0) + ' s decoding) · checking ' + Math.round(sp.checking) + ' s · ' + (sp.threads || '?') + ' threads';
        break;
      }
      if (answer.status !== 202) { const e = await answer.json(); $('try-state').textContent = e.error || 'It failed.'; break; }
      const w = await answer.json();
      $('try-state').textContent = w.session && w.session.warming ? 'Starting the voice (' + w.session.since + ' s)…'
        : 'Making it (' + Math.round((Date.now() - begun) / 1000) + ' s)…';
    }
    $('try-go').disabled = false;
  };
  refresh();
  setInterval(refresh, 3000);
})();
</script>
"""


def html(version):
    return _STYLE + f"""
<div class="adj">
<p class="intro">Version {escape(version)}. Audity finds this by itself, and its DJ station plays once the voice is downloaded.
The voice runs only while someone's DJ is on, and stops when the last one turns it off or closes Audity.</p>

<section>
  <h3>Status</h3>
  <div class="list">
    <div class="item"><div class="line">
      <div class="grow"><div class="title">Voice: Theo's Bank and Pocket TTS</div><div class="sub" id="voice-sub">…</div></div>
      <form id="voice-ready" class="inline" method="post" action="download" hidden
        onsubmit="return confirm('Remove Theo\\'s bank? The DJ talks in an earlier voice if one is here, or not at all until it\\'s downloaded again.')">
        <input type="hidden" name="action" value="remove"><button class="quiet danger">Remove</button></form>
    </div></div>
    <div id="earlier"></div>
    <div class="item"><div class="line">
      <div class="grow"><div class="title">Right Now</div><div class="sub"><span id="session-dot" class="dot"></span><span id="session">…</span></div></div>
    </div></div>
  </div>
  <div id="voice-none" hidden>
    <p class="note">The DJ's voice is Theo's bank: about 9,700 sentences made ahead by Qwen3-TTS, each a clip, played as they are. Only what
    the bank can't have, the names of songs, artists and albums, is said on this server's processor, by Pocket TTS (Kyutai,
    CC-BY-4.0), in Theo's voice, in about a second. It needs a one-time download of about {bank_setup.DISK_GB:.1f} GB (PyTorch for
    processors, Pocket TTS and the bank), kept in the plugins volume.</p>
    <p id="voice-error" class="error"></p>
    <form method="post" action="download"><input type="hidden" name="action" value="start">
      <div class="field" id="voice-token" hidden><label for="adj-token">Hugging Face token (read access, from an account that accepted
        kyutai/pocket-tts's terms): used for this download only, never kept</label>
        <input id="adj-token" type="password" name="token" autocomplete="off"></div>
      <div class="actions"><button class="btn btn-primary" id="voice-go">Download the Voice</button></div></form>
  </div>
  <div id="voice-coming" hidden>
    <div class="actions"><progress id="voice-bar" max="1" value="0"></progress><span id="voice-percent" class="muted"></span>
      <form class="inline" method="post" action="download"><input type="hidden" name="action" value="stop">
      <button class="btn btn-ghost btn-sm">Stop</button></form></div>
  </div>
</section>

<section>
  <h3>Try a Line</h3>
  <select id="try-voice" aria-label="Voice"></select>
  <textarea id="try-text" rows="3" aria-label="Words">Good evening. Let's start with a few of your favorites. Here's Steely Dan... Peg.</textarea>
  <div class="actions"><button type="button" class="btn btn-primary" id="try-go">Say It</button><span id="try-state" class="muted"></span></div>
  <p id="try-spent" class="muted"></p>
  <audio id="try-audio" controls hidden></audio>
  <p class="note">Sentences the bank has are its clips; the rest, names most of all, Pocket TTS says, with a beat at "..." before a
  name, as Audity writes its lines. A line waits a few seconds at most for its names, then goes without them, so the DJ never waits.</p>
</section>

<section>
  <h3>Recent Lines</h3>
  <div class="list" id="recent"></div>
  <details class="note"><summary>What the voice said as it started</summary><pre id="voice-log" class="muted"></pre></details>
</section>

<section>
  <h3>Voices</h3>
  <div class="list" id="voices"></div>
  <p class="note">Each listener picks their voice in Audity, which shows these names and descriptions. A voice is copied from a short clip
  of someone talking (5 to 15 s) with its exact words: a wrong word changes the voice. Only add someone's voice with their permission.</p>

  <h4>Add a Voice</h4>
  <form method="post" action="voices/add" enctype="multipart/form-data">
    <div class="fields">
      <div class="field"><label for="adj-name">Name</label><input id="adj-name" type="text" name="name" maxlength="40" required></div>
      <div class="field"><label for="adj-detail">Description</label><input id="adj-detail" type="text" name="detail" maxlength="60" placeholder="Optional"></div>
      <div class="field"><label for="adj-only">Only for the account</label><input id="adj-only" type="text" name="onlyFor" placeholder="Everyone if empty"></div>
    </div>
    <div class="field"><label for="adj-clip">Clip (WAV or FLAC): clear, lively talk copies best, as the voice keeps its feeling and pace</label>
      <input id="adj-clip" type="file" name="clip1" accept=".wav,.flac"></div>
    <div class="field"><label for="adj-words">The clip's exact words</label><textarea id="adj-words" name="words1" rows="2"></textarea></div>
    <div class="field"><label for="adj-package">Or a voice package (.zip with voice.json and its clip)</label>
      <input id="adj-package" type="file" name="package" accept=".zip"></div>
    <div class="actions"><button class="btn btn-primary">Add Voice</button></div>
  </form>
</section>

<section>
  <h3>Listeners</h3>
  <div class="list" id="listeners"></div>
  <p class="note">What the DJ remembers for each account (Navidrome, Jellyfin or Plex): its last lines and the songs it played in the last
  three days, so a new session, on any device, doesn't repeat them.</p>
</section>
</div>
""" + _SCRIPT


def problem(text, back):
    """What went wrong, with the way back to the page (`back`, its own address, from any route's depth)."""
    return _STYLE + f'<div class="adj"><section><p>{escape(text)}</p><div class="actions"><a class="btn btn-ghost btn-sm" href="{escape(back)}">Back</a></div></section></div>'
