



















import hashlib
import json
import os
import re
import threading
import time

import requests
from flask import current_app, g, jsonify, request

from plugin.api import logger

PREFIX = "/plugins/audity_dj/app/"


_SHAPE = re.compile(r"^[A-Za-z0-9._~+/=-]{1,512}$")

TRUSTED_FOR = 600
KINDS = ("navidrome", "jellyfin", "plex")
NAMES = {"navidrome": "Navidrome", "jellyfin": "Jellyfin", "plex": "Plex"}

UNREACHED = "unreached"


UNNAMED = "unnamed"
_trusted = {}
_lock = threading.Lock()


def install(app):
    """Puts `answer_app` ahead of AudioMuse-AI's sign-in check."""
    waiting = app.before_request_funcs.setdefault(None, [])
    if answer_app not in waiting:
        waiting.insert(0, answer_app)


def answer_app():
    if not request.path.startswith(PREFIX):
        return None
    signed = signed_in()
    if signed == UNREACHED:
        kind = _kind()
        return jsonify(error=f"AudioMuse-AI can't reach your {NAMES[kind]} at the address it has saved. Update it in "
                             f"AudioMuse-AI's settings.", reason="server-unreachable", server=kind), 503
    if signed == UNNAMED:
        return jsonify(error="AudioMuse-AI can't reach plex.tv to see which Plex account this is, the first time this "
                             "device signs in. It will once the internet is back.", reason="plex-account-unnamed",
                       server="plex"), 503
    if signed is None:

        return jsonify(error="Sign in with your music server's account.", reason="sign-in-turned-down"), 401
    if request.routing_exception is not None:
        code = getattr(request.routing_exception, "code", 404)
        return jsonify(error="Not here."), code
    view = current_app.view_functions.get(request.endpoint)
    if view is None:
        return jsonify(error="Not here."), 404
    g.audity_listener, g.audity_admin, g.audity_server = signed

    return current_app.ensure_sync(view)(**(request.view_args or {}))


def listener():
    return g.get("audity_listener")


def server_id():
    """The AudioMuse-AI server the sign-in was checked with: songs are found by sound in its own
    library, by its own IDs, where AudioMuse-AI is connected to more than one."""
    return g.get("audity_server")


def is_admin():
    """Whether the account signed in is an admin of its server: only an admin's phone may start the
    voice's download on the server (4.5 GB of its disk)."""
    return bool(g.get("audity_admin"))


def _kind():
    return request.headers.get("X-Audity-Server", "navidrome").strip().lower()


def signed_in():
    """(username, is admin, AudioMuse-AI's id for the server) for the request's sign-in; None where it's
    wrong, and UNREACHED where none of AudioMuse-AI's servers of its kind answered to check it."""
    kind = _kind()
    username = request.headers.get("X-Audity-User", "").strip()
    token = request.headers.get("X-Audity-Token", "").strip()
    salt = request.headers.get("X-Audity-Salt", "").strip()
    if kind not in KINDS or not token or (kind == "navidrome" and not (username and salt)):
        return None
    if not (_SHAPE.match(token) and (not salt or _SHAPE.match(salt)) and len(username) <= 200
            and username.isprintable()):
        return None
    key = hashlib.sha256(f"{kind}\0{username}\0{token}\0{salt}".encode()).hexdigest()
    now = time.monotonic()
    with _lock:
        kept = _trusted.get(key)
        if kept is not None:
            if kept[0] > now:
                return kept[1]
            _trusted.pop(key, None)
    checked = {"navidrome": _navidrome, "jellyfin": _jellyfin, "plex": _plex}[kind](username, token, salt)

    if checked is None or checked in (UNREACHED, UNNAMED):
        return checked
    with _lock:
        if len(_trusted) > 500:
            _trusted.clear()
        _trusted[key] = (now + TRUSTED_FOR, checked)
    return checked


def _servers(kind):
    """(AudioMuse-AI's id, address) for each server of `kind` it's connected to."""
    from tasks.mediaserver import registry

    found = []
    for server in registry.list_servers():
        url = (server.get("creds") or {}).get("url")
        if server.get("server_type") == kind and url:
            found.append((server.get("server_id"), url.rstrip("/")))
    return found


def _subsonic(answer):
    """The answer's subsonic-response, or {} for one that isn't a Subsonic server's (a page of another
    app now at that address, an error from a proxy in front of it)."""
    try:
        body = answer.json().get("subsonic-response") if answer.ok else None
    except (ValueError, AttributeError):
        return {}
    return body if isinstance(body, dict) else {}


def _navidrome(username, token, salt):
    params = {"u": username, "t": token, "s": salt, "v": "1.16.1", "c": "audity-dj", "f": "json"}
    servers = _servers("navidrome")
    answered = False
    for server, url in servers:
        try:

            body = _subsonic(requests.get(f"{url}/rest/getUser.view", timeout=10, params=dict(params, username=username)))
            if body.get("status") == "ok":
                return username, bool((body.get("user") or {}).get("adminRole")), server

            body = _subsonic(requests.get(f"{url}/rest/ping.view", timeout=10, params=params))
            if body.get("status") == "ok":
                return username, False, server
            if body:
                answered = True
                continue
        except requests.RequestException:
            pass
        logger.warning("Audity DJ: couldn't reach Navidrome at %s to check a sign-in", url)
    return UNREACHED if servers and not answered else None


def _jellyfin(_username, token, _salt):
    headers = {"Authorization": f'MediaBrowser Client="Audity DJ", Device="AudioMuse-AI", DeviceId="audity-dj", '
                                f'Version="1", Token="{token}"', "Accept": "application/json"}
    servers = _servers("jellyfin")
    answered = False
    for server, url in servers:
        try:
            answer = requests.get(f"{url}/Users/Me", timeout=10, headers=headers)

            if answer.status_code in (401, 403):
                answered = True
                continue
            if answer.ok:
                user = answer.json()
                name = str(user.get("Name") or "").strip()
                if name:
                    return name, bool((user.get("Policy") or {}).get("IsAdministrator")), server
        except (requests.RequestException, ValueError, AttributeError):
            pass
        logger.warning("Audity DJ: couldn't reach Jellyfin at %s to check a sign-in", url)
    return UNREACHED if servers and not answered else None



PLEX_TV = os.environ.get("AUDITY_DJ_PLEX_TV", "https://plex.tv").rstrip("/")
_PLEX_HEADERS = {"Accept": "application/json", "X-Plex-Product": "Audity DJ", "X-Plex-Client-Identifier": "audity-dj"}


PLEX_TV_WAIT = 5
PLEX_RENAME_EVERY = 3600
PLEX_KEPT_MOST = 1000
_named = {"loaded": False, "accounts": {}, "asked": {}}
_named_lock = threading.Lock()


def _named_file():
    from plugin.api import config

    return os.path.join(config.PLUGINS_DIR, "audity_dj_files", "plex-accounts.json")


def _named_key(server, token):
    """The sign-in as it's kept: hashed with the server's id, never the token itself."""
    return hashlib.sha256(f"plex\0{server}\0{token}".encode()).hexdigest()


def _kept_name(key):
    with _named_lock:
        if not _named["loaded"]:
            try:
                with open(_named_file()) as file:
                    accounts = json.load(file)
                _named["accounts"] = accounts if isinstance(accounts, dict) else {}
            except (OSError, ValueError):
                _named["accounts"] = {}
            _named["loaded"] = True
        return _named["accounts"].get(key)


def _keep_name(key, account):
    """`account` ({"name", "owner"}) kept for the sign-in `key`, or let go with None; written to the disk at once."""
    _kept_name(key)
    with _named_lock:
        accounts = _named["accounts"]
        if account is None:
            accounts.pop(key, None)
        else:
            accounts[key] = dict(account, at=time.time())
        if len(accounts) > PLEX_KEPT_MOST:
            for old in sorted(accounts, key=lambda each: accounts[each].get("at", 0))[:len(accounts) - PLEX_KEPT_MOST]:
                accounts.pop(old)
        try:
            path = _named_file()
            os.makedirs(os.path.dirname(path), exist_ok=True)
            with open(path + ".new", "w") as file:
                json.dump(accounts, file)
            os.replace(path + ".new", path)
        except OSError:
            logger.exception("Audity DJ: couldn't keep a Plex account's name")


def _plex_account(url, headers):
    """{"name", "owner"} as plex.tv names the token's account (its name as the app shows it, PlexSignIn: username,
    else title) and whether it's the server's owner; False where plex.tv says the token is no account's; None where
    plex.tv couldn't be reached."""
    try:
        answer = requests.get(f"{PLEX_TV}/api/v2/user", timeout=PLEX_TV_WAIT, headers=headers)
        if answer.status_code in (401, 403):
            return False
        user = answer.json() if answer.ok else None
    except (requests.RequestException, ValueError):
        return None
    if not isinstance(user, dict):
        return None
    name = str(user.get("username") or user.get("title") or "").strip()
    if not name:
        return False

    try:
        owner = requests.get(f"{url}/myplex/account", timeout=10, headers=headers)
        owner_name = ((owner.json() or {}).get("MyPlex") or {}).get("username") if owner.ok else None
    except (requests.RequestException, ValueError, AttributeError):
        owner_name = None
    return {"name": name, "owner": bool(owner_name) and owner_name == user.get("username")}


def _rename_soon(url, headers, key):
    """The name kept for `key` asked of plex.tv again, at most every PLEX_RENAME_EVERY, off the request: changed,
    it's kept; plex.tv saying the token is no account's lets it go; plex.tv out of reach changes nothing."""
    now = time.monotonic()
    with _named_lock:
        if now - _named["asked"].get(key, -PLEX_RENAME_EVERY) < PLEX_RENAME_EVERY:
            return
        _named["asked"][key] = now

    def rename():
        account = _plex_account(url, headers)
        kept = _kept_name(key) or {}
        if account is False:
            _keep_name(key, None)
        elif account is not None and account != {"name": kept.get("name"), "owner": kept.get("owner")}:
            _keep_name(key, account)
    threading.Thread(target=rename, name="audity-dj-plex-name", daemon=True).start()


def _plex(_username, token, _salt):
    """The Plex server's own yes makes the token an account of this server, as it opens the server's music; plex.tv
    only names the account. So a name kept from plex.tv's last answer is used as it is, and asked again off the
    request; only a token not named before waits for plex.tv, and with plex.tv out of reach is UNNAMED, not a no."""


    headers = dict(_PLEX_HEADERS, **{"X-Plex-Token": token})
    servers = _servers("plex")
    answered = False
    for server, url in servers:
        try:

            sections = requests.get(f"{url}/library/sections", timeout=10, headers=headers)
        except requests.RequestException:
            logger.warning("Audity DJ: couldn't reach Plex at %s to check a sign-in", url)
            continue
        if sections.status_code in (401, 403):
            answered = True
            continue
        if not sections.ok:
            logger.warning("Audity DJ: couldn't reach Plex at %s to check a sign-in", url)
            continue

        answered = True
        key = _named_key(server, token)
        kept = _kept_name(key)
        if kept is not None:
            _rename_soon(url, headers, key)
            return kept["name"], bool(kept.get("owner")), server
        account = _plex_account(url, headers)
        if account is None:
            logger.warning("Audity DJ: plex.tv couldn't be reached to name a Plex sign-in seen for the first time")
            return UNNAMED
        if account is False:
            continue
        _keep_name(key, account)
        with _named_lock:
            _named["asked"][key] = time.monotonic()
        return account["name"], account["owner"], server
    return UNREACHED if servers and not answered else None
