



import math
import threading
import time


PACES = ((80, "slow"), (105, "easy"), (130, "quick"), (math.inf, "fast"))


MUSICNN_MOODS = ("mellow", "chill", "party", "catchy", "sad", "happy", "instrumental", "acoustic")
CLAP_MOODS = ("danceable", "aggressive", "relaxed")

MOOD_TOP = 0.10
MOOD_OF_HIGHEST = 0.5
SONGS_MOST = 2000
SPREAD_SECONDS = 3600

_spread = {"at": None, "value": None, "busy": False}
_spread_lock = threading.Lock()


def _scores(text):
    """"label:0.530,…" as {label lower-cased: 0.53}."""
    out = {}
    for part in (text or "").split(","):
        label, _, value = part.rpartition(":")
        try:
            out[label.strip().lower()] = float(value)
        except ValueError:
            continue
    return out


def _cut(values, at):
    """The value `at` of the way up `values` (0 to 1), or None for none."""
    if not values:
        return None
    values = sorted(values)
    return values[min(len(values) - 1, max(0, int(round(at * (len(values) - 1)))))]


def _measure(db):
    """The library's spread, from the whole table: energy's and danceable's thirds, each mood's top tenth and
    highest."""
    cur = db.cursor()
    try:
        cur.execute("SELECT energy, mood_vector, other_features FROM score")
        rows = cur.fetchall()
    finally:
        cur.close()
    energies, moods = [], {mood: [] for mood in MUSICNN_MOODS + CLAP_MOODS}
    for energy, mood_vector, other in rows:
        if energy is not None:
            energies.append(float(energy))
        heard = _scores(mood_vector)
        heard.update({label: value for label, value in _scores(other).items() if label in CLAP_MOODS})
        for mood in moods:
            moods[mood].append(heard.get(mood, 0.0))
    return {"songs": len(rows), "energy": (_cut(energies, 1 / 3), _cut(energies, 2 / 3)),
            "moods": {mood: (_cut(values, 1 - MOOD_TOP), max(values) if values else None,
                             _cut(values, 1 / 3), _cut(values, 2 / 3)) for mood, values in moods.items()}}


def _library_spread(get_db):
    """The spread, measured again each hour in the background (the first time while asked)."""
    with _spread_lock:
        stale = _spread["at"] is None or time.monotonic() - _spread["at"] > SPREAD_SECONDS
        first = _spread["value"] is None
        if stale and not first and not _spread["busy"]:
            _spread["busy"] = True
            threading.Thread(target=_measure_again, args=(get_db,), name="audity-dj-facts-spread", daemon=True).start()
    if first:
        value = _measure(get_db())
        with _spread_lock:
            _spread.update(at=time.monotonic(), value=value)
    return _spread["value"]


def _measure_again(get_db):
    try:
        value = _measure(get_db())
        with _spread_lock:
            _spread.update(at=time.monotonic(), value=value)
    except Exception:
        with _spread_lock:
            _spread["at"] = time.monotonic() - SPREAD_SECONDS + 60
    finally:
        _spread["busy"] = False


def _band(value, thirds):
    low, high = thirds
    if value is None or low is None or high is None or low == high:
        return None
    return "low" if value <= low else "high" if value >= high else None


def _pace(bpm, lively):
    """(the pace, sure): slow and fast taken as they are only where the song's energy and danceable bear them out,
    as a beat tracker most often slips to half or double (a loud, danceable 70 is likelier 140)."""
    name = next(name for top, name in PACES if bpm < top)
    if name == "slow":
        return name, not lively
    if name == "fast":
        return name, lively
    return name, True


def songs(ids, get_db):
    """{"<song id>": its facts} for each of `ids` AudioMuse-AI has analyzed (FACTS.md); `get_db` is AudioMuse-AI's
    own database connection."""
    ids = [song for song in dict.fromkeys(ids) if isinstance(song, str) and song][:SONGS_MOST]
    if not ids:
        return {}
    spread = _library_spread(get_db)
    db = get_db()
    cur = db.cursor()
    try:
        cur.execute("SELECT item_id, tempo, key, scale, energy, mood_vector, other_features FROM score "
                    "WHERE item_id = ANY(%s)", (ids,))
        rows = cur.fetchall()
    finally:
        cur.close()
    answer = {}
    for item_id, tempo, key, scale, energy, mood_vector, other in rows:
        heard = _scores(mood_vector)
        clap = {label: value for label, value in _scores(other).items() if label in CLAP_MOODS}
        heard.update(clap)
        energy_band = _band(float(energy) if energy is not None else None, spread["energy"])
        dance = spread["moods"]["danceable"]
        dance_band = _band(clap.get("danceable"), (dance[2], dance[3])) if "danceable" in clap else None
        facts = {}
        if tempo:
            bpm = float(tempo)
            pace, sure = _pace(bpm, energy_band == "high" or dance_band == "high")
            facts.update(bpm=round(bpm, 1), pace=pace, paceSure=sure)
        if key:
            facts["key"] = key
        if scale:
            facts["scale"] = scale
        if energy_band:
            facts["energy"] = energy_band
        moods = []
        for mood in MUSICNN_MOODS + CLAP_MOODS:
            top, highest, _, _ = spread["moods"][mood]
            value = heard.get(mood)
            if value and top is not None and highest and value >= top and value >= MOOD_OF_HIGHEST * highest:
                moods.append(mood)
        facts["moods"] = moods
        answer[item_id] = facts
    return answer
