


import time

from flask import current_app


FEEL_SONGS = 40


def _view(name):
    for view in current_app.view_functions.values():
        if getattr(view, "__name__", "") == name:
            return view
    return None


def _called(name, method="GET", body=None):
    """AudioMuse-AI's own view `name`, asked inside this request as if on its own: (status, its JSON), or
    (None, None) when it has no such view."""
    view = _view(name)
    if view is None:
        return None, None
    with current_app.test_request_context(method=method, json=body):
        answer = current_app.make_response(current_app.ensure_sync(view)())
    try:
        return answer.status_code, answer.get_json(silent=True)
    except Exception:
        return answer.status_code, None


def feel_status():
    """Whether AudioMuse-AI can search by feel here: {"ready": bool, "why": str|None}. CLAP off in its settings, no
    text search in this version, or the library not analyzed with it."""
    try:
        from plugin.api import config
        if getattr(config, "CLAP_ENABLED", True) is False:
            return {"ready": False, "why": "CLAP is off in AudioMuse-AI's settings."}
    except ImportError:
        pass
    if _view("clap_search_api") is None:
        return {"ready": False, "why": "This AudioMuse-AI has no text search (it came in 0.9.0)."}
    status, stats = _called("cache_stats_api")
    if status == 200 and isinstance(stats, dict):
        songs = stats.get("songs") or stats.get("count") or stats.get("total") or stats.get("cached")
        if songs == 0:
            return {"ready": False, "why": "The library hasn't been analyzed with CLAP."}
    return {"ready": True, "why": None}


_warmed = {"at": 0.0}


def warm():
    """The text search's model loaded ahead (it unloads after 10 minutes idle), at most every 5 minutes, so a
    request for a feel doesn't wait for it."""
    if time.monotonic() - _warmed["at"] < 300 or _view("warmup_model_api") is None:
        return
    _warmed["at"] = time.monotonic()
    try:
        _called("warmup_model_api", "POST", {})
    except Exception:
        _warmed["at"] = 0.0


def search(text, limit=FEEL_SONGS):
    """AudioMuse-AI's text search's songs for `text`, best first, as it gives them ([{"item_id", "title", "author",
    "album", "similarity"}], None), or ([], why). The engine keeps those of the account's library (library.feel_songs)."""
    status, answer = _called("clap_search_api", "POST", {"query": text, "limit": max(limit * 3, 60)})
    if status is None:
        return [], "This AudioMuse-AI has no text search."
    if status == 503 or (isinstance(answer, dict) and "not loaded" in str(answer.get("error", "")).lower()):
        return [], "warming"
    if status != 200 or not isinstance(answer, dict):
        return [], (answer or {}).get("error") if isinstance(answer, dict) else f"AudioMuse-AI's text search answered {status}."
    return [result for result in answer.get("results") or [] if isinstance(result, dict)], None
