











import json
import math

from plugin.api import get_db, table


LINES_KEPT = 30



SAID_KEPT = 200_000
SONG_DAYS = 3
SONGS_KEPT = 3000


HISTORY_PAGE = 50_000


SAID_KEY_MOST = 600
RECORDING_MOST = 600


def migrate(db=None):
    db = db or get_db()
    cur = db.cursor()
    cur.execute(
        "CREATE TABLE IF NOT EXISTS " + table("listeners") + " ("
        " username TEXT PRIMARY KEY,"
        " voice TEXT,"
        " lines JSONB NOT NULL DEFAULT '[]'::jsonb,"
        " songs JSONB NOT NULL DEFAULT '{}'::jsonb,"
        " updated_at TIMESTAMP NOT NULL DEFAULT now())"
    )
    cur.execute(
        "CREATE TABLE IF NOT EXISTS " + table("said") + " ("
        " username TEXT NOT NULL,"
        " sentence TEXT NOT NULL,"
        " said_at DOUBLE PRECISION NOT NULL,"
        " PRIMARY KEY (username, sentence))"
    )



    cur.execute(
        "CREATE TABLE IF NOT EXISTS " + table("heard") + " ("
        " username TEXT NOT NULL,"
        " heard_at DOUBLE PRECISION NOT NULL,"
        " recording TEXT NOT NULL,"
        " device TEXT,"
        " skipped BOOLEAN,"
        " PRIMARY KEY (username, heard_at, recording))"
    )


    cur.execute(
        "CREATE TABLE IF NOT EXISTS " + table("ideas") + " ("
        " username TEXT NOT NULL,"
        " started_at DOUBLE PRECISION NOT NULL,"
        " idea TEXT NOT NULL,"
        " picked_by TEXT,"
        " device TEXT,"
        " PRIMARY KEY (username, started_at, idea))"
    )
    db.commit()
    cur.close()


def _key(username):
    return (username or "").strip().lower()


def _row(cur, username):
    cur.execute("SELECT voice, lines, songs FROM " + table("listeners") + " WHERE username = %s", (_key(username),))
    row = cur.fetchone()
    if row is None:
        return None, [], {}
    voice, lines, songs = row
    if isinstance(lines, str):
        lines = json.loads(lines)
    if isinstance(songs, str):
        songs = json.loads(songs)
    return voice, list(lines or []), dict(songs or {})


def memory(username):
    db = get_db()
    cur = db.cursor()
    try:
        voice, lines, songs = _row(cur, username)
    finally:
        cur.close()
    return {"voice": voice, "lines": lines, "songs": songs}


def remember(username, lines=(), songs=None, now=None):
    """Adds what a device said and played, and returns the whole memory. Each song's time is the
    latest any device played it; anything older than three days goes."""
    import time

    now = now or time.time()
    db = get_db()
    cur = db.cursor()
    try:

        cur.execute("INSERT INTO " + table("listeners") + " (username) VALUES (%s) ON CONFLICT DO NOTHING",
                    (_key(username),))
        cur.execute("SELECT 1 FROM " + table("listeners") + " WHERE username = %s FOR UPDATE", (_key(username),))
        voice, kept_lines, kept_songs = _row(cur, username)


        for line in lines or ():
            line = str(line).strip()[:600]
            if line and line not in kept_lines:
                kept_lines.append(line)
        kept_lines = kept_lines[-LINES_KEPT:]
        for recording, when in (songs or {}).items():
            try:
                when = float(when)
            except (TypeError, ValueError):
                continue
            recording = str(recording)[:300]
            if when > kept_songs.get(recording, 0):
                kept_songs[recording] = min(when, now + 60)
        since = now - SONG_DAYS * 86_400
        kept_songs = {key: value for key, value in kept_songs.items() if value >= since}
        if len(kept_songs) > SONGS_KEPT:
            kept_songs = dict(sorted(kept_songs.items(), key=lambda item: item[1], reverse=True)[:SONGS_KEPT])
        cur.execute("UPDATE " + table("listeners") + " SET lines = %s::jsonb, songs = %s::jsonb, updated_at = now()"
                    " WHERE username = %s", (json.dumps(kept_lines), json.dumps(kept_songs), _key(username)))
        db.commit()
    except Exception:
        db.rollback()
        raise
    finally:
        cur.close()
    return {"voice": voice, "lines": kept_lines, "songs": kept_songs}


def remember_said(username, said, now=None):
    """Sentences an account heard, [(key, unix seconds)], each kept at the latest time any device sent; returns how
    many the account has. Past SAID_KEPT, the ones said longest ago go."""
    import time

    now = now or time.time()
    rows = []
    for key, when in said:
        try:
            when = min(float(when), now + 60)
        except (TypeError, ValueError):
            continue
        key = str(key).strip()[:SAID_KEY_MOST]
        if key:
            rows.append((_key(username), key, when))
    db = get_db()
    cur = db.cursor()
    try:
        if rows:

            cur.executemany("INSERT INTO " + table("said") + " AS kept (username, sentence, said_at) VALUES (%s, %s, %s)"
                            " ON CONFLICT (username, sentence) DO UPDATE SET said_at = GREATEST(kept.said_at, EXCLUDED.said_at)",
                            rows)
        cur.execute("SELECT count(*) FROM " + table("said") + " WHERE username = %s", (_key(username),))
        count = cur.fetchone()[0]
        if count > SAID_KEPT:
            cur.execute("DELETE FROM " + table("said") + " WHERE username = %s AND sentence IN (SELECT sentence FROM "
                        + table("said") + " WHERE username = %s ORDER BY said_at ASC LIMIT %s)",
                        (_key(username), _key(username), count - SAID_KEPT))
            count = SAID_KEPT
        db.commit()
    except Exception:
        db.rollback()
        raise
    finally:
        cur.close()
    return count


def said_since(username, since=None):
    """{sentence: unix seconds} an account heard after `since` (all of them without it)."""
    db = get_db()
    cur = db.cursor()
    try:
        if since is None:
            cur.execute("SELECT sentence, said_at FROM " + table("said") + " WHERE username = %s", (_key(username),))
        else:
            cur.execute("SELECT sentence, said_at FROM " + table("said") + " WHERE username = %s AND said_at > %s",
                        (_key(username), float(since)))
        return {row[0]: row[1] for row in cur.fetchall()}
    finally:
        cur.close()


def said_counts():
    """How many sentences each account has heard, for the page."""
    db = get_db()
    cur = db.cursor()
    try:
        cur.execute("SELECT username, count(*) FROM " + table("said") + " GROUP BY username")
        return dict(cur.fetchall())
    finally:
        cur.close()





def _when(value, now):
    """Unix seconds as sent, or None: a time to come is the present (a phone's clock ahead), as in `remember_said`."""
    try:
        value = float(value)
    except (TypeError, ValueError):
        return None
    return min(value, now + 60) if math.isfinite(value) and value > 0 else None


def _known(**values):
    return {name: value for name, value in values.items() if value is not None and value != ""}


def _text(value, most):
    value = " ".join(str(value).split())[:most] if value is not None else ""
    return value or None


def remember_history(username, heard=(), ideas=(), now=None):
    """Songs the DJ played, [{"recording", "at", "device", "skipped"}], and sets' ideas, [{"idea", "at", "by",
    "device"}], each kept once: sent again (a device sends what it has as a session starts), a song's skipped and
    device are filled in where they weren't, and nothing else changes. Returns how many of each the account has."""
    import time

    now = now or time.time()
    account = _key(username)
    plays, sets = [], []
    for item in heard or ():
        at, recording = _when(item.get("at"), now), _text(item.get("recording"), RECORDING_MOST)
        skipped = item.get("skipped")
        if at is not None and recording:
            plays.append((account, at, recording, _text(item.get("device"), 100),
                          skipped if isinstance(skipped, bool) else None))
    for item in ideas or ():
        at, idea = _when(item.get("at"), now), _text(item.get("idea"), 200)
        if at is not None and idea:
            sets.append((account, at, idea, _text(item.get("by"), 20), _text(item.get("device"), 100)))
    db = get_db()
    cur = db.cursor()
    try:
        if plays:
            cur.executemany("INSERT INTO " + table("heard") + " AS kept (username, heard_at, recording, device, skipped)"
                            " VALUES (%s, %s, %s, %s, %s) ON CONFLICT (username, heard_at, recording) DO UPDATE SET"
                            " skipped = COALESCE(EXCLUDED.skipped, kept.skipped), device = COALESCE(kept.device, EXCLUDED.device)",
                            plays)
        if sets:
            cur.executemany("INSERT INTO " + table("ideas") + " AS kept (username, started_at, idea, picked_by, device)"
                            " VALUES (%s, %s, %s, %s, %s) ON CONFLICT (username, started_at, idea) DO UPDATE SET"
                            " picked_by = COALESCE(kept.picked_by, EXCLUDED.picked_by),"
                            " device = COALESCE(kept.device, EXCLUDED.device)",
                            sets)
        cur.execute("SELECT (SELECT count(*) FROM " + table("heard") + " WHERE username = %s),"
                    " (SELECT count(*) FROM " + table("ideas") + " WHERE username = %s)", (account, account))
        counts = cur.fetchone()
        db.commit()
    except Exception:
        db.rollback()
        raise
    finally:
        cur.close()
    return {"heard": counts[0], "ideas": counts[1]}


def history_since(username, since=0.0, most=None):
    """The account's songs the DJ played and ideas after `since` (unix seconds), oldest first: {"heard": [...],
    "ideas": [...], "next": seconds or None}. Past `most` of either (HISTORY_PAGE), both end at the same time and
    "next" is the `since` to read on from."""
    most = most or HISTORY_PAGE
    account = _key(username)
    db = get_db()
    cur = db.cursor()
    try:
        cur.execute("SELECT heard_at, recording, device, skipped FROM " + table("heard")
                    + " WHERE username = %s AND heard_at > %s ORDER BY heard_at, recording LIMIT %s",
                    (account, float(since), most + 1))
        plays = cur.fetchall()
        cur.execute("SELECT started_at, idea, picked_by, device FROM " + table("ideas")
                    + " WHERE username = %s AND started_at > %s ORDER BY started_at, idea LIMIT %s",
                    (account, float(since), most + 1))
        sets = cur.fetchall()
    finally:
        cur.close()


    ends = [rows[most][0] for rows in (plays, sets) if len(rows) > most]
    until = min(ends) if ends else None
    if until is not None:
        plays = [row for row in plays if row[0] < until]
        sets = [row for row in sets if row[0] < until]

    heard = [_known(recording=recording, at=at, device=device, skipped=skipped) for at, recording, device, skipped in plays]
    ideas = [_known(idea=idea, at=at, by=by, device=device) for at, idea, by, device in sets]
    last = max([row[0] for row in plays] + [row[0] for row in sets], default=float(since))
    return {"heard": heard, "ideas": ideas, "next": last if until is not None else None}


def history_counts():
    """How many songs the DJ played to each account, for the page."""
    db = get_db()
    cur = db.cursor()
    try:
        cur.execute("SELECT username, count(*) FROM " + table("heard") + " GROUP BY username")
        return dict(cur.fetchall())
    finally:
        cur.close()


def set_voice(username, voice_id):
    db = get_db()
    cur = db.cursor()
    try:
        cur.execute("INSERT INTO " + table("listeners") + " (username, voice) VALUES (%s, %s)"
                    " ON CONFLICT (username) DO UPDATE SET voice = EXCLUDED.voice, updated_at = now()",
                    (_key(username), voice_id))
        db.commit()
    except Exception:
        db.rollback()
        raise
    finally:
        cur.close()


def listeners():
    db = get_db()
    cur = db.cursor()
    try:
        cur.execute("SELECT username, voice, jsonb_array_length(lines), updated_at FROM " + table("listeners")
                    + " ORDER BY updated_at DESC")
        return [{"username": row[0], "voice": row[1], "lines": row[2], "updated": row[3]} for row in cur.fetchall()]
    finally:
        cur.close()
