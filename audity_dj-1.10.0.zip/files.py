


import os

from plugin.api import config


def folder(*parts):
    return os.path.join(config.PLUGINS_DIR, "audity_dj_files", *parts)


def clean_env():
    """The environment a program of the DJ's own is started in: the image's PYTHONPATH (AudioMuse-AI's packages) left
    out for the voice's own Python."""
    env = {key: value for key, value in os.environ.items() if key not in ("PYTHONPATH", "PYTHONHOME")}
    env["HF_HOME"] = folder("hf")
    env["PIP_DISABLE_PIP_VERSION_CHECK"] = "1"
    return env


def _size(path):
    total = 0
    for root, _, names in os.walk(path):
        for name in names:
            path = os.path.join(root, name)

            if os.path.islink(path):
                continue
            try:
                total += os.path.getsize(path)
            except OSError:
                pass
    return total


_measured = {}


def kept_size(path, state_file):
    """`_size(path)`, measured again only once `state_file` has changed, as a download or a removal writes it: measuring
    walks every file, and the plugin's page asks for the sizes every 3 s. Keyed by the file's time, so every process of
    AudioMuse-AI's sees the change."""
    try:
        stamp = os.stat(state_file).st_mtime_ns
    except OSError:
        stamp = None
    kept = _measured.get(path)
    if kept is None or kept[0] != stamp:
        kept = (stamp, _size(path))
        _measured[path] = kept
    return kept[1]
