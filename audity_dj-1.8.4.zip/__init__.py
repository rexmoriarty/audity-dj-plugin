













import gzip
import json
import os
import threading
import time
from datetime import datetime

from flask import Blueprint, Response, current_app, g, jsonify, make_response, redirect, request, url_for
from werkzeug.datastructures import ImmutableMultiDict

from plugin.api import config, logger, render_page

from . import asking, bank, bank_setup, gate, install, neutts_setup, page, store, voicebox, voices

VERSION = "1.8.4"
bp = Blueprint("audity_dj", __name__)


@bp.before_request
def _admins_only():
    """Everything here but the app's own routes (gate.py answers those, signed in with the music
    server) is the server owner's: the voice's download, the voices, who uses the DJ. AudioMuse-AI
    keeps only a plugin's settings page to its admins and opens the rest of a plugin's pages to anyone
    signed in to it, so the rest is kept to its admins here."""
    if request.path.startswith(gate.PREFIX):
        return None
    if not getattr(config, "AUTH_ENABLED", True) or g.get("auth_role") == "admin":
        return None
    return jsonify(error="Only an AudioMuse-AI admin can do this."), 403
box = voicebox.box


def _listener():
    return gate.listener()


def _picked(listener):
    """Theo: the bank is the only voice, and it's his (voicebox.engine)."""
    return voices.DEFAULT




@bp.route("/app/hello")
def app_hello():
    listener = _listener()
    box.keep_on()
    return jsonify({
        "plugin": "audity_dj",
        "version": VERSION,
        "voice": _voice_status(),
        "voices": [voices.public(voice) for voice in _offered(listener)],
        "picked": _picked(listener),
        "session": box.status(),

        "canDownload": gate.is_admin(),
        "diskGB": bank_setup.DISK_GB,


        "bank": {"pack": bank_setup.pack_id(), "clips": len(bank_setup.pack().get("clips", []))}
                if voicebox.engine() == "bank" else None,


        "asks": _asks(listener),

        "said": {"version": 1},
    })


_feel = {"at": 0.0, "status": None}


def _asks(listener):
    if time.monotonic() - _feel["at"] > 60 or _feel["status"] is None:
        try:
            _feel["status"] = asking.feel_status()
        except Exception as error:
            _feel["status"] = {"ready": False, "why": f"{type(error).__name__}: {error}"}
        _feel["at"] = time.monotonic()
    kept = asking.library(gate.server_id() or "", listener)
    return {"version": 1, "library": {"version": kept.version, "songs": len(kept.songs)} if kept else None,
            "feel": _feel["status"]}


def _offered(listener):
    """The voices the app lists: Theo alone, the bank being the only voice, ~~else all of this account's~~."""
    return [voices.find(voices.DEFAULT)]


def _voice_status():
    """The DJ's voice as the app sees it: Theo's bank, ready once it's downloaded, else its download's state.
    ~~NeuTTS Air or Ming, downloaded before, kept the DJ talking while the bank came down.~~"""
    state = bank_setup.status()
    if bank_setup.is_ready():
        state = dict(state, state="ready")
    return {"state": state.get("state"), "step": state.get("step"),
            "fraction": state.get("fraction", 0.0), "error": state.get("error")}


@bp.route("/app/voice", methods=["POST"])
def app_voice():
    listener = _listener()
    voice_id = (request.get_json(silent=True) or {}).get("id", "")
    if voices.find(voice_id, listener) is None:
        return jsonify(error="No such voice."), 404

    store.set_voice(listener, voice_id)
    return jsonify(picked=_picked(listener))


@bp.route("/app/voice/download", methods=["POST"])
def app_download():
    """The voice's download started (or stopped) from the app's DJ page, by an admin of the server, so
    there's nothing to do on this page at all once the plugin's installed."""
    if not gate.is_admin():
        return jsonify(error="Only an admin of your music server can download the DJ's voice."), 403
    if (request.get_json(silent=True) or {}).get("action") == "stop":
        bank_setup.stop()
    elif not bank_setup.is_ready():
        bank_setup.start()
    return jsonify(voice=_voice_status())


@bp.route("/app/session/hold", methods=["POST"])
def app_hold():
    try:
        box.hold(_listener())
    except voicebox.VoiceNotReady:
        return jsonify(error="The DJ's voice isn't downloaded on the server yet.", voice=_voice_status()), 409
    _warm_feel()
    return jsonify(box.status())


def _warm_feel():
    """AudioMuse-AI's text search kept loaded while a DJ session is on (`asking.warm`), off this request."""
    app = current_app._get_current_object()

    def warm():
        with app.app_context():
            asking.warm()
    threading.Thread(target=warm, name="audity-dj-warm-feel", daemon=True).start()




@bp.route("/app/library", methods=["POST"])
def app_library():
    """The account's song list, as the app's reader read it: {"version", "songs": [{"id", "title", "artist",
    "artistId", "album", "albumId", "genre", "genres", "moods", "year", "albumYear"}]}, gzip'd or not, in the app's
    order. Kept on the disk until the next."""
    body = request.get_data(cache=False)
    gzipped = request.headers.get("Content-Encoding", "").lower() == "gzip" or body[:2] == b"\x1f\x8b"
    try:
        version, count = asking.keep_library(gate.server_id() or "", _listener(), body, gzipped)
    except (ValueError, OSError, EOFError) as error:
        return jsonify(error=str(error) or "Not a library."), 400
    return jsonify(version=version, songs=count)


@bp.route("/app/names", methods=["POST"])
def app_names():
    """The next songs' name sentences, as the app will ask for them in its lines ({"say": [sentence]}): what of each
    the bank hasn't is said by Pocket TTS while no line waits, and kept, so their lines are made at once."""
    sentences = (request.get_json(silent=True) or {}).get("say")
    if not isinstance(sentences, list) or not all(isinstance(text, str) and 0 < len(text) <= 300 for text in sentences):
        return jsonify(error="say is a list of sentences, each 1 to 300 characters."), 400
    if voicebox.engine() != "bank":
        return jsonify(queued=0, why="Theo's bank isn't this server's voice.")
    texts = []
    for sentence in sentences[:box.AHEAD_MOST]:
        try:
            texts += [piece["say"] for piece in bank.pieces(sentence, bank_setup.pack_dir()) if "say" in piece]
        except (OSError, ValueError):
            continue
    return jsonify(queued=box.ahead(texts))


@bp.route("/app/ask", methods=["POST"])
def app_request():
    """A request, read: {"text", "alternatives", "playing" (the song's id), "now" (the phone's time with its offset)}
    answered {"request" (HostRequest's fields, or null), "heard", "feelSongs", "feelWhy", "took", "library"}. 409
    when the account's library hasn't been sent."""
    began = time.monotonic()
    asked = request.get_json(silent=True) or {}
    text = asked.get("text")
    if not isinstance(text, str) or not text.strip() or len(text) > 500:
        return jsonify(error="text is the words heard, 1 to 500 characters."), 400
    heard = [text] + [other for other in (asked.get("alternatives") or []) if isinstance(other, str) and other.strip()][:4]
    kept = asking.library(gate.server_id() or "", _listener())
    if kept is None:
        return jsonify(error="Send the library first (/app/library).", needsLibrary=True), 409
    now = None
    try:
        now = datetime.fromisoformat(str(asked.get("now"))) if asked.get("now") else None
    except ValueError:
        pass
    playing = asked.get("playing")
    answer = asking.ask(heard, kept, playing=str(playing) if playing else None, now=now)
    answer.update(took=round(time.monotonic() - began, 3), library=kept.version)
    logger.info("Audity DJ: a request read in %.2f s: %r as %s%s", answer["took"], answer["heard"],
                "nothing" if answer["request"] is None else ", ".join(key for key, value in answer["request"].items()
                                                                       if value and key not in ("without", "reply")) or "a feel",
                f", {len(answer['feelSongs'])} songs by feel" if answer["feelSongs"] else "")
    return jsonify(answer)


@bp.route("/app/session/release", methods=["POST"])
def app_release():
    box.release(_listener())
    return jsonify(ok=True)


@bp.route("/app/lines", methods=["POST"])
def app_ask():
    listener = _listener()
    asked = request.get_json(silent=True) or {}
    text = " ".join(str(asked.get("text", "")).split())
    if not text or len(text) > 600:
        return jsonify(error="A line of 1 to 600 characters."), 400
    voice_id = asked.get("voice") or _picked(listener)
    try:



        job_id = box.ask(listener, text, voice_id, asked.get("takes", 1), later=bool(asked.get("later")),
                         full_band=bool(asked.get("fullBand")), now=bool(asked.get("now")))
    except voicebox.VoiceNotReady:
        return jsonify(error="The DJ's voice isn't downloaded on the server yet."), 409
    job = box.line(job_id)
    if asked.get("atOnce") and job is not None and job.state == "done":



        return _line_answer(job)
    return jsonify(id=job_id), 202


@bp.route("/app/lines/<job_id>", methods=["GET", "DELETE"])
def app_line(job_id):
    job = box.line(job_id)
    if job is None or job.listener != _listener():
        return jsonify(error="No such line."), 404
    if request.method == "DELETE":
        box.cancel(job_id)
        return jsonify(ok=True)
    if job.state in ("waiting", "making"):

        try:
            box.hold(job.listener)
        except voicebox.VoiceNotReady:
            pass


        wait = request.args.get("wait", type=float)
        if wait:
            job.finished.wait(min(max(wait, 0), WAIT_LONGEST))
    return _line_answer(job)


WAIT_LONGEST = 8.0


def _line_answer(job):
    if job.state == "done":

        job.summary.setdefault("fetched", round(time.monotonic() - job.made, 1))
        answer = Response(job.wav_for_app(), mimetype="audio/wav")
        answer.headers["X-Audity-Line"] = json.dumps(job.info)
        return answer
    if job.state in ("failed", "cancelled"):
        return jsonify(state=job.state, error=job.error), 500 if job.state == "failed" else 410
    return jsonify(state=job.state, ahead=box.ahead_of(job), session=box.status()), 202


def _json(answer, etag=None):
    """`answer` as JSON, gzip'd for an app that takes it (URLSession does): release 2's bank and an account's sentences
    heard run to megabytes. `answer` may be bytes of JSON already."""
    body = answer if isinstance(answer, bytes) else json.dumps(answer, ensure_ascii=False, separators=(",", ":")).encode()
    zipped = "gzip" in request.headers.get("Accept-Encoding", "").lower() and len(body) > 1024
    response = make_response(gzip.compress(body, 6) if zipped else body)
    response.mimetype = "application/json"
    response.headers["Vary"] = "Accept-Encoding"
    if zipped:
        response.headers["Content-Encoding"] = "gzip"
    if etag:
        response.set_etag(etag + ("-gz" if zipped else ""))
    return response


_bank_built = {"key": None, "body": b"", "zipped": b""}


@bp.route("/app/bank")
def app_bank():
    """The bank in use, sentence by sentence, for an app that writes its lines with them: sent back with
    its exact words, each is its clip at once, and only the name sentence beside it is said by Pocket
    TTS. A new bank comes with no change to the app. Its ETag is the bank's, so an app that has it gets
    a 304. Built once for each bank and kept, gzip'd too (release 2's 99,000 sentences come to about 15 MB)."""
    if voicebox.engine() != "bank":
        return jsonify(error="Theo's bank isn't this server's voice."), 404
    pack = bank_setup.pack()
    key = f"{pack.get('id')}-{len(pack.get('clips', []))}"
    if _bank_built["key"] != key:
        body = json.dumps({"pack": pack.get("id"), "voice": pack.get("voice"),


                           "sentences": [{part: value for part, value in clip.items() if part not in ("file", "path")}
                                         for clip in pack.get("clips", [])]},
                          ensure_ascii=False, separators=(",", ":")).encode()
        _bank_built.update(key=key, body=body, zipped=gzip.compress(body, 6))
    zipped = "gzip" in request.headers.get("Accept-Encoding", "").lower()
    response = make_response(_bank_built["zipped"] if zipped else _bank_built["body"])
    response.mimetype = "application/json"
    response.headers["Vary"] = "Accept-Encoding"
    if zipped:
        response.headers["Content-Encoding"] = "gzip"
    response.set_etag(key + ("-gz" if zipped else ""))
    return response.make_conditional(request)


@bp.route("/app/said", methods=["GET", "POST"])
def app_said():
    """Every sentence this account heard (store.remember_said): POST {"said": [{"key", "at"}]} adds them (2,000 a call
    at most), GET ?since=<unix seconds> gives {"said": {key: at}, "count", "now"} heard after `since`, all of them
    without it."""
    listener = _listener()
    if request.method == "POST":
        said = (request.get_json(silent=True) or {}).get("said")
        if not isinstance(said, list) or len(said) > 2000 or not all(isinstance(item, dict) for item in said):
            return jsonify(error="said is a list of up to 2,000 {key, at}."), 400
        count = store.remember_said(listener, [(item.get("key"), item.get("at")) for item in said])
        return jsonify(kept=len(said), count=count)
    since = request.args.get("since")
    try:
        since = float(since) if since not in (None, "") else None
    except ValueError:
        return jsonify(error="since is unix seconds."), 400
    now = time.time()
    said = store.said_since(listener, since)
    return _json({"said": said, "count": len(said) if since is None else None, "now": now})


@bp.route("/app/memory", methods=["GET", "POST"])
def app_memory():
    listener = _listener()
    if request.method == "GET":
        return jsonify(store.memory(listener))
    asked = request.get_json(silent=True) or {}
    lines = asked.get("lines") or []
    songs = asked.get("songs") or {}
    if not isinstance(lines, list) or not isinstance(songs, dict):
        return jsonify(error="lines is a list, songs a dictionary."), 400
    return jsonify(store.remember(listener, lines[-60:], dict(list(songs.items())[-3000:])))






def _audiomuse_view(name):
    for view in current_app.view_functions.values():
        if getattr(view, "__name__", "") == name:
            return view
    return None


@bp.route("/app/similar")
def app_similar():
    view = _audiomuse_view("get_similar_tracks_endpoint")
    if view is None:
        return jsonify(error="This AudioMuse-AI can't find songs by sound."), 501
    _for_this_server(("item_id", "n", "eliminate_duplicates"), most=SIMILAR_MOST)
    return current_app.ensure_sync(view)()





SIMILAR_MOST = 100


def _for_this_server(allowed, most=None):
    """AudioMuse-AI's own answer asked of the server the app signed in to, by its IDs, rather than
    its default one, where it's connected to more than one, and never of another: `server` is always
    the sign-in's. Only the arguments the app sends (`allowed`) go through, with `n` at most `most`."""
    args = {key: request.args.getlist(key)[:1] for key in allowed if request.args.get(key) is not None}
    if most is not None and "n" in args:
        try:
            args["n"] = [str(max(1, min(int(args["n"][0]), most)))]
        except ValueError:
            args.pop("n")
    server = gate.server_id()
    if server:
        args["server"] = [server]
    request.args = ImmutableMultiDict(args)


@bp.route("/app/path")
def app_path():
    view = _audiomuse_view("find_path_endpoint")
    if view is None:
        return jsonify(error="This AudioMuse-AI can't find paths between songs."), 501
    _for_this_server(("start_song_id", "end_song_id", "max_steps"))
    return current_app.ensure_sync(view)()


@bp.route("/app/voices/<voice_id>/clip")
def app_clip(voice_id):
    return _clip(voices.find(voice_id, _listener()))


def _clip(voice):
    if voice is None:
        return jsonify(error="No such voice."), 404


    path = None
    if voicebox.engine() == "bank" and voice["id"] == voices.DEFAULT:
        path = os.path.join(bank_setup.pack_dir(), bank_setup.pack().get("pocket", {}).get("prompt", "pocket-prompt.wav"))
        path = path if os.path.isfile(path) else None
    path = path or voices.clip_path(voice, voices.clips_of(voice, voicebox.engine() or "neutts")[0])
    with open(path, "rb") as file:
        data = file.read()
    return Response(data, mimetype="audio/flac" if path.endswith(".flac") else "audio/wav")




@bp.route("/")
def home():
    return render_page(page.html(VERSION), title="Audity DJ")


def _log_tail(name, lines=20):
    try:
        with open(install.folder(name), errors="replace") as file:
            return file.read()[-6000:].splitlines()[-lines:]
    except OSError:
        return []


@bp.route("/status.json")
def status_json():
    box.keep_on()
    fast = bank_setup.status()
    using = voicebox.engine()
    return jsonify({
        "voice": {"state": fast.get("state"), "step": fast.get("step"), "fraction": fast.get("fraction", 0.0),
                  "error": fast.get("error"), "needsToken": bool(fast.get("needsToken")),
                  "ready": bank_setup.is_ready(), "newer": bool(fast.get("newer")),
                  "pack": bank_setup.pack().get("id"), "clips": len(bank_setup.pack().get("clips", [])),
                  "diskBytes": bank_setup.disk_bytes() if bank_setup.is_ready() else 0,
                  "diskGB": bank_setup.DISK_GB, "engine": using},

        "session": box.status(),

        "recent": list(reversed(list(box.recent))),
        "voiceLog": _log_tail("voice.log"),
        "voiceLogBefore": _log_tail("voice.log.1", 8),
        "listeners": [dict(row, updated=row["updated"].isoformat() if row["updated"] else None)
                      for row in store.listeners()],
    })


@bp.route("/download", methods=["POST"])
def download():
    action = request.form.get("action", "start")
    if action == "start":

        bank_setup.start(request.form.get("token"))
    elif action == "stop":
        bank_setup.stop()
    elif action == "remove":
        for listener in box.status()["listeners"]:
            box.release(listener)
        bank_setup.remove()
    return redirect(url_for("audity_dj.home"))







@bp.route("/try", methods=["POST"])
def try_line():
    asked = request.get_json(silent=True) or {}
    text = " ".join(str(asked.get("text", "")).split())[:600]
    if not text:
        return jsonify(error="Type a line."), 400
    voice_id = voices.DEFAULT
    try:

        job_id = box.ask("this page", text, voice_id, 1, full_band=True, any_voice=True)
    except voicebox.VoiceNotReady:
        return jsonify(error="Download the voice first."), 409
    return jsonify(id=job_id), 202


@bp.route("/try/<job_id>")
def try_result(job_id):
    job = box.line(job_id)
    if job is None or job.listener != "this page":
        return jsonify(error="No such line."), 404
    if job.state in ("waiting", "making"):
        box.hold("this page")
    elif job.state == "done" and request.args.get("done") == "1":
        box.release("this page")
    return _line_answer(job)


def _clear_earlier():
    """The voices before the bank, NeuTTS Air (3.4 GB) and Ming (4.5 GB), their packages and weights, gone once the
    bank is in: nothing says a line in them now (voicebox.engine). Voices added by hand stay on the disk, unused."""
    if not bank_setup.is_ready():
        return
    for name, setup in (("NeuTTS Air", neutts_setup), ("Ming", install)):
        try:
            if setup.status().get("state") != "none":
                freed = setup.disk_bytes()
                setup.remove()
                logger.info("Audity DJ: %s, a voice from before the bank, removed (%.1f GB)", name, freed / 1e9)
        except Exception:
            logger.exception("Audity DJ: %s couldn't be removed", name)


def _on_start():
    store.migrate()
    gate.install(current_app._get_current_object())

    box.keep_on()
    threading.Thread(target=_clear_earlier, name="audity-dj-clear-earlier", daemon=True).start()
    logger.info("Audity DJ %s is ready for the app at /plugins/audity_dj/app/", VERSION)


def register(ctx):
    ctx.add_blueprint(bp)
    ctx.add_menu_item("Audity DJ", "audity_dj.home", admin_only=True)
    ctx.set_settings_page("audity_dj.home")
    ctx.on_install(store.migrate)
    ctx.on_flask_start(_on_start)
