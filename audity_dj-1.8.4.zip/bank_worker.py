


























import argparse
import collections
import hashlib
import json
import os
import re
import threading
import time
import zlib
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

parser = argparse.ArgumentParser()
parser.add_argument("--port", type=int, required=True)
parser.add_argument("--model", required=True, help="Pocket TTS's English weights (safetensors)")
parser.add_argument("--tokenizer", required=True, help="its tokenizer.json")
parser.add_argument("--decoder", help="the codec's decoder retrained on the bank (safetensors); none keeps Pocket TTS's own")
parser.add_argument("--prompt", required=True, help="the bank's takes Pocket TTS copies Theo from")
parser.add_argument("--cache", required=True, help="a folder for the voice's state, worked out once")
parser.add_argument("--steps", type=int, default=4)
parser.add_argument("--temperature", type=float, default=0.3)
parser.add_argument("--lufs", type=float, help="how loud the pack's clips sound (their median, make_nas_pack.py): "
                    "a line of names alone is made as loud")
parser.add_argument("--louder", type=float, default=0.0,
                    help="dB the pack's clips are above the usual level (make_pack.py --louder), names made to match")
parser.add_argument("--threads", type=int, default=0, help="torch's threads; 0 keeps Pocket TTS's own, 1")
parser.add_argument("--idle", type=float, default=90, help="seconds without a word from the plugin before it stops")
args = parser.parse_args()

import numpy as np
import soundfile
from scipy.signal import butter, lfilter, resample_poly, sosfilt

RATE = 48_000
POCKET_RATE = 24_000



PAUSE = 0.34
EDGE = 0.05



LOUDNESS = 10 ** ((-20 + args.louder) / 20)
CEILING = 10 ** (-1.5 / 20)


_HIGH_PASS = butter(2, 80, btype="highpass", fs=RATE, output="sos")

state = {"loaded": False, "error": None, "heard_from": time.monotonic(), "threads": None}
loaded = threading.Event()
speaking = threading.Lock()
model = {"tts": None, "voice": None, "init_states": None, "torch": None}
_said = collections.OrderedDict()
_said_lock = threading.Lock()





def _config():
    """Pocket TTS's own English config, its weights and tokenizer read from this server's disk instead
    of Hugging Face (where the weights that copy a voice are gated)."""
    import pocket_tts

    with open(os.path.join(os.path.dirname(pocket_tts.__file__), "config", "english.yaml"), encoding="utf-8") as file:
        text = file.read()
    text = re.sub(r"(?m)^weights_path:.*$", "weights_path: " + json.dumps(args.model), text)
    text = re.sub(r"(?m)^weights_path_without_voice_cloning:.*$", "", text)
    text = re.sub(r"(?m)^(\s*)tokenizer_path:.*$", lambda m: m.group(1) + "tokenizer_path: " + json.dumps(args.tokenizer), text)
    path = os.path.join(args.cache, "english.yaml")
    with open(path + ".new", "w", encoding="utf-8") as file:
        file.write(text)
    os.replace(path + ".new", path)
    return path


def load():
    try:
        began = time.monotonic()
        os.makedirs(args.cache, exist_ok=True)
        import torch
        from safetensors.torch import load_file

        from pocket_tts import TTSModel
        from pocket_tts.models.model_state import export_model_state
        from pocket_tts.modules.stateful_module import init_states




        if args.threads > 0:
            torch.set_num_threads(args.threads)
        state["threads"] = torch.get_num_threads()
        tts = TTSModel.load_model(config=_config(), temp=args.temperature, sampler_decode_steps=args.steps)
        if args.decoder:
            decoder = load_file(args.decoder)
            unknown = set(decoder) - set(tts.mimi.state_dict())
            if unknown:
                raise RuntimeError(f"the retrained decoder doesn't fit Pocket TTS's codec ({sorted(unknown)[:2]})")
            tts.mimi.load_state_dict(decoder, strict=False)
        tts.mimi.eval()


        with open(args.prompt, "rb") as file:
            key = hashlib.sha256(file.read()).hexdigest()[:16]
        key += f"-{os.path.getsize(args.model)}"
        kept = os.path.join(args.cache, f"voice-{key}.safetensors")
        if os.path.isfile(kept):
            voice = tts.get_state_for_audio_prompt(kept)
        else:
            voice = tts.get_state_for_audio_prompt(args.prompt)
            try:
                export_model_state(voice, kept + ".new.safetensors")
                os.replace(kept + ".new.safetensors", kept)
            except OSError:
                pass
        model.update(tts=tts, voice=voice, init_states=init_states, torch=torch)


        with speaking, torch.no_grad():
            tts.generate_audio(voice, "Hello.")
        state["loaded"] = True
        loaded.set()
        print(f"Pocket TTS loaded in {time.monotonic() - began:.1f} s ({torch.get_num_threads()} threads)", flush=True)
    except Exception as error:
        state["error"] = f"{type(error).__name__}: {error}"
        loaded.set()
        print(f"Pocket TTS failed to load: {state['error']}", flush=True)




SAID_KEPT = 256


def _seed(text, seed):
    """The take of `text`: chosen by its words, ~~by where it falls in its line~~, so a name said ahead is the one
    its line uses."""
    return (int(seed) * 7919 + zlib.crc32(text.encode("utf-8"))) % 2_147_483_647


def is_kept(text, seed):
    with _said_lock:
        return (text, int(seed)) in _said


def say(text, seed):
    """`text` in Theo's voice, at 24 kHz, kept for the next ask of the same words."""
    key = (text, int(seed))
    with _said_lock:
        if key in _said:
            _said.move_to_end(key)
            return _said[key]
    torch = model["torch"]
    with speaking, torch.no_grad():
        torch.manual_seed(_seed(text, seed))
        audio = model["tts"].generate_audio(model["voice"], text).numpy().astype(np.float32)
    with _said_lock:
        _said[key] = audio
        while len(_said) > SAID_KEPT:
            _said.popitem(last=False)
    return audio


def through_codec(audio):
    """A clip (24 kHz) through Pocket TTS's codec and the retrained decoder, as a name is."""
    torch = model["torch"]
    with speaking, torch.no_grad():
        mimi = model["tts"].mimi
        latent = mimi.encode_to_latent(torch.from_numpy(np.ascontiguousarray(audio))[None, None])
        back = mimi.decode_from_latent(latent, model["init_states"](mimi, batch_size=1,
                                                                     sequence_length=latent.shape[1] * 16 + 64))
    return back[0, 0].numpy().astype(np.float32)





def read_clip(path):
    audio, rate = soundfile.read(path, dtype="float32", always_2d=False)
    if audio.ndim > 1:
        audio = audio.mean(axis=1)
    if rate != RATE:
        audio = resample_poly(audio, RATE, rate).astype(np.float32)
    return audio


def limited(audio, rate, ceiling=CEILING, window=0.025):
    """make_pack.py's limiter (Tools/DJBank/kit, aafd3a3): the voice turned down only around peaks over the
    ceiling, ramped over 25 ms each way, the rest left as it is."""
    w = max(1, int(window * rate))
    n = len(audio)
    if not n:
        return audio
    need = np.ones(-(-n // w) * w, np.float64)
    need[:n] = np.minimum(1.0, ceiling / np.maximum(np.abs(audio), 1e-12))
    blocks = np.pad(need.reshape(-1, w).min(axis=1), 1, constant_values=1.0)
    lowest = np.repeat(np.minimum(np.minimum(blocks[:-2], blocks[1:-1]), blocks[2:]), w)[:n]
    total = np.concatenate([[0.0], np.cumsum(np.pad(lowest, w, mode="edge"))])
    gain = (total[2 * w + 1:] - total[:-(2 * w + 1)]) / (2 * w + 1)
    return (audio * gain).astype(np.float32)


def louden(audio, gain, rate):
    """`audio` turned up by `gain`: held under the ceiling by the limiter for a louder pack (the clips were),
    else with its peaks kept under 0.97 by turning it up less, as before."""
    if args.louder:
        return limited((audio * gain).astype(np.float32), rate)
    return audio * min(gain, 0.97 / max(1e-9, float(np.abs(audio).max())))


def match(audio, target, rate):
    """`audio` made to sound `target` LUFS loud. Measured again after each turn up, as the limiter of a louder
    pack takes some back: 6 dB louder, names came out 1.0 to 1.3 LU under the clips beside them with one."""
    for _ in range(4):
        now = lufs(audio, rate)
        if abs(target - now) < 0.2:
            break
        audio = louden(audio, 10 ** ((target - now) / 20), rate)
    return audio


def even(audio, rate=POCKET_RATE):
    """The voiced parts at the bank's level (make_pack.py), peaks under 0.97 (or the ceiling)."""
    voiced = audio[np.abs(audio) > 0.01]
    rms = float(np.sqrt(np.mean(voiced ** 2))) if voiced.size else 0.0
    return louden(audio, LOUDNESS / rms if rms > 0 else 1.0, rate)


def trim(audio, rate, start_under=40.0, end_under=50.0, keep=0.06, fade=0.03, rises_to=20.0, rises_within=0.06):
    """Quiet off both ends, keeping each word's own fade (Tools/DJBank/models/pocket-tts/join.py's rule,
    9b00ba1). In 10 ms steps against the loudest: from where the voice first comes within `start_under` dB
    and goes on to come within `rises_to` dB inside `rises_within` s, to where it last falls `end_under` dB
    below (a word's fade is slow, its start sharp), `keep` more each side, faded in and out over `fade` so
    no piece starts or stops mid-wave. A piece with nothing above 0.01 is none."""







    if not audio.size or float(np.abs(audio).max()) <= 0.01:
        return audio[:0]
    step = max(1, int(0.01 * rate))
    frames = max(1, len(audio) // step)
    padded = np.zeros(frames * step, dtype=np.float64)
    padded[:min(len(audio), padded.size)] = audio[:padded.size]
    level = np.sqrt(np.mean(padded.reshape(frames, step) ** 2, axis=1))
    near = np.flatnonzero(level > level.max() * 10 ** (-start_under / 20))
    voiced = level > level.max() * 10 ** (-rises_to / 20)
    ahead = int(round(rises_within / 0.01)) + 1
    first = next((frame for frame in near if voiced[frame:frame + ahead].any()), near[0])
    last = np.flatnonzero(level > level.max() * 10 ** (-end_under / 20))[-1]
    out = audio[max(0, first * step - int(keep * rate)):min(len(audio), (last + 1) * step + int(keep * rate))].copy()
    ramp = min(int(fade * rate), out.size // 2)
    if ramp:
        curve = (np.sin(np.linspace(0, np.pi / 2, ramp)) ** 2).astype(out.dtype)
        out[:ramp] *= curve
        out[-ramp:] *= curve[::-1]
    return out


def _biquad(kind, rate, frequency, q, gain_db=0.0):
    """RBJ's cookbook filters, as BS.1770's K-weighting is made at any rate (pyloudnorm's way)."""
    a_gain = 10 ** (gain_db / 40)
    w0 = 2 * np.pi * frequency / rate
    alpha = np.sin(w0) / (2 * q)
    cos = np.cos(w0)
    if kind == "high_shelf":
        root = 2 * np.sqrt(a_gain) * alpha
        b = [a_gain * ((a_gain + 1) + (a_gain - 1) * cos + root), -2 * a_gain * ((a_gain - 1) + (a_gain + 1) * cos),
             a_gain * ((a_gain + 1) + (a_gain - 1) * cos - root)]
        a = [(a_gain + 1) - (a_gain - 1) * cos + root, 2 * ((a_gain - 1) - (a_gain + 1) * cos),
             (a_gain + 1) - (a_gain - 1) * cos - root]
    else:
        b = [(1 + cos) / 2, -(1 + cos), (1 + cos) / 2]
        a = [1 + alpha, -2 * cos, 1 - alpha]
    return np.array(b) / a[0], np.array(a) / a[0]


def lufs(audio, rate):
    """How loud it sounds (ITU-R BS.1770-4: K-weighted, 400 ms blocks, gated at -70 LUFS and 10 LU under)."""
    weighted = audio.astype(np.float64)
    for kind, frequency, q, gain in (("high_shelf", 1681.974450955533, 0.7071752369554193, 3.99984385397),
                                     ("high_pass", 38.13547087613982, 0.5003270373253953, 0.0)):
        b, a = _biquad(kind, rate, frequency, q, gain)
        weighted = lfilter(b, a, weighted)
    block, step = int(0.4 * rate), int(0.1 * rate)
    if weighted.size < block:
        weighted = np.concatenate([weighted, np.zeros(block - weighted.size)])
    powers = np.array([np.mean(weighted[at:at + block] ** 2) for at in range(0, weighted.size - block + 1, step)])
    loudness = -0.691 + 10 * np.log10(powers + 1e-12)
    kept = powers[loudness > -70]
    if not kept.size:
        return -70.0
    relative = -0.691 + 10 * np.log10(np.mean(kept)) - 10
    kept = powers[(loudness > -70) & (loudness > relative)]
    return float(-0.691 + 10 * np.log10(np.mean(kept if kept.size else powers) + 1e-12))


def make_line(pieces, codec, seed, spent):
    """The line's samples at 48 kHz from its pieces (see the top)."""
    made = []
    for index, piece in enumerate(pieces):
        if "clip" in piece:
            began = time.monotonic()
            audio = read_clip(piece["clip"])
            spent["reading"] = spent.get("reading", 0.0) + time.monotonic() - began
            if codec:
                began = time.monotonic()
                audio = through_codec(resample_poly(audio, POCKET_RATE, RATE).astype(np.float32))
                spent["codec"] = spent.get("codec", 0.0) + time.monotonic() - began
                made.append(("clip", trim(even(audio, POCKET_RATE), POCKET_RATE)))
            else:
                made.append(("clip", trim(audio, RATE)))
        else:
            began = time.monotonic()
            audio = say(piece["say"], seed)
            spent["pocket"] = spent.get("pocket", 0.0) + time.monotonic() - began
            spent["newWords"] = spent.get("newWords", 0) + len(piece["say"].split())
            if codec:
                made.append(("say", trim(even(audio, POCKET_RATE), POCKET_RATE)))
            else:

                audio = sosfilt(_HIGH_PASS, resample_poly(audio, RATE, POCKET_RATE)).astype(np.float32)
                made.append(("say", trim(even(audio, RATE), RATE)))
    rate = POCKET_RATE if codec else RATE
    made = [(kind, audio) for kind, audio in made if audio.size]
    if not made:
        return np.zeros(0, dtype=np.float32)
    clips = [audio for kind, audio in made if kind == "clip"]

    target = float(np.mean([lufs(audio, rate) for audio in clips])) if clips else args.lufs
    if target is not None and any(kind == "say" for kind, _ in made):
        for at, (kind, audio) in enumerate(made):
            if kind == "say":
                made[at] = (kind, match(audio, target, rate))
    quiet = lambda seconds: np.zeros(int(seconds * rate), dtype=np.float32)
    joined = [quiet(EDGE)]
    for at, (_, audio) in enumerate(made):
        joined += [audio, quiet(PAUSE if at < len(made) - 1 else EDGE)]
    line = np.concatenate(joined)
    if rate != RATE:
        line = resample_poly(line, RATE, rate).astype(np.float32)
    peak = float(np.max(np.abs(line))) or 1.0
    return (line * min(1.0, 0.97 / peak)).astype(np.float32)





class Handler(BaseHTTPRequestHandler):
    def log_message(self, *_):
        pass

    def _send(self, status, body, kind="application/json", headers=None):
        self.send_response(status)
        self.send_header("Content-Type", kind)
        for name, value in (headers or {}).items():
            self.send_header(name, value)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        state["heard_from"] = time.monotonic()
        if self.path == "/ready":
            self._send(200, json.dumps({"bank": True, "loaded": state["loaded"], "error": state["error"]}).encode())
        else:
            self._send(404, b"{}")

    def do_POST(self):
        state["heard_from"] = time.monotonic()
        length = int(self.headers.get("Content-Length") or 0)
        asked = json.loads(self.rfile.read(length) or b"{}")
        if self.path == "/beat":
            self._send(200, b"{}")
            return
        if self.path == "/kept":
            texts = asked.get("say") or []
            self._send(200, json.dumps({"kept": state["loaded"] and all(is_kept(text, asked.get("seed", 1)) for text in texts)}).encode())
            return
        if self.path == "/ahead":
            if not state["loaded"]:
                self._send(503, json.dumps({"error": state["error"] or "Pocket TTS is still loading"}).encode())
                return
            began = time.monotonic()
            kept = is_kept(asked.get("say") or "", asked.get("seed", 1))
            try:
                if not kept and asked.get("say"):
                    say(asked["say"], asked.get("seed", 1))
            except Exception as error:
                self._send(500, json.dumps({"error": f"{type(error).__name__}: {error}"}).encode())
                return
            finally:
                state["heard_from"] = time.monotonic()
            self._send(200, json.dumps({"keptBefore": kept, "took": round(time.monotonic() - began, 2)}).encode())
            return
        if self.path != "/line":
            self._send(404, b"{}")
            return
        pieces = asked.get("pieces") or []
        new_words = any("say" in piece for piece in pieces)
        began = time.monotonic()
        if new_words:
            loaded.wait(max(0.0, float(asked.get("wait", 0))))
            if not state["loaded"]:
                self._send(503, json.dumps({"error": state["error"] or "Pocket TTS is still loading",
                                            "loading": state["error"] is None}).encode())
                return
        spent = {"loading": time.monotonic() - began, "threads": state["threads"]}
        try:
            samples = make_line(pieces, bool(asked.get("codec")) and new_words, int(asked.get("seed", 1)), spent)
        except Exception as error:
            self._send(500, json.dumps({"error": f"{type(error).__name__}: {error}"}).encode())
            return
        finally:
            state["heard_from"] = time.monotonic()
        spent["total"] = time.monotonic() - began
        self._send(200, samples.tobytes(), "application/octet-stream", {"X-Spent": json.dumps(spent)})


def watch():


    while True:
        time.sleep(5)
        if not speaking.locked() and time.monotonic() - state["heard_from"] > args.idle:
            print("No word from the plugin; stopping", flush=True)
            os._exit(0)


threading.Thread(target=load, daemon=True).start()
threading.Thread(target=watch, daemon=True).start()
ThreadingHTTPServer(("127.0.0.1", args.port), Handler).serve_forever()
