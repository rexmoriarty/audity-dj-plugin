








import gzip
import hashlib
import json
import os
import threading
import time
from collections import OrderedDict

from flask import current_app

from . import install, reader


LIBRARY_MOST = 96 * 1024 * 1024

KEPT_READ = 4

FEEL_SONGS = 40

_lock = threading.Lock()
_libraries = OrderedDict()


def _file(server, listener):
    key = hashlib.sha256(f"{server}\n{listener}".encode()).hexdigest()[:24]
    return install.folder("libraries", key + ".json.gz")


def keep_library(server, listener, body, gzipped):
    """The app's song list, kept on the disk for this account and read: {"version", "songs": [...]}. Returns the
    version and the count."""
    data = gzip.decompress(body) if gzipped else body
    if len(data) > LIBRARY_MOST:
        raise ValueError("The library is too large.")
    sent = json.loads(data)
    songs = sent.get("songs")
    version = str(sent.get("version") or "")
    if not isinstance(songs, list) or not all(isinstance(song, dict) and song.get("id") for song in songs):
        raise ValueError("songs is a list of songs, each with an id.")
    library = reader.Library(songs, version)
    path = _file(server, listener)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with gzip.open(path + ".new", "wb", compresslevel=5) as file:
        file.write(json.dumps({"version": version, "songs": songs}, ensure_ascii=False).encode())
    os.replace(path + ".new", path)
    with _lock:
        _libraries[(server, listener)] = library
        _libraries.move_to_end((server, listener))
        while len(_libraries) > KEPT_READ:
            _libraries.popitem(last=False)
    return version, len(songs)


def library(server, listener):
    """This account's library as last sent, or None."""
    with _lock:
        kept = _libraries.get((server, listener))
        if kept is not None:
            _libraries.move_to_end((server, listener))
            return kept
    path = _file(server, listener)
    try:
        with gzip.open(path, "rb") as file:
            sent = json.loads(file.read())
    except (OSError, ValueError, EOFError):
        return None
    kept = reader.Library(sent.get("songs") or [], str(sent.get("version") or ""))
    with _lock:
        _libraries[(server, listener)] = kept
        while len(_libraries) > KEPT_READ:
            _libraries.popitem(last=False)
    return kept




def _view(name):
    for view in current_app.view_functions.values():
        if getattr(view, "__name__", "") == name:
            return view
    return None


def _called(name, method="GET", body=None):
    """AudioMuse-AI's own view `name`, asked inside this request as if on its own: (status, its JSON), or
    (None, None) when it has no such view."""
    view = _view(name)
    if view is None:
        return None, None
    with current_app.test_request_context(method=method, json=body):
        answer = current_app.make_response(current_app.ensure_sync(view)())
    try:
        return answer.status_code, answer.get_json(silent=True)
    except Exception:
        return answer.status_code, None


def feel_status():
    """Whether AudioMuse-AI can search by feel here: {"ready": bool, "why": str|None}. CLAP off in its settings, no
    text search in this version, or the library not analyzed with it."""
    try:
        from plugin.api import config
        if getattr(config, "CLAP_ENABLED", True) is False:
            return {"ready": False, "why": "CLAP is off in AudioMuse-AI's settings."}
    except ImportError:
        pass
    if _view("clap_search_api") is None:
        return {"ready": False, "why": "This AudioMuse-AI has no text search (it came in 0.9.0)."}
    status, stats = _called("cache_stats_api")
    if status == 200 and isinstance(stats, dict):
        songs = stats.get("songs") or stats.get("count") or stats.get("total") or stats.get("cached")
        if songs == 0:
            return {"ready": False, "why": "The library hasn't been analyzed with CLAP."}
    return {"ready": True, "why": None}


_warmed = {"at": 0.0}


def warm():
    """The text search's model loaded ahead (it unloads after 10 minutes idle), at most every 5 minutes, so a
    request for a feel doesn't wait for it."""
    if time.monotonic() - _warmed["at"] < 300 or _view("warmup_model_api") is None:
        return
    _warmed["at"] = time.monotonic()
    try:
        _called("warmup_model_api", "POST", {})
    except Exception:
        _warmed["at"] = 0.0


def feel_songs(text, songs_here, leave_out=None, limit=FEEL_SONGS):
    """The songs AudioMuse-AI's text search finds for `text`, of this account's library only (`songs_here`, ids), the
    song playing left out: ([{"id", "title", "artist", "album", "match"}], None), or ([], why)."""
    status, answer = _called("clap_search_api", "POST", {"query": text, "limit": max(limit * 3, 60)})
    if status is None:
        return [], "This AudioMuse-AI has no text search."
    if status == 503 or (isinstance(answer, dict) and "not loaded" in str(answer.get("error", "")).lower()):
        return [], "warming"
    if status != 200 or not isinstance(answer, dict):
        return [], (answer or {}).get("error") if isinstance(answer, dict) else f"AudioMuse-AI's text search answered {status}."
    out = []
    for result in answer.get("results") or []:
        item = str(result.get("item_id") or "")
        if not item or item == leave_out or (songs_here and item not in songs_here):
            continue
        out.append({"id": item, "title": result.get("title"), "artist": result.get("author"), "album": result.get("album"),
                    "match": round(float(result.get("similarity") or 0), 3)})
        if len(out) >= limit:
            break
    return out, None


def ask(heard, library_, playing=None, now=None):
    """What the app heard, read: {"request", "heard" (which of the words was read), "feelSongs", "feelWhy"}. The
    first of `heard` (the speech recognizer's best, then its others) that reads is the reading; with none, the
    first's feel goes to the text search."""
    playing_song = library_.by_id.get(playing) if playing else None
    request, used = None, None
    for words in heard:
        request = reader.read(words, library_, playing=playing_song, now=now)
        if request is not None:
            used = words
            break
    feel, why = [], None



    asked_a_sound = request is not None and request.get("phrase") and not reader.names_music(request)         and request.get("kind") is None and request.get("playing") is None and request.get("era") is None         and request.get("mix") is None and not request.get("genres") and not request.get("moods")         and reader.without_empty(request)
    unread = request is None or not reader.is_read(request)
    if unread and not reader.searchable(heard[0] if heard else "", library_):

        why = "The words name music that isn't in the library, or none at all."
    elif unread or asked_a_sound:

        words = (request or {}).get("phrase") or (used or (heard[0] if heard else ""))
        if words.strip():
            try:
                feel, why = feel_songs(words, set(library_.by_id), leave_out=playing)
            except Exception as error:
                feel, why = [], f"AudioMuse-AI's text search failed: {type(error).__name__}: {error}"
            used = used or heard[0]
    return {"request": request, "heard": used, "feelSongs": feel, "feelWhy": why}
