









import hashlib
import os
import secrets
import shutil
import socket
import subprocess
import sys
import threading
import time
import zipfile

import requests

from plugin.api import logger

from . import bank_setup, files


ENGINE = {"version": "1.12.0", "tag": "audity-dj-engine-1.12.0", "file": "audity-dj-engine-1.12.0.zip",
          "bytes": 63078, "sha256": "2a02e1db6fed4057d1067fc97aac3fb68714a6daded836ce2320a2bf4944c458"}

SOURCE = os.environ.get("AUDITY_DJ_ENGINE_DIR") or None


START_WAIT = 25.0
IDLE = 120

_lock = threading.RLock()
_up = threading.Event()
_state = {"process": None, "port": None, "secret": None, "began": None, "restart_at": None, "error": None,
          "fetching": False, "keeper": None, "version": None, "failed_at": 0.0}


class EngineDown(Exception):
    pass


def folder(*parts):
    return files.folder("engine", *parts)


def _installed():
    """The engine's run.py, unpacked from the release file this plugin pins, or None."""
    if SOURCE:
        return os.path.join(SOURCE, "run.py")
    here = folder(ENGINE["version"])
    try:
        with open(os.path.join(here, ".sha256")) as file:
            if file.read().strip() != ENGINE["sha256"]:
                return None
    except OSError:
        return None
    run = os.path.join(here, "run.py")
    return run if os.path.isfile(run) else None


def _fetch():
    """The engine's release file downloaded, checked by its size and SHA-256, and unpacked (only its own files, no
    paths out of its folder). The engines of other versions go once it's in."""
    url = f"{bank_setup.RELEASE}/{ENGINE['tag']}/{ENGINE['file']}"
    os.makedirs(folder(), exist_ok=True)
    archive = folder(".download.zip")
    digest = hashlib.sha256()
    with requests.get(url, stream=True, timeout=(10, 60)) as answer:
        answer.raise_for_status()
        with open(archive, "wb") as file:
            for chunk in answer.iter_content(1 << 16):
                file.write(chunk)
                digest.update(chunk)
    if os.path.getsize(archive) != ENGINE["bytes"] or digest.hexdigest() != ENGINE["sha256"]:
        os.remove(archive)
        raise RuntimeError(f"{ENGINE['file']} came down different from the one this plugin was made with")
    temporary = folder(ENGINE["version"] + ".new")
    shutil.rmtree(temporary, ignore_errors=True)
    os.makedirs(temporary)
    with zipfile.ZipFile(archive) as zipped:
        for name in zipped.namelist():
            target = os.path.realpath(os.path.join(temporary, name))
            if not target.startswith(os.path.realpath(temporary) + os.sep):
                raise RuntimeError(f"{ENGINE['file']} has a file outside its folder: {name}")
        zipped.extractall(temporary)
    with open(os.path.join(temporary, ".sha256"), "w") as file:
        file.write(ENGINE["sha256"])
    os.remove(archive)
    shutil.rmtree(folder(ENGINE["version"]), ignore_errors=True)
    os.replace(temporary, folder(ENGINE["version"]))
    for name in os.listdir(folder()):
        if name != ENGINE["version"] and not name.startswith("."):
            shutil.rmtree(folder(name), ignore_errors=True)
    logger.info("Audity DJ: the engine %s downloaded (%d bytes)", ENGINE["version"], ENGINE["bytes"])


def _relay(process):
    """The engine's log, line by line, into AudioMuse-AI's, as the plugin's own lines were before the split."""
    levels = {"DEBUG": logger.debug, "INFO": logger.info, "WARNING": logger.warning, "ERROR": logger.error,
              "CRITICAL": logger.critical}
    for line in process.stdout:
        line = line.rstrip()
        level, _, message = line.partition(" ")
        if level in levels:
            levels[level](message)
        elif line:
            logger.info("Audity DJ engine: %s", line)


def _launch(run):
    with socket.socket() as probe:
        probe.bind(("127.0.0.1", 0))
        port = probe.getsockname()[1]
    secret = secrets.token_hex(24)
    env = dict(os.environ, AUDITY_DJ_ENGINE_SECRET=secret, PYTHONUNBUFFERED="1")
    command = [sys.executable, "-s", run, "--port", str(port), "--files", files.folder(), "--idle", str(IDLE),
               *(["--facts", bank_setup.FACTS["id"]] if bank_setup.FACTS else [])]
    process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, env=env, text=True,
                               encoding="utf-8", errors="replace", bufsize=1)
    threading.Thread(target=_relay, args=(process,), name="audity-dj-engine-log", daemon=True).start()
    _state.update(process=process, port=port, secret=secret, began=time.monotonic(), error=None, version=None)
    until = time.monotonic() + 20
    while time.monotonic() < until and process.poll() is None:
        try:
            answer = requests.post(f"http://127.0.0.1:{port}/beat", headers={"X-Audity-Engine": secret}, timeout=2)
            if answer.status_code == 200:
                _state["version"] = answer.json().get("version")
                _up.set()

                requests.post(f"http://127.0.0.1:{port}/keep-on", headers={"X-Audity-Engine": secret}, timeout=5)
                return
        except (requests.RequestException, ValueError):
            pass
        time.sleep(0.2)
    _state["error"] = "The DJ's engine didn't start." if process.poll() is None else\
        f"The DJ's engine stopped as it started (code {process.poll()})."
    logger.warning("Audity DJ: %s", _state["error"])


def _start():
    """The engine started if it isn't running, downloaded first if this plugin's isn't here."""
    with _lock:
        process = _state["process"]
        if process is not None and process.poll() is None and _up.is_set():
            return
        run = _installed()
        if run is None:
            if not ENGINE["sha256"]:
                _state["error"] = "This plugin was built without its engine."
                return
            if time.monotonic() - _state["failed_at"] < 60:
                return
            _state["fetching"] = True
            try:
                _fetch()
            except Exception as error:
                _state["error"] = f"The DJ's engine couldn't be downloaded: {error}"
                _state["failed_at"] = time.monotonic()
                logger.warning("Audity DJ: %s", _state["error"])
                return
            finally:
                _state["fetching"] = False
            run = _installed()
        _up.clear()
        _launch(run)


def _keep():
    while True:
        time.sleep(5)
        with _lock:
            process, port, secret = _state["process"], _state["port"], _state["secret"]
            now = time.monotonic()
            if process is None or process.poll() is not None:
                _up.clear()
                if _state["restart_at"] is None:
                    lived = now - (_state["began"] or now)


                    _state["restart_at"] = now + (60 if process is not None and lived < 60 else 0)
                    if process is not None:
                        logger.warning("Audity DJ: the engine stopped (code %s) after %.0f s; starting it again",
                                       process.poll(), lived)
                if now >= _state["restart_at"]:
                    _state["restart_at"] = None
                    _start()
                continue
        try:
            requests.post(f"http://127.0.0.1:{port}/beat", headers={"X-Audity-Engine": secret}, timeout=3)
        except requests.RequestException:
            pass


def start():
    """Asked as AudioMuse-AI starts: the engine started (downloaded first if need be), off the caller's thread, and
    kept running."""
    with _lock:
        if _state["keeper"] is None or not _state["keeper"].is_alive():
            _state["keeper"] = threading.Thread(target=_keep, name="audity-dj-engine-keeper", daemon=True)
            _state["keeper"].start()
    threading.Thread(target=_start, name="audity-dj-engine-start", daemon=True).start()


def status():
    """The engine as the page shows it: {"state": "running" | "starting" | "downloading" | "failed", "version", "error"}."""
    running = _up.is_set() and _state["process"] is not None and _state["process"].poll() is None
    state = "running" if running else "downloading" if _state["fetching"] else "failed" if _state["error"] else "starting"
    return {"state": state, "version": _state["version"] or ENGINE["version"], "error": None if running else _state["error"]}


def ask(method, path, params=None, json=None, data=None, headers=None, timeout=30):
    """The engine's answer to a request passed on (requests' Response, streamed, its body as the engine sent it, gzip'd
    or not); EngineDown when it isn't up within START_WAIT."""


    if not _up.is_set() and not (_state["error"] and not _state["fetching"]):
        _up.wait(START_WAIT)
    if not _up.is_set():
        start()
        raise EngineDown(_state["error"] or "The DJ is starting. Try again in a moment.")
    sent = dict(headers or {}, **{"X-Audity-Engine": _state["secret"]})
    try:
        return requests.request(method, f"http://127.0.0.1:{_state['port']}{path}", params=params, json=json,
                                data=data, headers=sent, timeout=(3, timeout), stream=True)
    except requests.ConnectionError as error:
        _up.clear()
        start()
        raise EngineDown("The DJ is starting again. Try again in a moment.") from error
