












import atexit
import fcntl
import os
import re
import socket
import struct
import threading
import time

SERVICE = "_audity-dj._tcp.local."
SERVICES = "_services._dns-sd._udp.local."
GROUP = "224.0.0.251"
MDNS = 5353

HOST_TTL = 120
OTHER_TTL = 4500
A, PTR, TXT, SRV, ANY = 1, 12, 16, 33, 255
FLUSH = 0x8000
LOCK = "/tmp/audity-dj-bonjour.lock"

_started = False
_lock_file = None


def _encode(name):
    out = b""
    for label in name.rstrip(".").split("."):
        raw = label.encode("utf-8")[:63]
        out += bytes([len(raw)]) + raw
    return out + b"\x00"


def _decode(packet, at):
    """A name at `at`, following compression pointers; the name and where the bytes after it start."""
    labels, end, hops = [], None, 0
    while True:
        if at >= len(packet):
            raise ValueError("name runs past the packet")
        length = packet[at]
        if length & 0xC0 == 0xC0:
            if at + 1 >= len(packet) or hops > 20:
                raise ValueError("bad pointer")
            if end is None:
                end = at + 2
            at = ((length & 0x3F) << 8) | packet[at + 1]
            hops += 1
            continue
        if length == 0:
            return ".".join(labels) + ".", (end if end is not None else at + 1)
        labels.append(packet[at + 1:at + 1 + length].decode("utf-8", "replace"))
        at += 1 + length


def _record(name, kind, ttl, data, flush=False):
    return _encode(name) + struct.pack("!HHIH", kind, 1 | (FLUSH if flush else 0), ttl, len(data)) + data


def _txt(entries):
    out = b""
    for key, value in entries.items():
        raw = f"{key}={value}".encode("utf-8")[:255]
        out += bytes([len(raw)]) + raw
    return out


def _address():
    """This machine's address on the network the announcement goes out on: the one its multicast leaves from."""
    probe = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        probe.connect((GROUP, MDNS))
        return probe.getsockname()[0]
    finally:
        probe.close()


class Announcer:
    def __init__(self, port, version, path, host=None, address=None):
        machine = re.sub(r"[^A-Za-z0-9-]", "-", (host or socket.gethostname()).split(".")[0]).strip("-") or "server"
        self.instance = f"Audity DJ on {machine}." + SERVICE
        self.host = f"audity-dj-{machine.lower()}.local."
        self.port = port
        self.address = address or _address()
        self.txt = _txt({"path": path, "version": version})
        self.sock = None
        self.running = False

    def records(self, ttl=None):
        """Every record the DJ is announced with: (name, kind, record bytes)."""
        def t(default):
            return default if ttl is None else ttl
        srv = struct.pack("!HHH", 0, 0, self.port) + _encode(self.host)
        return [
            (SERVICE, PTR, _record(SERVICE, PTR, t(OTHER_TTL), _encode(self.instance))),
            (self.instance, SRV, _record(self.instance, SRV, t(HOST_TTL), srv, flush=True)),
            (self.instance, TXT, _record(self.instance, TXT, t(OTHER_TTL), self.txt, flush=True)),
            (self.host, A, _record(self.host, A, t(HOST_TTL), socket.inet_aton(self.address), flush=True)),
            (SERVICES, PTR, _record(SERVICES, PTR, t(OTHER_TTL), _encode(SERVICE))),
        ]

    def answer(self, questions):
        """The answers and additional records for a query's questions, by RFC 6763 §12's additional records."""
        records = self.records()
        by = {(name.lower(), kind): data for name, kind, data in records}
        answers, extra = [], []

        def add(into, key):
            data = by.get(key)
            if data is not None and data not in answers and data not in extra:
                into.append(data)

        for name, kind in questions:
            name = name.lower()
            for (rname, rkind), data in by.items():
                if rname == name and (kind == rkind or kind == ANY) and data not in answers:
                    answers.append(data)
        names = {name.lower() for name, _ in questions}
        if SERVICE.lower() in names or self.instance.lower() in names:
            for key in ((self.instance.lower(), SRV), (self.instance.lower(), TXT), (self.host, A)):
                add(extra, key)
        return answers, extra

    @staticmethod
    def packet(answers, extra=(), ident=0, questions=b"", qcount=0):
        header = struct.pack("!HHHHHH", ident, 0x8400, qcount, len(answers), 0, len(extra))
        return header + questions + b"".join(answers) + b"".join(extra)

    def open(self):
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        if hasattr(socket, "SO_REUSEPORT"):
            try:
                sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEPORT, 1)
            except OSError:
                pass
        sock.bind(("", MDNS))
        sock.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_TTL, 255)
        sock.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_LOOP, 1)
        sock.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_IF, socket.inet_aton(self.address))
        sock.setsockopt(socket.IPPROTO_IP, socket.IP_ADD_MEMBERSHIP, socket.inet_aton(GROUP) + socket.inet_aton(self.address))
        sock.settimeout(0.25)
        self.sock = sock

    def send(self, data, to=(GROUP, MDNS)):
        try:
            self.sock.sendto(data, to)
        except OSError:
            pass

    def announce(self, ttl=None):
        self.send(self.packet([data for _, _, data in self.records(ttl)]))

    def handle(self, packet, sender):
        if len(packet) < 12:
            return
        ident, flags, qcount = struct.unpack("!HHH", packet[:6])
        if flags & 0x8000:
            return
        at, questions, unicast = 12, [], False
        for _ in range(qcount):
            name, at = _decode(packet, at)
            kind, klass = struct.unpack("!HH", packet[at:at + 4])
            at += 4
            questions.append((name, kind))
            unicast |= bool(klass & FLUSH)
        answers, extra = self.answer(questions)
        if not answers:
            return
        if sender[1] != MDNS:

            self.send(self.packet(answers, extra, ident, packet[12:at], qcount), sender)
        elif unicast:
            self.send(self.packet(answers, extra), sender)
        else:
            self.send(self.packet(answers, extra))

    def run(self):
        self.running = True

        announced, next_at = 0, 0.0
        while self.running:
            if announced < 2 and time.monotonic() >= next_at:
                self.announce()
                announced, next_at = announced + 1, time.monotonic() + 1
            try:
                packet, sender = self.sock.recvfrom(9000)
            except socket.timeout:
                continue
            except OSError:
                break
            try:
                self.handle(packet, sender)
            except (ValueError, struct.error, IndexError):
                continue

    def stop(self):
        """Goodbye (RFC 6762 §10.1): the records with no time to live, so they go from every cache at once."""
        if self.sock is None:
            return
        self.running = False
        self.announce(ttl=0)
        self.sock.close()
        self.sock = None


def start(version, logger, port=None, path="/plugins/audity_dj/app"):
    """Announces the DJ once for this machine, from whichever of AudioMuse-AI's processes gets there first."""
    global _started, _lock_file
    if _started or os.environ.get("AUDITY_DJ_BONJOUR", "on").lower() in ("off", "0", "no"):
        return None
    try:
        _lock_file = open(LOCK, "w")
        fcntl.flock(_lock_file, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except OSError:
        return None
    _started = True
    port = int(port or os.environ.get("AUDITY_DJ_BONJOUR_PORT", "8000"))
    try:
        announcer = Announcer(port, version, path)
        announcer.open()
    except Exception as error:
        logger.info("Audity DJ: not announced on your network with Bonjour (%s)", error)
        return None
    threading.Thread(target=announcer.run, name="audity-dj-bonjour", daemon=True).start()
    atexit.register(announcer.stop)
    logger.info("Audity DJ: announced on your network with Bonjour as \"%s\", port %d", announcer.instance.split("._")[0], port)
    return announcer


if __name__ == "__main__":



    import logging
    import signal
    import sys

    logging.basicConfig(level=logging.INFO, format="%(message)s")
    here = os.path.dirname(os.path.abspath(__file__))
    try:
        version = re.search(r'^VERSION = "([^"]+)"', open(os.path.join(here, "__init__.py")).read(), re.M).group(1)
    except (OSError, AttributeError):
        version = "unknown"
    signal.signal(signal.SIGTERM, lambda *_: sys.exit(0))
    if start(version, logging.getLogger("audity-dj")) is None:
        sys.exit(1)
    while True:
        time.sleep(3600)
